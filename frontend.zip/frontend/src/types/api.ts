export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  accountNumber?: string;
}

// Customer Info Types
export interface CustomerInfoResponse {
  data: CustomerData;
  context: string;
}

export interface CustomerData {
  id: string;
  'first-name': string;
  'first-surname': string;
  'last-name': string;
  address: Address;
  'customer-suitability': CustomerSuitability;
  'mailing-address': Address;
  'is-foreign': boolean;
  'regulatory-domain': string;
  'usa-citizenship-type': string;
  'mobile-phone-number': string;
  'birth-date': string;
  email: string;
  'external-id': string;
  'tax-number': string;
  'tax-number-type': string;
  'citizenship-country': string;
  'agreed-to-margining': boolean;
  'subject-to-tax-withholding': boolean;
  'agreed-to-terms': boolean;
  'ext-crm-id': string;
  'has-industry-affiliation': boolean;
  'has-institutional-assets': boolean;
  'has-listed-affiliation': boolean;
  'has-political-affiliation': boolean;
  'is-investment-adviser': boolean;
  'has-delayed-quotes': boolean;
  'has-pending-or-approved-application': boolean;
  'is-professional': boolean;
  'permitted-account-types': PermittedAccountType[];
  'created-at': string;
  'identifiable-type': string;
  person: Person;
}

export interface Address {
  city: string;
  country: string;
  'is-domestic': boolean;
  'is-foreign': boolean;
  'postal-code': string;
  'state-region': string;
  'street-one': string;
  'street-two': string;
}

export interface CustomerSuitability {
  id: number;
  'annual-net-income': number;
  'covered-options-trading-experience': string;
  'employer-name': string;
  'employment-status': string;
  'futures-trading-experience': string;
  'job-title': string;
  'liquid-net-worth': number;
  'marital-status': string;
  'net-worth': number;
  'number-of-dependents': number;
  occupation: string;
  'stock-trading-experience': string;
  'uncovered-options-trading-experience': string;
}

export interface PermittedAccountType {
  name: string;
  description: string;
  is_tax_advantaged: boolean;
  has_multiple_owners: boolean;
  is_publicly_available: boolean;
  margin_types: MarginType[];
}

export interface MarginType {
  name: string;
  is_margin: boolean;
}

export interface Person {
  'external-id': string;
  'first-name': string;
  'last-name': string;
  'birth-date': string;
  'citizenship-country': string;
  'usa-citizenship-type': string;
  'employer-name': string;
  'employment-status': string;
  'job-title': string;
  'marital-status': string;
  'number-of-dependents': number;
  occupation: string;
}

// Account Types
export interface AccountsResponse {
  data: {
    items: AccountItem[];
  };
  context: string;
}

export interface AccountItem {
  account: Account;
  'authority-level': string;
}

export interface Account {
  'account-number': string;
  'opened-at': string;
  nickname?: string;
  'account-type-name': string;
  'day-trader-status': boolean;
  'is-closed': boolean;
  'is-firm-error': boolean;
  'is-firm-proprietary': boolean;
  'is-futures-approved': boolean;
  'is-test-drive': boolean;
  'margin-or-cash': string;
  'is-foreign': boolean;
  'funding-date': string;
  'investment-objective': string;
  'liquidity-needs': string;
  'risk-tolerance': string;
  'time-horizon': string;
  'investment-time-horizon': string;
  'suitable-options-level': string;
  'created-at': string;
  'external-id': string;
}

// Balance Types
export interface AccountBalancesResponse {
  data: AccountBalances;
  context: string;
}

export interface AccountBalances {
  'account-number': string;
  'cash-balance': number;
  'long-equity-value': number;
  'short-equity-value': number;
  'long-derivative-value': number;
  'short-derivative-value': number;
  'long-futures-value': number;
  'short-futures-value': number;
  'long-futures-derivative-value': number;
  'short-futures-derivative-value': number;
  'long-margineable-value': number;
  'short-margineable-value': number;
  'margin-equity': number;
  'equity-buying-power': number;
  'derivative-buying-power': number;
  'used-derivative-buying-power': number;
  'day-trading-buying-power': number;
  'futures-margin-requirement': number;
  'available-trading-funds': number;
  'maintenance-requirement': number;
  'maintenance-call-value': number;
  'reg-t-call-value': number;
  'day-trading-call-value': number;
  'day-equity-call-value': number;
  'net-liquidating-value': number;
  'cash-available-to-withdraw': number;
  'day-trade-excess': number;
  'pending-cash': number;
  'pending-cash-effect': string;
  'long-cryptocurrency-value': number;
  'short-cryptocurrency-value': number;
  'cryptocurrency-margin-requirement': number;
  'unsettled-cryptocurrency-fiat-amount': number;
  'unsettled-cryptocurrency-fiat-effect': string;
  'closed-loop-available-balance': number;
  'equity-offering-margin-requirement': number;
  'long-bond-value': number;
  'bond-margin-requirement': number;
  'snapshot-date': string;
  'reg-t-margin-requirement': number;
  'futures-overnight-margin-requirement': number;
  'futures-intraday-margin-requirement': number;
  'maintenance-excess': number;
  'pending-margin-interest': number;
  'effective-cryptocurrency-buying-power': number;
  'updated-at': string;
}

// Position Types
export interface AccountPositionsResponse {
  data: {
    items: Position[];
    pagination?: any;
    'total-count'?: number;
  };
  context: string;
}

export interface Position {
  'account-number': string;
  symbol: string;
  'instrument-type': string;
  'underlying-symbol': string;
  quantity: number;
  'quantity-direction': string;
  'close-price': number;
  'average-open-price': number;
  'average-yearly-market-close-price': number;
  'average-daily-market-close-price': number;
  multiplier: number;
  'cost-effect': string;
  'is-suppressed': boolean;
  'is-frozen': boolean;
  'restricted-quantity': number;
  'realized-day-gain': number;
  'realized-day-gain-effect': string;
  'realized-day-gain-date': string;
  'realized-today': number;
  'realized-today-effect': string;
  'realized-today-date': string;
  'created-at': string;
  'updated-at': string;
  
  // Enhanced fields from API documentation
  mark?: number;
  'mark-price'?: number;
  'expires-at'?: string;
  'days-to-expiration'?: number;
  'net-liquidating-value'?: number;
  'market-value'?: number;
  'buying-power-effect'?: number;
  'buying-power-effect-type'?: string;
  'price-effect'?: number;
  'price-effect-type'?: string;
  'time-of-day'?: string;
  
  // Enhanced instrument object
  instrument?: PositionInstrument;
}

export interface PositionInstrument {
  // Common fields for all instruments
  symbol?: string;
  'instrument-type'?: string;
  active?: boolean;
  cusip?: string;
  description?: string;
  'listed-market'?: string;
  'tick-sizes'?: TickSize[];
  'market-time-instrument-collection'?: string;
  'is-closing-only'?: boolean;
  'is-options-closing-only'?: boolean;
  'short-description'?: string;
  exchange?: string;
  'streamer-symbol'?: string;
  
  // Equity-specific fields
  'is-etf'?: boolean;
  'is-index'?: boolean;
  lendability?: string;
  'borrow-rate'?: number;
  'market-cap'?: number;
  'shares-outstanding'?: number;
  
  // Option-specific fields
  'strike-price'?: number;
  'root-symbol'?: string;
  'underlying-symbol'?: string;
  'expiration-date'?: string;
  'exercise-style'?: string;
  'shares-per-contract'?: number;
  'option-type'?: string; // "C" for Call, "P" for Put
  'option-chain-type'?: string;
  'expiration-type'?: string;
  'settlement-type'?: string;
  'stops-trading-at'?: string;
  'days-to-expiration'?: number;
  'expires-at'?: string;
  'deliverable-type'?: string;
  'old-security-number'?: string;
  'spc-details'?: any;
  
  // Future-specific fields
  'product-code'?: string;
  'contract-size'?: number;
  'tick-size'?: number;
  'display-factor'?: number;
  'last-trade-date'?: string;
  'first-notice-date'?: string;
  'roll-target-symbol'?: string;
  
  // Cryptocurrency-specific fields
  'crypto-type'?: string;
  
  // Warrant-specific fields
  'warrant-type'?: string;
  'shared-symbol'?: string;
}

export interface TickSize {
  value?: number;
  threshold?: number;
  symbol?: string;
}

// Transaction Types
export interface TransactionsResponse {
  data: TransactionData;
  context: string;
}

export interface TransactionData {
  items: Transaction[];
  pagination: TransactionPagination;
}

export interface TransactionPagination {
  'total-items': number;
  'items-per-page': number;
  'page-count': number;
  'current-page-index': number;
}

export interface Transaction {
  id: number;
  'account-number': string;
  symbol?: string;
  'instrument-type'?: string;
  'transaction-type': string;
  'transaction-sub-type': string;
  description: string;
  quantity?: string;  // Keep as string for precision
  price?: string;     // Keep as string for precision
  'executed-at': string;
  value: string;      // Keep as string for precision
  'value-effect': string; // "Credit" or "Debit"
  
  // Fee-related fields (for trade transactions)
  commission?: string;
  'clearing-fees'?: string;
  'proprietary-index-option-fees'?: string;
  'regulatory-fees'?: string;
  
  // Additional fields
  action?: string;
  'underlying-symbol'?: string;
  'order-id'?: number;
}

export interface SingleTransactionResponse {
  data: Transaction;
  context: string;
}