import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { accountApi } from '../services/api';
import { TransactionsResponse, Transaction, TransactionPagination } from '../types/api';
import Tooltip from './Tooltip';
import { getDefinition } from '../utils/financialDefinitions';

type FilterType = 'all' | 'Trade' | 'Money Movement' | 'Receive Deliver' | 'Administrative Transfer';
type SortDirection = 'asc' | 'desc';

const AccountTransactions: React.FC = () => {
  const { accountNumber } = useParams<{ accountNumber: string }>();
  const navigate = useNavigate();
  
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [pagination, setPagination] = useState<TransactionPagination | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');
  
  // Filter and search state
  const [filterType, setFilterType] = useState<FilterType>('all');
  const [searchSymbol, setSearchSymbol] = useState<string>('');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  useEffect(() => {
    if (!accountNumber) {
      setError('No account number provided');
      setLoading(false);
      return;
    }

    fetchTransactions();
  }, [accountNumber, filterType, searchSymbol, startDate, endDate, sortDirection]);

  const fetchTransactions = async () => {
    if (!accountNumber) {
      setError('No account number provided');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      
      // Determine if we need filtered request
      const hasFilters = filterType !== 'all' || searchSymbol || startDate || endDate;
      
      let response: any;
      
      if (hasFilters) {
        const filters: any = {
          sort: sortDirection === 'asc' ? 'Asc' : 'Desc'
        };
        
        if (filterType !== 'all') filters.type = filterType;
        if (searchSymbol) filters.symbol = searchSymbol.toUpperCase();
        if (startDate) filters['start-date'] = startDate;
        if (endDate) filters['end-date'] = endDate;
        
        response = await accountApi.getAccountTransactionsFiltered(accountNumber, filters);
      } else {
        response = await accountApi.getAccountTransactions(accountNumber);
      }
      
      if (response.success && response.data) {
        setTransactions(response.data.data.items || []);
        setPagination(response.data.data.pagination || null);
      } else {
        setError('Failed to fetch account transactions');
      }
    } catch (err) {
      setError('Error fetching account transactions: ' + (err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  // Helper functions
  const formatCurrency = (value: string | number) => {
    const num = typeof value === 'string' ? parseFloat(value) : value;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(num || 0);
  };

  const formatQuantity = (quantity: string | undefined) => {
    if (!quantity) return '-';
    const num = parseFloat(quantity);
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 6,
    }).format(num);
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateString;
    }
  };

  const getTransactionTypeIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'trade': return '💰';
      case 'money movement': return '🏦';
      case 'receive deliver': return '📩';
      case 'administrative transfer': return '📋';
      default: return '📄';
    }
  };

  const getTransactionTypeColor = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'trade': return 'trade';
      case 'money movement': return 'money';
      case 'receive deliver': return 'dividend';
      case 'administrative transfer': return 'admin';
      default: return 'default';
    }
  };

  const getValueEffectColor = (effect: string) => {
    return effect?.toLowerCase() === 'credit' ? 'positive' : 'negative';
  };

  // Statistics
  const transactionStats = useMemo(() => {
    const stats = {
      total: transactions.length,
      trades: 0,
      moneyMovement: 0,
      dividends: 0,
      totalValue: 0,
      credits: 0,
      debits: 0
    };

    transactions.forEach(tx => {
      const value = parseFloat(tx.value || '0');
      stats.totalValue += Math.abs(value);
      
      if (tx['value-effect']?.toLowerCase() === 'credit') {
        stats.credits += value;
      } else {
        stats.debits += value;
      }

      switch (tx['transaction-type']?.toLowerCase()) {
        case 'trade':
          stats.trades++;
          break;
        case 'money movement':
          stats.moneyMovement++;
          break;
        case 'receive deliver':
          stats.dividends++;
          break;
      }
    });

    return stats;
  }, [transactions]);

  if (loading) return <div className="loading">Loading account transactions...</div>;
  if (error) return <div className="error">Error: {error}</div>;

  return (
    <div className="transactions-dashboard">
      {/* Hero Header */}
      <div className="transactions-hero-header">
        <div className="hero-background-pattern"></div>
        <div className="hero-content-wrapper">
          <div className="transactions-title-section">
            <div className="title-icon-large">📊</div>
            <div className="title-content">
              <h1>Account Transactions</h1>
              <div className="account-info">
                <span className="account-badge">#{accountNumber}</span>
                <span className="live-indicator">
                  <span className="pulse-dot"></span>
                  Real-time Data
                </span>
              </div>
            </div>
          </div>
          <div className="header-actions">
            <button onClick={() => navigate(`/accounts/${accountNumber}`)} className="dashboard-btn secondary">
              ← Account Details
            </button>
            <button onClick={() => navigate(`/accounts/${accountNumber}/positions`)} className="dashboard-btn primary">
              📊 View Positions
            </button>
            <button onClick={() => navigate(`/accounts/${accountNumber}/balances`)} className="dashboard-btn primary">
              💰 View Balances
            </button>
          </div>
        </div>
      </div>

      {/* Transaction Statistics */}
      <div className="transaction-stats-dashboard">
        <div className="stats-grid">
          <div className="stat-card primary">
            <div className="stat-icon">📈</div>
            <div className="stat-content">
              <h3>Total Transactions</h3>
              <div className="stat-value">{transactionStats.total}</div>
              <div className="stat-subtitle">{pagination?.['total-items'] || 0} total records</div>
            </div>
          </div>
          
          <div className="stat-card trade">
            <div className="stat-icon">💰</div>
            <div className="stat-content">
              <h3>Trades</h3>
              <div className="stat-value">{transactionStats.trades}</div>
              <div className="stat-subtitle">Buy/Sell activities</div>
            </div>
          </div>
          
          <div className="stat-card dividend">
            <div className="stat-icon">📩</div>
            <div className="stat-content">
              <h3>Dividends</h3>
              <div className="stat-value">{transactionStats.dividends}</div>
              <div className="stat-subtitle">Dividend payments</div>
            </div>
          </div>
          
          <div className="stat-card money">
            <div className="stat-icon">🏦</div>
            <div className="stat-content">
              <h3>Money Movement</h3>
              <div className="stat-value">{transactionStats.moneyMovement}</div>
              <div className="stat-subtitle">Deposits/Withdrawals</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Controls */}
      <div className="transaction-controls">
        <div className="controls-section">
          <div className="filter-group">
            <label>Transaction Type:</label>
            <select 
              value={filterType} 
              onChange={(e) => setFilterType(e.target.value as FilterType)}
              className="filter-select"
            >
              <option value="all">All Types</option>
              <option value="Trade">Trades</option>
              <option value="Money Movement">Money Movement</option>
              <option value="Receive Deliver">Dividends & Delivers</option>
              <option value="Administrative Transfer">Administrative</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Symbol:</label>
            <input
              type="text"
              value={searchSymbol}
              onChange={(e) => setSearchSymbol(e.target.value)}
              placeholder="e.g., AAPL"
              className="filter-input"
            />
          </div>

          <div className="filter-group">
            <label>Start Date:</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="filter-input"
            />
          </div>

          <div className="filter-group">
            <label>End Date:</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="filter-input"
            />
          </div>

          <div className="filter-group">
            <label>Sort:</label>
            <select 
              value={sortDirection} 
              onChange={(e) => setSortDirection(e.target.value as SortDirection)}
              className="filter-select"
            >
              <option value="desc">Newest First</option>
              <option value="asc">Oldest First</option>
            </select>
          </div>
        </div>
      </div>

      {/* Transactions Table */}
      {transactions.length > 0 ? (
        <div className="transactions-table-container">
          <div className="transactions-table-wrapper">
            <table className="transactions-table">
              <thead>
                <tr>
                  <th>Transaction</th>
                  <th>Symbol</th>
                  <th>Type</th>
                  <th>Action</th>
                  <th>Quantity</th>
                  <th>Price</th>
                  <th>Value</th>
                  <th>Fees</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((transaction, index) => (
                  <tr key={transaction.id} className={`transaction-row ${getTransactionTypeColor(transaction['transaction-type'])}`}>
                    <td className="transaction-info-cell">
                      <div className="transaction-info">
                        <div className="transaction-header">
                          <span className="transaction-icon">
                            {getTransactionTypeIcon(transaction['transaction-type'])}
                          </span>
                          <span className="transaction-id">#{transaction.id}</span>
                        </div>
                        <div className="transaction-description">{transaction.description}</div>
                        <div className="transaction-sub-type">{transaction['transaction-sub-type']}</div>
                      </div>
                    </td>
                    
                    <td className="symbol-cell">
                      {transaction.symbol ? (
                        <div className="symbol-info">
                          <span className="symbol-name">{transaction.symbol}</span>
                          {transaction['underlying-symbol'] && (
                            <span className="underlying-symbol">
                              ({transaction['underlying-symbol']})
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="no-symbol">—</span>
                      )}
                    </td>
                    
                    <td className="type-cell">
                      <span className={`transaction-type-badge ${getTransactionTypeColor(transaction['transaction-type'])}`}>
                        {transaction['transaction-type']}
                      </span>
                    </td>
                    
                    <td className="action-cell">
                      {transaction.action ? (
                        <span className={`action-badge ${transaction.action?.toLowerCase()}`}>
                          {transaction.action}
                        </span>
                      ) : (
                        <span className="no-action">—</span>
                      )}
                    </td>
                    
                    <td className="quantity-cell">
                      {transaction.quantity ? formatQuantity(transaction.quantity) : '—'}
                    </td>
                    
                    <td className="price-cell">
                      {transaction.price ? formatCurrency(transaction.price) : '—'}
                    </td>
                    
                    <td className="value-cell">
                      <div className="transaction-value">
                        <span className={`value-amount ${getValueEffectColor(transaction['value-effect'])}`}>
                          {transaction['value-effect']?.toLowerCase() === 'credit' ? '+' : ''}
                          {formatCurrency(transaction.value)}
                        </span>
                        <span className="value-effect">{transaction['value-effect']}</span>
                      </div>
                    </td>
                    
                    <td className="fees-cell">
                      <div className="fees-info">
                        {transaction.commission && (
                          <div className="fee-item">
                            <span className="fee-label">Commission:</span>
                            <span className="fee-value">{formatCurrency(transaction.commission)}</span>
                          </div>
                        )}
                        {transaction['regulatory-fees'] && (
                          <div className="fee-item">
                            <span className="fee-label">Regulatory:</span>
                            <span className="fee-value">{formatCurrency(transaction['regulatory-fees'])}</span>
                          </div>
                        )}
                        {!transaction.commission && !transaction['regulatory-fees'] && (
                          <span className="no-fees">—</span>
                        )}
                      </div>
                    </td>
                    
                    <td className="date-cell">
                      <div className="transaction-date">
                        {formatDate(transaction['executed-at'])}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Info */}
          {pagination && (
            <div className="pagination-info">
              <div className="pagination-text">
                Showing {transactions.length} of {pagination['total-items']} transactions
                (Page {(pagination['current-page-index'] || 0) + 1} of {pagination['page-count'] || 1})
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="empty-transactions-state">
          <div className="empty-transactions-bg"></div>
          <div className="empty-content">
            <div className="empty-icon">📊</div>
            <h2>No Transactions Found</h2>
            <p>No transactions match your current filters.</p>
            <p>Try adjusting your search criteria or date range.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountTransactions;