import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';

interface TooltipProps {
  content: string;
  children: React.ReactNode;
  position?: 'top' | 'bottom' | 'left' | 'right' | 'auto';
  className?: string;
}

const Tooltip: React.FC<TooltipProps> = ({ content, children, position = 'auto', className = '' }) => {
  const [isVisible, setIsVisible] = useState(false);
  const hideTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [actualPosition, setActualPosition] = useState(position);
  const [tooltipStyle, setTooltipStyle] = useState<React.CSSProperties>({});
  const tooltipRef = useRef<HTMLDivElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const updateTooltipPosition = () => {
    if (!isVisible || !wrapperRef.current) return;

    const wrapper = wrapperRef.current;
    const rect = wrapper.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    const tooltipWidth = 280; // max-width from CSS
    const tooltipHeight = 60; // estimated height
    
    let bestPosition: 'top' | 'bottom' | 'left' | 'right' = 'top';
    let style: React.CSSProperties = {};
    
    if (position === 'auto') {
      // Check if tooltip fits above
      if (rect.top - tooltipHeight - 10 >= 0) {
        bestPosition = 'top';
      }
      // Check if tooltip fits below
      else if (rect.bottom + tooltipHeight + 10 <= viewportHeight) {
        bestPosition = 'bottom';
      }
      // Check if tooltip fits to the right
      else if (rect.right + tooltipWidth + 10 <= viewportWidth) {
        bestPosition = 'right';
      }
      // Check if tooltip fits to the left
      else if (rect.left - tooltipWidth - 10 >= 0) {
        bestPosition = 'left';
      }
      // Default to bottom if nothing else works
      else {
        bestPosition = 'bottom';
      }
    } else {
      bestPosition = position;
    }
    
    // Calculate fixed position based on wrapper's position
    switch (bestPosition) {
      case 'top':
        style = {
          top: rect.top - 10,
          left: rect.left + rect.width / 2,
          transform: 'translate(-50%, -100%)',
        };
        break;
      case 'bottom':
        style = {
          top: rect.bottom + 10,
          left: rect.left + rect.width / 2,
          transform: 'translate(-50%, 0)',
        };
        break;
      case 'left':
        style = {
          top: rect.top + rect.height / 2,
          left: rect.left - 10,
          transform: 'translate(-100%, -50%)',
        };
        break;
      case 'right':
        style = {
          top: rect.top + rect.height / 2,
          left: rect.right + 10,
          transform: 'translate(0, -50%)',
        };
        break;
    }
    
    setActualPosition(bestPosition);
    setTooltipStyle(style);
  };

  useEffect(() => {
    if (isVisible) {
      updateTooltipPosition();
      
      // Update position on scroll and resize
      const handleUpdate = () => updateTooltipPosition();
      window.addEventListener('scroll', handleUpdate, true);
      window.addEventListener('resize', handleUpdate);
      
      return () => {
        window.removeEventListener('scroll', handleUpdate, true);
        window.removeEventListener('resize', handleUpdate);
      };
    }
  }, [isVisible, position]);

  const renderTooltip = () => {
    if (!isVisible) return null;
    
    return createPortal(
      <div 
        ref={tooltipRef}
        className={`tooltip tooltip-${actualPosition} tooltip-smart`}
        style={tooltipStyle}
      >
        <div className="tooltip-content">
          {content}
        </div>
        <div className="tooltip-arrow"></div>
      </div>,
      document.body
    );
  };

  const handleMouseEnter = () => {
    if (hideTimeoutRef.current) {
      clearTimeout(hideTimeoutRef.current);
      hideTimeoutRef.current = null;
    }
    setIsVisible(true);
  };

  const handleMouseLeave = () => {
    hideTimeoutRef.current = setTimeout(() => {
      setIsVisible(false);
    }, 100); // Small delay to prevent flicker
  };

  return (
    <div 
      ref={wrapperRef}
      className={`tooltip-wrapper ${className}`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {children}
      {renderTooltip()}
    </div>
  );
};

export default Tooltip;