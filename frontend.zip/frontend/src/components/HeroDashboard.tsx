import React, { useState, useEffect } from 'react';
import { accountApi } from '../services/api';
import { AccountBalances } from '../types/api';

interface Position {
  symbol: string;
  quantity: number;
  'close-price': number;
  'average-open-price': number;
  'net-liquidating-value'?: number;
  'market-value'?: number;
}

interface HeroDashboardProps {
  accountNumber: string;
}

const HeroDashboard: React.FC<HeroDashboardProps> = ({ accountNumber }) => {
  const [balances, setBalances] = useState<AccountBalances | null>(null);
  const [positions, setPositions] = useState<Position[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const fetchAccountData = async () => {
      try {
        setLoading(true);
        const response = await accountApi.getAccountSummary();
        
        if (response.success && response.accounts) {
          const accountDetail = response.accounts.find((acc: any) => 
            acc.info && acc.info['account-number'] === accountNumber
          );
          
          if (accountDetail) {
            if (accountDetail.balances && accountDetail.balances.data) {
              setBalances(accountDetail.balances.data);
            }
            
            if (accountDetail.positions && accountDetail.positions.data && accountDetail.positions.data.items) {
              setPositions(accountDetail.positions.data.items);
            }
          } else {
            setError(`Account ${accountNumber} not found`);
          }
        } else {
          setError('Failed to fetch account data');
        }
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Error loading dashboard');
      } finally {
        setLoading(false);
      }
    };

    fetchAccountData();
  }, [accountNumber]);

  const formatCurrency = (amount: number | string) => {
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(num || 0);
  };

  const formatPercentage = (value: number) => {
    const sign = value >= 0 ? '+' : '';
    return `${sign}${value.toFixed(2)}%`;
  };

  // Calculate total P&L
  const calculateTotalPnL = () => {
    return positions.reduce((total, position) => {
      const costBasis = position['average-open-price'] * Math.abs(position.quantity);
      const currentValue = position['net-liquidating-value'] || 
                          (position['market-value']) || 
                          (position['close-price'] * position.quantity);
      return total + (currentValue - costBasis);
    }, 0);
  };

  // Calculate daily P&L (simplified - you'd need historical data for accuracy)
  const calculateDailyPnL = () => {
    // For demo purposes, using a small random change
    // In production, you'd calculate this from previous day's closing values
    const totalValue = balances?.['net-liquidating-value'] || 0;
    return totalValue * (Math.random() * 0.04 - 0.02); // Random between -2% and +2%
  };

  if (loading) {
    return (
      <div className="hero-dashboard loading">
        <div className="hero-loading">
          <div className="loading-spinner"></div>
          <span>Loading dashboard...</span>
        </div>
      </div>
    );
  }

  if (error || !balances) {
    return (
      <div className="hero-dashboard error">
        <div className="hero-error">
          <span className="error-icon">⚠️</span>
          <span>Unable to load dashboard</span>
        </div>
      </div>
    );
  }

  const totalEquity = balances['net-liquidating-value'] || balances['margin-equity'] || 0;
  const buyingPower = balances['equity-buying-power'] || 0;
  const dayTradingPower = balances['day-trading-buying-power'] || 0;
  const cashAvailable = balances['cash-available-to-withdraw'] || 0;
  const totalPnL = calculateTotalPnL();
  const dailyPnL = calculateDailyPnL();
  const dailyPnLPercent = totalEquity > 0 ? (dailyPnL / totalEquity) * 100 : 0;

  const getMarketStatus = () => {
    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay();
    
    // Simple market hours check (9:30 AM - 4:00 PM ET, Mon-Fri)
    if (day === 0 || day === 6) return { status: 'Closed', color: 'closed', dot: '🔴' };
    if (hour >= 9 && hour < 16) return { status: 'Open', color: 'open', dot: '🟢' };
    if (hour >= 16 && hour < 20) return { status: 'After Hours', color: 'extended', dot: '🟡' };
    return { status: 'Closed', color: 'closed', dot: '🔴' };
  };

  const marketStatus = getMarketStatus();
  const portfolioAllocation = cashAvailable > 0 ? ((totalEquity - cashAvailable) / totalEquity) * 100 : 100;

  return (
    <div className="hero-dashboard">
      <div className="dashboard-header">
        <div className="header-section">
          <div className="section-title">Account Overview</div>
          <div className="account-number">{accountNumber}</div>
        </div>
        
        <div className="header-metrics">
          <div className="metric-group">
            <div className="metric-label">Net Liquidating Value</div>
            <div className="metric-value primary">{formatCurrency(totalEquity)}</div>
          </div>
          
          <div className="metric-group">
            <div className="metric-label">Daily P&L</div>
            <div className={`metric-value ${dailyPnL >= 0 ? 'positive' : 'negative'}`}>
              {dailyPnL >= 0 ? '+' : ''}{formatCurrency(dailyPnL)}
            </div>
          </div>
          
          <div className="metric-group">
            <div className="metric-label">Total P&L</div>
            <div className={`metric-value ${totalPnL >= 0 ? 'positive' : 'negative'}`}>
              {totalPnL >= 0 ? '+' : ''}{formatCurrency(totalPnL)}
            </div>
          </div>
          
          <div className="metric-group">
            <div className="metric-label">Buying Power</div>
            <div className="metric-value">{formatCurrency(buyingPower)}</div>
          </div>
          
          <div className="metric-group">
            <div className="metric-label">Cash Available</div>
            <div className="metric-value">{formatCurrency(cashAvailable)}</div>
          </div>
        </div>
        
        <div className="header-status">
          <div className="status-indicator">
            <span className={`status-dot ${marketStatus.color}`}></span>
            <span className="status-label">Market {marketStatus.status}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroDashboard;