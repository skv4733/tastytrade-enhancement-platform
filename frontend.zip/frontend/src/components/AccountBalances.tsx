import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { accountApi } from '../services/api';
import { ApiResponse, AccountBalancesResponse, AccountBalances as AccountBalancesData } from '../types/api';
import Tooltip from './Tooltip';
import { getDefinition } from '../utils/financialDefinitions';

const AccountBalances: React.FC = () => {
  const { accountNumber } = useParams<{ accountNumber: string }>();
  const navigate = useNavigate();
  const [balances, setBalances] = useState<AccountBalancesData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');
  const [activeFilter, setActiveFilter] = useState<string>('all');

  useEffect(() => {
    if (!accountNumber) {
      setError('No account number provided');
      setLoading(false);
      return;
    }

    const fetchBalances = async () => {
      try {
        setLoading(true);
        // Use the summary endpoint since individual endpoints work better
        const response = await accountApi.getAccountSummary();
        
        if (response.success && response.accounts) {
          // Find the account with matching account number
          const accountDetail = response.accounts.find((acc: any) => 
            acc.info && acc.info['account-number'] === accountNumber
          );
          
          if (accountDetail && accountDetail.balances && accountDetail.balances.data) {
            setBalances(accountDetail.balances.data);
          } else {
            setError(`Balances for account ${accountNumber} not found`);
          }
        } else {
          setError('Failed to fetch account balances');
        }
      } catch (err) {
        setError('Error fetching account balances: ' + (err as Error).message);
      } finally {
        setLoading(false);
      }
    };

    fetchBalances();
  }, [accountNumber]);

  const formatCurrency = (amount: number | string) => {
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(num || 0);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getFilteredBalanceRows = () => {
    if (!balances) return [];
    
    const allRows = [
      // Cash & Equity
      { category: 'cash-equity', type: 'section', label: 'Cash & Equity', key: 'cash-equity-header' },
      { category: 'cash-equity', type: 'row', label: 'Cash Balance', description: 'Available cash in account', value: balances['cash-balance'], key: 'cash-balance', definition: 'cash-balance' },
      { category: 'cash-equity', type: 'row', label: 'Long Equity Value', description: 'Value of long equity positions', value: balances['long-equity-value'], key: 'long-equity-value' },
      { category: 'cash-equity', type: 'row', label: 'Short Equity Value', description: 'Value of short equity positions', value: balances['short-equity-value'], key: 'short-equity-value' },
      { category: 'cash-equity', type: 'row', label: 'Margin Equity', description: 'Total equity including margin', value: balances['margin-equity'], key: 'margin-equity' },
      
      // Derivatives & Futures
      { category: 'derivatives', type: 'section', label: 'Derivatives & Futures', key: 'derivatives-header' },
      { category: 'derivatives', type: 'row', label: 'Long Derivative Value', description: 'Value of long derivative positions', value: balances['long-derivative-value'], key: 'long-derivative-value' },
      { category: 'derivatives', type: 'row', label: 'Short Derivative Value', description: 'Value of short derivative positions', value: balances['short-derivative-value'], key: 'short-derivative-value' },
      { category: 'derivatives', type: 'row', label: 'Long Futures Value', description: 'Value of long futures positions', value: balances['long-futures-value'], key: 'long-futures-value' },
      { category: 'derivatives', type: 'row', label: 'Short Futures Value', description: 'Value of short futures positions', value: balances['short-futures-value'], key: 'short-futures-value' },
      
      // Buying Power
      { category: 'cash-equity', type: 'section', label: 'Buying Power', key: 'buying-power-header' },
      { category: 'cash-equity', type: 'row', label: 'Equity Buying Power', description: 'Available power for equity trades', value: balances['equity-buying-power'], key: 'equity-buying-power' },
      { category: 'derivatives', type: 'row', label: 'Derivative Buying Power', description: 'Available power for derivative trades', value: balances['derivative-buying-power'], key: 'derivative-buying-power' },
      { category: 'derivatives', type: 'row', label: 'Used Derivative Power', description: 'Already used derivative buying power', value: balances['used-derivative-buying-power'], key: 'used-derivative-buying-power' },
      { category: 'cash-equity', type: 'row', label: 'Day Trading Power', description: 'Available power for day trading', value: balances['day-trading-buying-power'], key: 'day-trading-power' },
      
      // Requirements & Calls
      { category: 'requirements', type: 'section', label: 'Requirements & Calls', key: 'requirements-header' },
      { category: 'requirements', type: 'row', label: 'Maintenance Requirement', description: 'Required margin maintenance', value: balances['maintenance-requirement'], key: 'maintenance-requirement', definition: 'maintenance-requirement' },
      { category: 'requirements', type: 'row', label: 'Reg T Requirement', description: 'Regulation T margin requirement', value: balances['reg-t-margin-requirement'], key: 'reg-t-requirement', definition: 'reg-t-margin-requirement' },
      { category: 'requirements', type: 'row', label: 'Maintenance Excess', description: 'Excess above maintenance requirement', value: balances['maintenance-excess'], key: 'maintenance-excess', definition: 'maintenance-excess' },
      { category: 'requirements', type: 'row', label: 'Day Trade Excess', description: 'Excess day trading buying power', value: balances['day-trade-excess'], key: 'day-trade-excess' },
      
      // Other Assets
      { category: 'cash-equity', type: 'section', label: 'Other Assets', key: 'other-assets-header' },
      { category: 'cash-equity', type: 'row', label: 'Cryptocurrency Value', description: 'Long crypto positions', value: balances['long-cryptocurrency-value'], key: 'crypto-value' },
      { category: 'cash-equity', type: 'row', label: 'Bond Value', description: 'Long bond positions', value: balances['long-bond-value'], key: 'bond-value' },
      { category: 'cash-equity', type: 'row', label: 'Pending Cash', description: 'Cash pending settlement', value: balances['pending-cash'], key: 'pending-cash', definition: 'pending-cash' }
    ];
    
    if (activeFilter === 'all') return allRows;
    return allRows.filter(row => row.category === activeFilter);
  };

  if (loading) return <div className="loading">Loading account balances...</div>;
  if (error) return <div className="error">Error: {error}</div>;

  return (
    <div className="balances-dashboard">
      {/* Trading Dashboard Header */}
      <div className="trading-dashboard-header">
        <div className="header-background-pattern"></div>
        <div className="header-content-wrapper">
          <div className="dashboard-title-section">
            <div className="title-icon">💰</div>
            <div className="title-content">
              <h1>Account Balances</h1>
              <div className="account-info">
                <span className="account-badge">#{accountNumber}</span>
                <span className="live-indicator">
                  <span className="pulse-dot"></span>
                  Live Data
                </span>
              </div>
            </div>
          </div>
          <div className="header-actions">
            <button onClick={() => navigate(`/accounts/${accountNumber}`)} className="dashboard-btn secondary">
              ← Account Details
            </button>
            <button onClick={() => navigate(`/accounts/${accountNumber}/positions`)} className="dashboard-btn primary">
              📊 View Positions
            </button>
            <button onClick={() => navigate('/accounts')} className="dashboard-btn tertiary">
              🏦 All Accounts
            </button>
          </div>
        </div>
      </div>
      
      {balances ? (
        <div className="balances-content">
          {/* Portfolio Value Hero */}
          <div className="portfolio-value-hero">
            <div className="value-card primary">
              <div className="value-background"></div>
              <div className="value-content">
                <div className="value-header">
                  <div className="value-icon">📎</div>
                  <div className="value-title">
                    <h2>
                      Total Portfolio Value
                      <Tooltip content={getDefinition('net-liquidating-value')} position="auto">
                        <span className="help-icon">?</span>
                      </Tooltip>
                    </h2>
                    <span className="value-subtitle">Net Liquidating Value</span>
                  </div>
                </div>
                <div className="value-amount">
                  <span className="currency-symbol">$</span>
                  <span className="amount-value">{(balances['net-liquidating-value'] || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div className="value-indicators">
                  <div className="indicator positive">
                    <span className="indicator-icon">↑</span>
                    <span className="indicator-text">Available for Trading</span>
                    <span className="indicator-value">{formatCurrency(balances['equity-buying-power'] || 0)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Trading Power Dashboard */}
          <div className="trading-power-dashboard">
            <div className="section-title">
              <h2>Trading Power & Liquidity</h2>
              <div className="section-badge">Live</div>
            </div>
            <div className="power-cards-grid">
              <div className="power-card cash">
                <div className="card-gradient-bg cash-gradient"></div>
                <div className="power-header">
                  <div className="power-icon">💵</div>
                  <div className="power-info">
                    <h3>
                      Cash Available
                      <Tooltip content={getDefinition('cash-available')} position="auto">
                        <span className="help-icon">?</span>
                      </Tooltip>
                    </h3>
                    <span className="power-subtitle">Ready to withdraw</span>
                  </div>
                </div>
                <div className="power-value">{formatCurrency(balances['cash-available-to-withdraw'] || 0)}</div>
                <div className="power-progress">
                  <div className="progress-bar">
                    <div className="progress-fill cash-fill" style={{width: `${Math.min((balances['cash-available-to-withdraw'] || 0) / (balances['net-liquidating-value'] || 1) * 100, 100)}%`}}></div>
                  </div>
                  <span className="progress-text">{((balances['cash-available-to-withdraw'] || 0) / (balances['net-liquidating-value'] || 1) * 100).toFixed(1)}% of portfolio</span>
                </div>
              </div>
              
              <div className="power-card equity">
                <div className="card-gradient-bg equity-gradient"></div>
                <div className="power-header">
                  <div className="power-icon">⚡</div>
                  <div className="power-info">
                    <h3>
                      Equity Buying Power
                      <Tooltip content={getDefinition('equity-buying-power')} position="auto">
                        <span className="help-icon">?</span>
                      </Tooltip>
                    </h3>
                    <span className="power-subtitle">Stock purchases</span>
                  </div>
                </div>
                <div className="power-value">{formatCurrency(balances['equity-buying-power'] || 0)}</div>
                <div className="power-multiplier">
                  <span className="multiplier-badge">2x Leverage</span>
                </div>
              </div>
              
              <div className="power-card daytrading">
                <div className="card-gradient-bg daytrading-gradient"></div>
                <div className="power-header">
                  <div className="power-icon">🚀</div>
                  <div className="power-info">
                    <h3>
                      Day Trading Power
                      <Tooltip content={getDefinition('day-trading-buying-power')} position="auto">
                        <span className="help-icon">?</span>
                      </Tooltip>
                    </h3>
                    <span className="power-subtitle">Intraday trades</span>
                  </div>
                </div>
                <div className="power-value">{formatCurrency(balances['day-trading-buying-power'] || 0)}</div>
                <div className="power-multiplier">
                  <span className="multiplier-badge premium">4x Leverage</span>
                </div>
              </div>
              
              <div className="power-card margin">
                <div className="card-gradient-bg margin-gradient"></div>
                <div className="power-header">
                  <div className="power-icon">📊</div>
                  <div className="power-info">
                    <h3>
                      Margin Equity
                      <Tooltip content={getDefinition('margin-equity')} position="auto">
                        <span className="help-icon">?</span>
                      </Tooltip>
                    </h3>
                    <span className="power-subtitle">Total equity value</span>
                  </div>
                </div>
                <div className="power-value">{formatCurrency(balances['margin-equity'] || 0)}</div>
                <div className="power-indicator">
                  <span className={`status-badge ${balances['maintenance-excess'] > 0 ? 'healthy' : 'warning'}`}>
                    {balances['maintenance-excess'] > 0 ? 'Healthy' : 'Monitor'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Portfolio Allocation */}
          <div className="portfolio-allocation">
            <div className="allocation-header">
              <h2>Portfolio Allocation</h2>
              <div className="allocation-total">Total: {formatCurrency(balances['net-liquidating-value'] || 0)}</div>
            </div>
            <div className="allocation-visualization">
              <div className="allocation-chart">
                <div className="chart-segments">
                  <div className="segment cash" style={{width: `${((balances['cash-balance'] || 0) / (balances['net-liquidating-value'] || 1) * 100)}%`}} title="Cash"></div>
                  <div className="segment equity" style={{width: `${((balances['long-equity-value'] || 0) / (balances['net-liquidating-value'] || 1) * 100)}%`}} title="Equity"></div>
                  <div className="segment crypto" style={{width: `${((balances['long-cryptocurrency-value'] || 0) / (balances['net-liquidating-value'] || 1) * 100)}%`}} title="Crypto"></div>
                  <div className="segment bonds" style={{width: `${((balances['long-bond-value'] || 0) / (balances['net-liquidating-value'] || 1) * 100)}%`}} title="Bonds"></div>
                </div>
              </div>
              <div className="allocation-breakdown">
                <div className="breakdown-item cash">
                  <div className="breakdown-indicator cash-indicator"></div>
                  <div className="breakdown-info">
                    <span className="breakdown-label">Cash & Equivalents</span>
                    <span className="breakdown-value">{formatCurrency(balances['cash-balance'] || 0)}</span>
                    <span className="breakdown-percentage">{((balances['cash-balance'] || 0) / (balances['net-liquidating-value'] || 1) * 100).toFixed(1)}%</span>
                  </div>
                </div>
                
                <div className="breakdown-item equity">
                  <div className="breakdown-indicator equity-indicator"></div>
                  <div className="breakdown-info">
                    <span className="breakdown-label">Long Equity Positions</span>
                    <span className="breakdown-value">{formatCurrency(balances['long-equity-value'] || 0)}</span>
                    <span className="breakdown-percentage">{((balances['long-equity-value'] || 0) / (balances['net-liquidating-value'] || 1) * 100).toFixed(1)}%</span>
                  </div>
                </div>
                
                <div className="breakdown-item crypto">
                  <div className="breakdown-indicator crypto-indicator"></div>
                  <div className="breakdown-info">
                    <span className="breakdown-label">Cryptocurrency</span>
                    <span className="breakdown-value">{formatCurrency(balances['long-cryptocurrency-value'] || 0)}</span>
                    <span className="breakdown-percentage">{((balances['long-cryptocurrency-value'] || 0) / (balances['net-liquidating-value'] || 1) * 100).toFixed(1)}%</span>
                  </div>
                </div>
                
                <div className="breakdown-item bonds">
                  <div className="breakdown-indicator bonds-indicator"></div>
                  <div className="breakdown-info">
                    <span className="breakdown-label">Fixed Income</span>
                    <span className="breakdown-value">{formatCurrency(balances['long-bond-value'] || 0)}</span>
                    <span className="breakdown-percentage">{((balances['long-bond-value'] || 0) / (balances['net-liquidating-value'] || 1) * 100).toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Advanced Balance Details */}
          <div className="advanced-balance-details">
            <div className="details-header">
              <h2>Detailed Balance Breakdown</h2>
              <div className="details-filters">
                <button 
                  className={`filter-btn ${activeFilter === 'all' ? 'active' : ''}`}
                  onClick={() => setActiveFilter('all')}
                >
                  All Categories
                </button>
                <button 
                  className={`filter-btn ${activeFilter === 'cash-equity' ? 'active' : ''}`}
                  onClick={() => setActiveFilter('cash-equity')}
                >
                  Cash & Equity
                </button>
                <button 
                  className={`filter-btn ${activeFilter === 'derivatives' ? 'active' : ''}`}
                  onClick={() => setActiveFilter('derivatives')}
                >
                  Derivatives
                </button>
                <button 
                  className={`filter-btn ${activeFilter === 'requirements' ? 'active' : ''}`}
                  onClick={() => setActiveFilter('requirements')}
                >
                  Requirements
                </button>
              </div>
            </div>
            <div className="balance-details-grid">
              <table className="modern-balance-table">
              <thead>
                <tr>
                  <th>Category</th>
                  <th>Description</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                {getFilteredBalanceRows().map((row) => {
                  if (row.type === 'section') {
                    return (
                      <tr key={row.key} className="section-header">
                        <td colSpan={3}>{row.label}</td>
                      </tr>
                    );
                  }
                  
                  return (
                    <tr key={row.key}>
                      <td>
                        {row.label}
                        {row.definition && (
                          <Tooltip content={getDefinition(row.definition)} position="auto">
                            <span className="help-icon">?</span>
                          </Tooltip>
                        )}
                      </td>
                      <td>{row.description}</td>
                      <td>{formatCurrency(row.value || 0)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            </div>
          </div>
          
          {/* Risk Metrics */}
          <div className="risk-metrics">
            <div className="risk-header">
              <h2>Risk Management</h2>
              <div className="risk-status healthy">
                <span className="status-indicator"></span>
                Account Health: Good
              </div>
            </div>
            <div className="risk-cards">
              <div className="risk-card">
                <div className="risk-icon">🛡️</div>
                <div className="risk-content">
                  <h4>Maintenance Requirement</h4>
                  <div className="risk-value">{formatCurrency(balances['maintenance-requirement'] || 0)}</div>
                  <div className="risk-description">Required margin to hold positions</div>
                </div>
              </div>
              
              <div className="risk-card">
                <div className="risk-icon">📊</div>
                <div className="risk-content">
                  <h4>Maintenance Excess</h4>
                  <div className="risk-value positive">{formatCurrency(balances['maintenance-excess'] || 0)}</div>
                  <div className="risk-description">Buffer above minimum requirement</div>
                </div>
              </div>
              
              <div className="risk-card">
                <div className="risk-icon">⏱️</div>
                <div className="risk-content">
                  <h4>Last Updated</h4>
                  <div className="risk-value">{formatDate(balances['updated-at'])}</div>
                  <div className="risk-description">Data refresh timestamp</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div>No balance information available</div>
      )}
    </div>
  );
};

export default AccountBalances;