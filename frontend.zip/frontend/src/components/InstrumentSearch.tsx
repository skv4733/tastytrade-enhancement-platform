import React, { useState, useEffect, useMemo } from 'react';
import { instrumentsApi, Equity, Option, Future, InstrumentSearchParams, SymbolData } from '../services/instrumentsApi';

interface InstrumentSearchProps {
  onInstrumentSelect?: (instrument: any, type: 'equity' | 'option' | 'future' | 'crypto' | 'smart') => void;
}

const InstrumentSearch: React.FC<InstrumentSearchProps> = ({ onInstrumentSelect }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [instrumentType, setInstrumentType] = useState<'smart' | 'equity' | 'future' | 'crypto'>('smart');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [error, setError] = useState<string>('');
  const [showDetails, setShowDetails] = useState<any>(null);
  const [smartSearchResults, setSmartSearchResults] = useState<SymbolData[]>([]);
  const [currentFuturesResults, setCurrentFuturesResults] = useState<Future[]>([]);

  // Advanced filters
  const [lendability, setLendability] = useState<string>('');
  const [isEtf, setIsEtf] = useState<boolean | undefined>(undefined);
  const [isIndex, setIsIndex] = useState<boolean | undefined>(undefined);

  const searchInstruments = async () => {
    if (!searchTerm.trim()) {
      setResults([]);
      setSmartSearchResults([]);
      setCurrentFuturesResults([]);
      return;
    }

    setLoading(true);
    setError('');

    try {
      const trimmedSearch = searchTerm.trim();
      
      if (instrumentType === 'smart') {
        // Smart search: Use symbol search endpoint for fuzzy matching
        console.log('🧠 Using smart search for:', trimmedSearch);
        
        const symbolResponse = await instrumentsApi.searchSymbols(trimmedSearch);
        
        if (symbolResponse.success && symbolResponse.data?.data?.items) {
          const symbolData = symbolResponse.data.data.items;
          setSmartSearchResults(symbolData);
          
          // Convert SymbolData to appropriate format for display
          const convertedResults = symbolData.map(item => ({
            symbol: item.symbol,
            'instrument-type': item['instrument-type'],
            description: item.description,
            'short-description': item['short-description'],
            active: item.active,
            'is-closing-only': item['is-closing-only'],
            'product-code': item['product-code'],
            'is-etf': item['is-etf'],
            'is-index': item['is-index'],
            'root-symbol': item['root-symbol'],
          }));
          
          setResults(convertedResults);
          
          // If this looks like a futures root symbol (starts with /), also get current contracts
          if (trimmedSearch.startsWith('/') && trimmedSearch.length > 1) {
            try {
              const rootSymbol = trimmedSearch.substring(1); // Remove the /
              console.log('📈 Getting current futures contracts for root:', rootSymbol);
              const futuresResponse = await instrumentsApi.getCurrentFuturesContracts(rootSymbol);
              
              if (futuresResponse.success && futuresResponse.data?.data?.items) {
                setCurrentFuturesResults(futuresResponse.data.data.items);
              }
            } catch (futuresErr) {
              console.warn('Could not get current futures contracts:', futuresErr);
              // Don't fail the main search if futures lookup fails
            }
          }
        } else {
          setResults([]);
          setSmartSearchResults([]);
          setCurrentFuturesResults([]);
        }
      } else {
        // Traditional search for specific instrument types
        let response;
        const params: InstrumentSearchParams = {
          symbol: trimmedSearch,
        };

        switch (instrumentType) {
          case 'equity':
            params.lendability = lendability || undefined;
            params.isEtf = isEtf;
            params.isIndex = isIndex;
            response = await instrumentsApi.searchEquities(params);
            break;
          case 'future':
            response = await instrumentsApi.searchFutures(params);
            break;
          case 'crypto':
            response = await instrumentsApi.searchCryptocurrencies(params);
            break;
          default:
            throw new Error('Invalid instrument type');
        }

        if (response.success && response.data?.data?.items) {
          setResults(response.data.data.items);
        } else {
          setResults([]);
        }
      }
    } catch (err) {
      console.error('Error searching instruments:', err);
      setError('Failed to search instruments. Please try again.');
      setResults([]);
      setSmartSearchResults([]);
      setCurrentFuturesResults([]);
    } finally {
      setLoading(false);
    }
  };

  // Debounced search
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchTerm.trim()) {
        searchInstruments();
      } else {
        setResults([]);
        setSmartSearchResults([]);
        setCurrentFuturesResults([]);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchTerm, instrumentType, lendability, isEtf, isIndex]);

  const formatCurrency = (amount: string | number | undefined): string => {
    if (!amount) return 'N/A';
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(num);
  };

  const formatNumber = (num: string | number | undefined): string => {
    if (!num) return 'N/A';
    const value = typeof num === 'string' ? parseFloat(num) : num;
    return new Intl.NumberFormat('en-US').format(value);
  };

  const getInstrumentDisplayName = (instrument: any): string => {
    if (instrument.symbol) return instrument.symbol;
    return 'Unknown';
  };

  const getInstrumentDescription = (instrument: any): string => {
    return instrument.description || instrument['short-description'] || 'No description available';
  };

  const handleInstrumentClick = (instrument: any) => {
    setShowDetails(instrument);
    onInstrumentSelect?.(instrument, instrumentType);
  };

  const renderInstrumentDetails = (instrument: any) => {
    if (!showDetails) return null;

    return (
      <div className="instrument-details-modal">
        <div className="modal-overlay" onClick={() => setShowDetails(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{getInstrumentDisplayName(instrument)}</h3>
              <button className="modal-close" onClick={() => setShowDetails(null)}>×</button>
            </div>
            
            <div className="modal-body">
              <div className="detail-section">
                <h4>Basic Information</h4>
                <div className="detail-grid">
                  <div className="detail-item">
                    <span className="detail-label">Symbol:</span>
                    <span className="detail-value">{instrument.symbol}</span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Type:</span>
                    <span className="detail-value">{instrument['instrument-type']}</span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Description:</span>
                    <span className="detail-value">{getInstrumentDescription(instrument)}</span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Exchange:</span>
                    <span className="detail-value">{instrument.exchange || 'N/A'}</span>
                  </div>
                </div>
              </div>

              {instrumentType === 'equity' && (
                <div className="detail-section">
                  <h4>Equity Details</h4>
                  <div className="detail-grid">
                    <div className="detail-item">
                      <span className="detail-label">Is ETF:</span>
                      <span className="detail-value">{instrument['is-etf'] ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Is Index:</span>
                      <span className="detail-value">{instrument['is-index'] ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Lendability:</span>
                      <span className="detail-value">{instrument.lendability || 'N/A'}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Market Cap:</span>
                      <span className="detail-value">{formatCurrency(instrument['market-cap'])}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Shares Outstanding:</span>
                      <span className="detail-value">{formatNumber(instrument['shares-outstanding'])}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Borrow Rate:</span>
                      <span className="detail-value">{instrument['borrow-rate'] ? `${instrument['borrow-rate']}%` : 'N/A'}</span>
                    </div>
                  </div>
                </div>
              )}

              {instrumentType === 'future' && (
                <div className="detail-section">
                  <h4>Future Details</h4>
                  <div className="detail-grid">
                    <div className="detail-item">
                      <span className="detail-label">Product Code:</span>
                      <span className="detail-value">{instrument['product-code'] || 'N/A'}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Contract Size:</span>
                      <span className="detail-value">{instrument['contract-size'] || 'N/A'}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Tick Size:</span>
                      <span className="detail-value">{instrument['tick-size'] || 'N/A'}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Expiration Date:</span>
                      <span className="detail-value">{instrument['expiration-date'] || 'N/A'}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Days to Expiration:</span>
                      <span className="detail-value">{instrument['days-to-expiration'] || 'N/A'}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="detail-section">
                <h4>Trading Information</h4>
                <div className="detail-grid">
                  <div className="detail-item">
                    <span className="detail-label">Active:</span>
                    <span className={`detail-value ${instrument.active ? 'active' : 'inactive'}`}>
                      {instrument.active ? 'Yes' : 'No'}
                    </span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Closing Only:</span>
                    <span className="detail-value">{instrument['is-closing-only'] ? 'Yes' : 'No'}</span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Streamer Symbol:</span>
                    <span className="detail-value">{instrument['streamer-symbol'] || 'N/A'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="instrument-search">
      <div className="search-header">
        <h2>Instrument Search</h2>
        <p>Search for equities, futures, and cryptocurrencies</p>
      </div>

      <div className="search-controls">
        <div className="search-row-1">
          <div className="search-input-container">
            <input
              type="text"
              placeholder="Enter symbol (e.g., aapl, /es, aap for fuzzy match)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
            {instrumentType === 'smart' && (
              <div className="search-hint">
                💡 Smart search: Type any symbol (case-insensitive). Use "/" for futures (e.g., /es). Fuzzy matching enabled.
              </div>
            )}
          </div>
          
          <select
            value={instrumentType}
            onChange={(e) => setInstrumentType(e.target.value as any)}
            className="instrument-type-select"
          >
            <option value="smart">Smart Search (All)</option>
            <option value="equity">Equities Only</option>
            <option value="future">Futures Only</option>
            <option value="crypto">Cryptocurrency Only</option>
          </select>
        </div>

        {(instrumentType === 'equity' || instrumentType === 'smart') && (
          <div className="search-row-2">
            <select
              value={lendability}
              onChange={(e) => setLendability(e.target.value)}
              className="filter-select"
            >
              <option value="">All Lendability</option>
              <option value="Easy To Borrow">Easy To Borrow</option>
              <option value="Locate Required">Locate Required</option>
              <option value="Preborrow">Preborrow</option>
            </select>

            <select
              value={isEtf === undefined ? '' : isEtf.toString()}
              onChange={(e) => setIsEtf(e.target.value === '' ? undefined : e.target.value === 'true')}
              className="filter-select"
            >
              <option value="">All Securities</option>
              <option value="true">ETFs Only</option>
              <option value="false">Non-ETFs Only</option>
            </select>

            <select
              value={isIndex === undefined ? '' : isIndex.toString()}
              onChange={(e) => setIsIndex(e.target.value === '' ? undefined : e.target.value === 'true')}
              className="filter-select"
            >
              <option value="">All Types</option>
              <option value="true">Indexes Only</option>
              <option value="false">Non-Indexes Only</option>
            </select>
          </div>
        )}
      </div>

      {loading && (
        <div className="search-loading">
          <div className="loading-spinner"></div>
          <span>Searching instruments...</span>
        </div>
      )}

      {error && (
        <div className="search-error">
          <span className="error-icon">⚠️</span>
          <span>{error}</span>
        </div>
      )}

      {results.length > 0 && (
        <div className="search-results">
          <div className="results-header">
            <h3>Search Results ({results.length} found)</h3>
          </div>
          
          <div className="results-list">
            {results.map((instrument, index) => (
              <div
                key={`${instrument.symbol}-${index}`}
                className="result-item"
                onClick={() => handleInstrumentClick(instrument)}
              >
                <div className="result-main">
                  <div className="result-symbol">
                    <span className="symbol-name">{getInstrumentDisplayName(instrument)}</span>
                    <span className="symbol-type">{instrument['instrument-type']}</span>
                  </div>
                  <div className="result-info">
                    <span className="result-description">{getInstrumentDescription(instrument)}</span>
                    <div className="result-details">
                      <span className="result-exchange">{instrument.exchange || 'N/A'}</span>
                      <span className={`result-status ${instrument.active ? 'active' : 'inactive'}`}>
                        {instrument.active ? 'Active' : 'Inactive'}
                      </span>
                      {instrument['is-closing-only'] && (
                        <span className="result-closing-only">Closing Only</span>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="result-actions">
                  <button className="action-btn details">📋 Details</button>
                  <button className="action-btn trade">⚡ Trade</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {searchTerm && !loading && results.length === 0 && !error && (
        <div className="no-results">
          <div className="no-results-icon">🔍</div>
          <h3>No instruments found</h3>
          <p>Try a different symbol or adjust your filters</p>
        </div>
      )}

      {showDetails && renderInstrumentDetails(showDetails)}
    </div>
  );
};

export default InstrumentSearch;