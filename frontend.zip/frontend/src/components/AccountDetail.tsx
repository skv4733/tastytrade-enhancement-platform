import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { accountApi } from '../services/api';
import { ApiResponse, Account } from '../types/api';
import Tooltip from './Tooltip';
import { getDefinition } from '../utils/financialDefinitions';

const AccountDetail: React.FC = () => {
  const { accountNumber } = useParams<{ accountNumber: string }>();
  const navigate = useNavigate();
  const [account, setAccount] = useState<Account | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (!accountNumber) {
      setError('No account number provided');
      setLoading(false);
      return;
    }

    const fetchAccountInfo = async () => {
      try {
        setLoading(true);
        // Use the summary endpoint since individual account endpoints return null
        const response = await accountApi.getAccountSummary();
        
        if (response.success && response.accounts) {
          // Find the account with matching account number
          const accountDetail = response.accounts.find((acc: any) => 
            acc.info && acc.info['account-number'] === accountNumber
          );
          
          if (accountDetail && accountDetail.info) {
            setAccount(accountDetail.info);
          } else {
            setError(`Account ${accountNumber} not found`);
          }
        } else {
          setError('Failed to fetch account information');
        }
      } catch (err) {
        setError('Error fetching account information: ' + (err as Error).message);
      } finally {
        setLoading(false);
      }
    };

    fetchAccountInfo();
  }, [accountNumber]);

  if (loading) return <div className="loading">Loading account details...</div>;
  if (error) return <div className="error">Error: {error}</div>;

  const formatCurrency = (amount: number | string) => {
    if (!amount) return '$0.00';
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(num || 0);
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getAccountTypeIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'cash': return '💰';
      case 'margin': return '📊';
      case 'pdt': return '🚀';
      default: return '🏦';
    }
  };

  const getAccountStatusColor = (isClosed: boolean) => {
    return isClosed ? 'closed' : 'active';
  };

  const getAccountStatus = (isClosed: boolean) => {
    return isClosed ? 'Closed' : 'Active';
  };

  return (
    <div className="account-detail-dashboard">
      {/* Account Hero Header */}
      <div className="account-hero-header">
        <div className="hero-background-pattern"></div>
        <div className="hero-content-wrapper">
          <div className="account-title-section">
            <div className="account-icon-large">
              {getAccountTypeIcon(account?.['account-type-name'] || 'default')}
            </div>
            <div className="account-title-info">
              <h1>{account?.['nickname'] || `Account ${accountNumber}`}</h1>
              <div className="account-subtitle">
                <span className="account-type-badge">{account?.['account-type-name']}</span>
                <span className={`status-indicator ${getAccountStatusColor(account?.['is-closed'] || false)}`}>
                  {getAccountStatus(account?.['is-closed'] || false)}
                </span>
              </div>
            </div>
          </div>
          
          <div className="hero-actions">
            <button onClick={() => navigate(`/accounts/${accountNumber}/balances`)} className="hero-btn primary">
              💰 View Balances
            </button>
            <button onClick={() => navigate(`/accounts/${accountNumber}/positions`)} className="hero-btn secondary">
              📊 View Positions
            </button>
            <button onClick={() => navigate(`/accounts/${accountNumber}/transactions`)} className="hero-btn secondary">
              📋 View Transactions
            </button>
            <button onClick={() => navigate('/accounts')} className="hero-btn tertiary">
              ← All Accounts
            </button>
          </div>
        </div>
      </div>
      
      {account ? (
        <div className="account-detail-content">
          {/* Key Metrics Dashboard */}
          <div className="metrics-dashboard">
            <div className="metric-card primary">
              <div className="metric-icon">🆔</div>
              <div className="metric-content">
                <div className="metric-label">Account Number</div>
                <div className="metric-value">{account['account-number']}</div>
              </div>
            </div>
            
            <div className="metric-card secondary">
              <div className="metric-icon">📅</div>
              <div className="metric-content">
                <div className="metric-label">Account Age</div>
                <div className="metric-value">{account['opened-at'] ? Math.floor((Date.now() - new Date(account['opened-at']).getTime()) / (1000 * 60 * 60 * 24)) : 'N/A'} days</div>
              </div>
            </div>
            
            <div className="metric-card tertiary">
              <div className="metric-icon">{account['margin-or-cash']?.toLowerCase() === 'margin' ? '📊' : '💰'}</div>
              <div className="metric-content">
                <div className="metric-label">Trading Type</div>
                <div className="metric-value">{account['margin-or-cash']}</div>
              </div>
            </div>
            
            <div className="metric-card quaternary">
              <div className="metric-icon">{account['day-trader-status'] ? '🚀' : '📈'}</div>
              <div className="metric-content">
                <div className="metric-label">Day Trading</div>
                <div className="metric-value">{account['day-trader-status'] ? 'Enabled' : 'Standard'}</div>
              </div>
            </div>
          </div>

          {/* Trading Permissions Grid */}
          <div className="trading-permissions">
            <div className="section-header">
              <h2>Trading Permissions & Features</h2>
              <div className="section-icon">⚡</div>
            </div>
            <div className="permissions-grid">
              <div className={`permission-card ${account['day-trader-status'] ? 'enabled' : 'disabled'}`}>
                <div className="permission-icon">
                  <span className="icon-wrapper">{account['day-trader-status'] ? '🚀' : '📈'}</span>
                </div>
                <div className="permission-content">
                  <h4>
                    Day Trading
                    <Tooltip content="Pattern Day Trading allows unlimited day trades with 4x buying power." position="auto">
                      <span className="help-icon">?</span>
                    </Tooltip>
                  </h4>
                  <div className="permission-status">{account['day-trader-status'] ? 'Enabled' : 'Not Available'}</div>
                  <div className="permission-description">
                    {account['day-trader-status'] ? 'Full day trading capabilities' : 'Limited to 3 day trades per week'}
                  </div>
                </div>
              </div>
              
              <div className={`permission-card ${account['is-futures-approved'] ? 'enabled' : 'disabled'}`}>
                <div className="permission-icon">
                  <span className="icon-wrapper">{account['is-futures-approved'] ? '📈' : '🚫'}</span>
                </div>
                <div className="permission-content">
                  <h4>
                    Futures Trading
                    <Tooltip content={getDefinition('futures-trading')} position="auto">
                      <span className="help-icon">?</span>
                    </Tooltip>
                  </h4>
                  <div className="permission-status">{account['is-futures-approved'] ? 'Approved' : 'Not Approved'}</div>
                  <div className="permission-description">
                    {account['is-futures-approved'] ? 'Can trade futures contracts' : 'Futures trading not available'}
                  </div>
                </div>
              </div>
              
              <div className="permission-card enabled">
                <div className="permission-icon">
                  <span className="icon-wrapper">⚡</span>
                </div>
                <div className="permission-content">
                  <h4>
                    Options Level
                    <Tooltip content="Options trading level determines which strategies are available." position="auto">
                      <span className="help-icon">?</span>
                    </Tooltip>
                  </h4>
                  <div className="permission-status">Level {account['suitable-options-level'] || '0'}</div>
                  <div className="permission-description">
                    {account['suitable-options-level'] ? 'Advanced options strategies' : 'No options trading'}
                  </div>
                </div>
              </div>
              
              <div className={`permission-card ${account['margin-or-cash']?.toLowerCase() === 'margin' ? 'enabled' : 'disabled'}`}>
                <div className="permission-icon">
                  <span className="icon-wrapper">{account['margin-or-cash']?.toLowerCase() === 'margin' ? '📊' : '💰'}</span>
                </div>
                <div className="permission-content">
                  <h4>
                    Margin Trading
                    <Tooltip content={getDefinition('margin-equity')} position="auto">
                      <span className="help-icon">?</span>
                    </Tooltip>
                  </h4>
                  <div className="permission-status">{account['margin-or-cash']}</div>
                  <div className="permission-description">
                    {account['margin-or-cash']?.toLowerCase() === 'margin' ? 'Borrow against positions' : 'Use settled funds only'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Account Profile & Settings */}
          <div className="account-profile-section">
            <div className="profile-grid">
              <div className="profile-card">
                <div className="card-header">
                  <div className="card-icon">⚙️</div>
                  <h3>Account Settings</h3>
                </div>
                <div className="profile-details">
                  <div className="profile-item">
                    <span className="profile-label">Nickname</span>
                    <span className="profile-value">{account.nickname || 'Not set'}</span>
                  </div>
                  <div className="profile-item">
                    <span className="profile-label">External ID</span>
                    <span className="profile-value">{account['external-id'] || 'Not assigned'}</span>
                  </div>
                  <div className="profile-item">
                    <span className="profile-label">Risk Tolerance</span>
                    <span className="profile-value">{account['risk-tolerance'] || 'Not specified'}</span>
                  </div>
                  <div className="profile-item">
                    <span className="profile-label">Liquidity Needs</span>
                    <span className="profile-value">{account['liquidity-needs'] || 'Not specified'}</span>
                  </div>
                </div>
              </div>
              
              <div className="profile-card">
                <div className="card-header">
                  <div className="card-icon">🎯</div>
                  <h3>Investment Profile</h3>
                </div>
                <div className="profile-details">
                  <div className="profile-item">
                    <span className="profile-label">Investment Objective</span>
                    <span className="profile-value">{account['investment-objective'] || 'Not specified'}</span>
                  </div>
                  <div className="profile-item">
                    <span className="profile-label">Time Horizon</span>
                    <span className="profile-value">{account['time-horizon'] || 'Not specified'}</span>
                  </div>
                  <div className="profile-item">
                    <span className="profile-label">Account Category</span>
                    <span className="profile-value">{account['account-type-name']}</span>
                  </div>
                </div>
              </div>
              
              <div className="profile-card">
                <div className="card-header">
                  <div className="card-icon">📅</div>
                  <h3>Account Timeline</h3>
                </div>
                <div className="profile-details">
                  <div className="profile-item">
                    <span className="profile-label">Created</span>
                    <span className="profile-value">{formatDate(account['created-at'])}</span>
                  </div>
                  <div className="profile-item">
                    <span className="profile-label">Opened</span>
                    <span className="profile-value">{formatDate(account['opened-at'])}</span>
                  </div>
                  <div className="profile-item">
                    <span className="profile-label">Funded</span>
                    <span className="profile-value">{formatDate(account['funding-date'])}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Quick Actions Panel */}
          <div className="quick-actions-panel">
            <div className="section-header">
              <h2>Quick Actions</h2>
              <div className="section-icon">⚡</div>
            </div>
            <div className="actions-grid">
              <button onClick={() => navigate(`/accounts/${accountNumber}/balances`)} className="action-card">
                <div className="action-icon">💰</div>
                <div className="action-content">
                  <h4>Account Balances</h4>
                  <p>View cash, buying power, and portfolio value</p>
                </div>
                <div className="action-arrow">→</div>
              </button>
              
              <button onClick={() => navigate(`/accounts/${accountNumber}/positions`)} className="action-card">
                <div className="action-icon">📊</div>
                <div className="action-content">
                  <h4>Portfolio Positions</h4>
                  <p>See all holdings, P&L, and position details</p>
                </div>
                <div className="action-arrow">→</div>
              </button>
              
              <button onClick={() => navigate(`/accounts/${accountNumber}/transactions`)} className="action-card">
                <div className="action-icon">📋</div>
                <div className="action-content">
                  <h4>Transaction History</h4>
                  <p>View all trades, transfers, and account activity</p>
                </div>
                <div className="action-arrow">→</div>
              </button>
              
              <button onClick={() => navigate('/accounts')} className="action-card">
                <div className="action-icon">🏦</div>
                <div className="action-content">
                  <h4>All Accounts</h4>
                  <p>Return to complete accounts overview</p>
                </div>
                <div className="action-arrow">→</div>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="empty-state-dashboard">
          <div className="empty-background"></div>
          <div className="empty-content">
            <div className="empty-icon">🏦</div>
            <h2>Account Not Found</h2>
            <p>We couldn't load the details for account <strong>{accountNumber}</strong></p>
            <p>Please check the account number or try again later.</p>
            <button onClick={() => navigate('/accounts')} className="back-btn">
              ← Return to Accounts
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountDetail;