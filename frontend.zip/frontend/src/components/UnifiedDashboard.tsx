// Import React library and specific hooks for state management and side effects
import React, { useState, useEffect } from 'react';
// Import React Router hooks for navigation and URL management
import { useNavigate, useParams, useLocation } from 'react-router-dom';
// Import API service for making account-related requests
import { accountApi } from '../services/api';
// Import various component modules for different dashboard sections
import AccountSummary from './AccountSummary';
import CustomerInfo from './CustomerInfo';
import AccountsList from './AccountsList';
import AccountBalances from './AccountBalances';
import StreamlinedPositions from './StreamlinedPositions';
import AccountTransactions from './AccountTransactions';
import FinancialGlossary from './FinancialGlossary';
import HeroDashboard from './HeroDashboard';
import UnifiedTradingView from './UnifiedTradingView';

// Define TypeScript types for the main navigation tabs
type MainTab = 'summary' | 'customer' | 'accounts' | 'trading' | 'api-explorer' | 'help';
// Define TypeScript types for the account sub-tabs
type AccountTab = 'balances' | 'positions' | 'transactions';

// Define the structure of an Account object
interface Account {
  info: {
    'account-number': string;
    nickname: string;
    'account-type-name': string;
  };
}

// Main functional component definition
const UnifiedDashboard: React.FC = () => {
  // useNavigate hook - provides function to programmatically navigate to different routes
  const navigate = useNavigate();
  // useLocation hook - provides access to the current URL location object
  const location = useLocation();
  // useParams hook - extracts URL parameters, specifically the accountNumber from the route
  const { accountNumber: urlAccountNumber } = useParams<{ accountNumber: string }>();

  // useState hook - manages the currently active main tab, defaults to 'summary'
  const [activeMainTab, setActiveMainTab] = useState<MainTab>('summary');
  // useState hook - manages the currently active account sub-tab, defaults to 'balances'
  const [activeAccountTab, setActiveAccountTab] = useState<AccountTab>('balances');
  // useState hook - manages which account is currently selected (null means none selected)
  const [selectedAccount, setSelectedAccount] = useState<string | null>(null);
  // useState hook - stores the list of user accounts fetched from the API
  const [accounts, setAccounts] = useState<Account[]>([]);
  // useState hook - tracks whether data is currently being loaded
  const [loading, setLoading] = useState(true);
  // useState hook - stores the currently selected financial instrument symbol
  const [selectedInstrument, setSelectedInstrument] = useState<string>('SPY');

  // useEffect hook - runs once when component mounts to fetch account data
  useEffect(() => {
    fetchAccounts(); // Call function to load accounts from API
  }, []); // Empty dependency array means this only runs once on mount

  // useEffect hook - runs whenever the URL changes to update tab states
  useEffect(() => {
    // Get the current URL path
    const path = location.pathname;

    // Determine which main tab should be active based on the URL
    if (path === '/' || path === '/summary') {
      setActiveMainTab('summary'); // Set summary tab active for home or summary routes
    } else if (path === '/customer') {
      setActiveMainTab('customer'); // Set customer tab active for customer route
    } else if (path === '/trading' || path === '/instruments' || path === '/options') {
      setActiveMainTab('trading'); // Set trading tab active for trading/instruments/options routes
    } else if (path === '/api-explorer') {
      setActiveMainTab('api-explorer'); // Set api-explorer tab active for api-explorer route
    } else if (path === '/glossary') {
      setActiveMainTab('help'); // Set help tab active for glossary route
    } else if (path.startsWith('/accounts')) {
      setActiveMainTab('accounts'); // Set accounts tab active for any accounts route

      // Determine which account sub-tab should be active based on URL
      if (path.includes('/balances')) {
        setActiveAccountTab('balances'); // Set balances sub-tab if URL contains balances
      } else if (path.includes('/positions')) {
        setActiveAccountTab('positions'); // Set positions sub-tab if URL contains positions
      } else if (path.includes('/transactions')) {
        setActiveAccountTab('transactions'); // Set transactions sub-tab if URL contains transactions
      }

      // Extract and set the selected account from the URL parameter
      if (urlAccountNumber) {
        setSelectedAccount(urlAccountNumber); // Use account number from URL
      }
    }
  }, [location.pathname, urlAccountNumber]); // Re-run when URL path or account parameter changes

  // useEffect hook - automatically handles single account scenarios
  useEffect(() => {
    // If user has only one account and none is selected yet
    if (accounts.length === 1 && !selectedAccount) {
      // Get the account number of the single account
      const singleAccount = accounts[0].info['account-number'];
      setSelectedAccount(singleAccount); // Select that account
      // If currently on summary tab, redirect to the single account's balances page
      if (activeMainTab === 'summary') {
        setActiveMainTab('accounts'); // Switch to accounts tab
        navigate(`/accounts/${singleAccount}/balances`, { replace: true }); // Navigate to balances page
      }
    }
  }, [accounts, selectedAccount, activeMainTab, navigate]); // Re-run when these dependencies change

  // Async function to fetch account data from the API
  const fetchAccounts = async () => {
    try {
      setLoading(true); // Set loading state to true before API call
      // Make API call to get account summary data
      const response = await accountApi.getAccountSummary();
      // Check if the API call was successful and contains account data
      if (response.success && response.accounts) {
        setAccounts(response.accounts); // Update accounts state with fetched data
      }
    } catch (err) {
      // Log any errors that occur during the API call
      console.error('Error fetching accounts:', err);
    } finally {
      setLoading(false); // Always set loading to false when done (success or error)
    }
  };

  // Function to handle main tab navigation
  const handleMainTabChange = (tab: MainTab) => {
    setActiveMainTab(tab); // Update the active main tab state

    // Navigate to appropriate URL based on selected tab
    switch (tab) {
      case 'summary':
        navigate('/'); // Go to home page for summary
        break;
      case 'customer':
        navigate('/customer'); // Go to customer info page
        break;
      case 'trading':
        navigate('/trading'); // Go to unified trading page
        break;
      case 'accounts':
        // For accounts tab, navigate based on whether an account is selected
        if (selectedAccount) {
          navigate(`/accounts/${selectedAccount}/${activeAccountTab}`); // Go to specific account page
        } else {
          navigate('/accounts'); // Go to accounts list page
        }
        break;
      case 'api-explorer':
        navigate('/api-explorer'); // Go to API Explorer page
        break;
      case 'help':
        navigate('/glossary'); // Go to help/glossary page
        break;
    }
  };

  // Function to handle account sub-tab navigation
  const handleAccountTabChange = (tab: AccountTab) => {
    setActiveAccountTab(tab); // Update the active account sub-tab state
    // If an account is selected, navigate to that account's specific sub-tab page
    if (selectedAccount) {
      navigate(`/accounts/${selectedAccount}/${tab}`);
    }
  };

  // Function to handle selecting a specific account
  const handleAccountSelect = (accountNumber: string) => {
    setSelectedAccount(accountNumber); // Set the selected account
    setActiveMainTab('accounts'); // Switch to accounts main tab
    // Navigate to the selected account's current sub-tab page
    navigate(`/accounts/${accountNumber}/${activeAccountTab}`);
  };

  // Function that returns the appropriate React component based on current tab
  const renderMainTabContent = () => {
    switch (activeMainTab) {
      case 'summary':
        return <AccountSummary />; // Show account summary component
      case 'customer':
        return <CustomerInfo />; // Show customer information component
      case 'trading':
        // Unified trading view with instrument search and option chains
        return (
          <UnifiedTradingView 
            defaultSymbol={selectedInstrument}
          />
        );
      case 'accounts':
        // If an account is selected, show account dashboard
        if (selectedAccount) {
          return (
              <div className="account-dashboard-container">
                {/* Hero dashboard component for the selected account */}
                <HeroDashboard accountNumber={selectedAccount} />

                {/* Account selection dropdown - only show if user has multiple accounts */}
                {accounts.length > 1 && (
                    <div className="account-selector">
                      <label htmlFor="account-select">Select Account:</label>
                      <select
                          id="account-select"
                          value={selectedAccount}
                          onChange={(e) => handleAccountSelect(e.target.value)} // Handle account change
                          className="account-dropdown"
                      >
                        {/* Map through accounts to create dropdown options */}
                        {accounts.map((account) => (
                            <option key={account.info['account-number']} value={account.info['account-number']}>
                              {account.info.nickname || account.info['account-type-name']} - {account.info['account-number']}
                            </option>
                        ))}
                      </select>
                    </div>
                )}

                {/* Content area for account sub-tabs */}
                <div className="account-tab-content">
                  {/* Conditionally render components based on active account sub-tab */}
                  {activeAccountTab === 'balances' && <AccountBalances />}
                  {activeAccountTab === 'positions' && <StreamlinedPositions />}
                  {activeAccountTab === 'transactions' && <AccountTransactions />}
                </div>
              </div>
          );
        } else {
          // If no account selected, show accounts list
          return <AccountsList />;
        }
      case 'api-explorer':
        // Note: API Explorer is handled by separate route, this shouldn't be reached
        return <div>Redirecting to API Explorer...</div>;
      case 'help':
        return <FinancialGlossary />; // Show financial glossary/help component
      default:
        return <AccountSummary />; // Default fallback to account summary
    }
  };

  // Show loading screen while data is being fetched
  if (loading) {
    return (
        <div className="unified-dashboard">
          <div className="dashboard-loading">
            <div className="loading-icon">📊</div>
            <h2>Loading Dashboard</h2>
            <div className="loading-spinner"></div>
          </div>
        </div>
    );
  }

  // Main component render - the actual dashboard UI
  return (
      <div className="unified-dashboard">
        {/* Main Navigation Tabs */}
        <div className="main-navigation">
          <div className="main-tabs">
            {/* Summary tab button */}
            <button
                className={`main-tab ${activeMainTab === 'summary' ? 'active' : ''}`} // Add 'active' class if this tab is selected
                onClick={() => handleMainTabChange('summary')} // Handle tab click
            >
              📊 Summary
            </button>
            {/* Customer Info tab button */}
            <button
                className={`main-tab ${activeMainTab === 'customer' ? 'active' : ''}`}
                onClick={() => handleMainTabChange('customer')}
            >
              👤 Customer Info
            </button>
            {/* Accounts tab button - shows account number if single account is selected */}
            <button
                className={`main-tab ${activeMainTab === 'accounts' ? 'active' : ''}`}
                onClick={() => handleMainTabChange('accounts')}
            >
              🏦 {accounts.length === 1 && selectedAccount ? `Account ${selectedAccount}` : 'Accounts'}
            </button>
            {/* Trading tab button (combines instruments and options) */}
            <button
                className={`main-tab ${activeMainTab === 'trading' ? 'active' : ''}`}
                onClick={() => handleMainTabChange('trading')}
            >
              🎯 Trading
            </button>
            {/* API Explorer tab button */}
            <button
                className={`main-tab ${activeMainTab === 'api-explorer' ? 'active' : ''}`}
                onClick={() => handleMainTabChange('api-explorer')}
            >
              🔧 API Explorer
            </button>

            {/* Account Sub-tabs - Only show when accounts tab is active and account is selected */}
            {activeMainTab === 'accounts' && selectedAccount && (
                <>
                  {/* Visual separator between main tabs and sub-tabs */}
                  <div className="tab-separator">|</div>
                  {/* Balances sub-tab button */}
                  <button
                      className={`sub-tab ${activeAccountTab === 'balances' ? 'active' : ''}`}
                      onClick={() => handleAccountTabChange('balances')}
                  >
                    💰 Balances
                  </button>
                  {/* Positions sub-tab button */}
                  <button
                      className={`sub-tab ${activeAccountTab === 'positions' ? 'active' : ''}`}
                      onClick={() => handleAccountTabChange('positions')}
                  >
                    📊 Positions
                  </button>
                  {/* Transactions sub-tab button */}
                  <button
                      className={`sub-tab ${activeAccountTab === 'transactions' ? 'active' : ''}`}
                      onClick={() => handleAccountTabChange('transactions')}
                  >
                    📋 Transactions
                  </button>
                </>
            )}

            {/* Help/Glossary tab button */}
            <button
                className={`main-tab ${activeMainTab === 'help' ? 'active' : ''}`}
                onClick={() => handleMainTabChange('help')}
            >
              📖 Help
            </button>
          </div>
        </div>

        {/* Content Area - displays the component returned by renderMainTabContent() */}
        <div className="dashboard-content">
          {renderMainTabContent()}
        </div>
      </div>
  );
};

// Export the component as the default export
export default UnifiedDashboard;