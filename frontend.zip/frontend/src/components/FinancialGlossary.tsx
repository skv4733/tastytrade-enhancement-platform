import React, { useState } from 'react';
import { FINANCIAL_DEFINITIONS, getDefinitionsByCategory, FinancialTerm } from '../utils/financialDefinitions';

const FinancialGlossary: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<FinancialTerm['category']>('general');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = [
    { key: 'balance' as const, label: 'Balances & Cash', icon: '💰' },
    { key: 'buying_power' as const, label: 'Buying Power', icon: '⚡' },
    { key: 'margin' as const, label: 'Margin Trading', icon: '📊' },
    { key: 'position' as const, label: 'Positions', icon: '📈' },
    { key: 'general' as const, label: 'General Terms', icon: '📚' }
  ];

  const filteredDefinitions = Object.values(FINANCIAL_DEFINITIONS).filter(def => {
    const matchesCategory = selectedCategory === 'general' || def.category === selectedCategory;
    const matchesSearch = searchTerm === '' || 
                         def.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         def.definition.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="modern-glossary-dashboard">
      {/* Hero Header */}
      <div className="glossary-hero-header">
        <div className="hero-background-pattern"></div>
        <div className="hero-content-wrapper">
          <div className="glossary-title-section">
            <div className="title-icon-large">📚</div>
            <div className="title-content">
              <h1>Financial Knowledge Center</h1>
              <p>Master trading terminology and build your investment expertise</p>
              <div className="stats-row">
                <div className="stat-item">
                  <span className="stat-number">{Object.keys(FINANCIAL_DEFINITIONS).length}</span>
                  <span className="stat-label">Terms Explained</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{categories.length}</span>
                  <span className="stat-label">Categories</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">{filteredDefinitions.length}</span>
                  <span className="stat-label">Current Results</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Advanced Search & Filter Section */}
      <div className="glossary-search-section">
        <div className="search-container">
          <div className="advanced-search-box">
            <div className="search-icon-wrapper">
              <span className="search-icon">🔍</span>
            </div>
            <input
              type="text"
              placeholder="Search financial terms, definitions, or concepts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="advanced-search-input"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="clear-search-btn"
              >
                ✕
              </button>
            )}
          </div>
          
          <div className="search-suggestions">
            <span className="suggestion-label">Popular searches:</span>
            {['margin', 'buying power', 'options', 'futures', 'liquidation'].map(suggestion => (
              <button
                key={suggestion}
                onClick={() => setSearchTerm(suggestion)}
                className="suggestion-tag"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Category Navigation */}
      <div className="category-navigation">
        <div className="nav-header">
          <h2>Browse by Category</h2>
          <div className="results-counter">
            Showing {filteredDefinitions.length} of {Object.keys(FINANCIAL_DEFINITIONS).length} terms
          </div>
        </div>
        <div className="category-grid">
          {categories.map(category => {
            const categoryCount = Object.values(FINANCIAL_DEFINITIONS).filter(def => 
              category.key === 'general' || def.category === category.key
            ).length;
            
            return (
              <div
                key={category.key}
                className={`category-card ${selectedCategory === category.key ? 'active' : ''}`}
                onClick={() => setSelectedCategory(category.key)}
              >
                <div className="category-icon">{category.icon}</div>
                <div className="category-content">
                  <h3>{category.label}</h3>
                  <span className="category-count">{categoryCount} terms</span>
                </div>
                <div className="category-arrow">→</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Definition Results */}
      <div className="glossary-results-section">
        {filteredDefinitions.length > 0 ? (
          <div className="definitions-masonry">
            {filteredDefinitions.map((definition, index) => {
              const categoryInfo = categories.find(cat => cat.key === definition.category);
              return (
                <div key={index} className={`definition-card modern ${definition.category}`}>
                  <div className="card-header">
                    <div className="term-icon">{categoryInfo?.icon || '💼'}</div>
                    <div className="term-meta">
                      <span className={`category-badge ${definition.category}`}>
                        {categoryInfo?.label || definition.category}
                      </span>
                    </div>
                  </div>
                  <div className="card-content">
                    <h3 className="term-title">{definition.term}</h3>
                    <p className="term-definition">{definition.definition}</p>
                  </div>
                  <div className="card-footer">
                    <div className="term-tags">
                      <span className="usage-tag">Trading</span>
                      {definition.category === 'margin' && <span className="usage-tag">Risk</span>}
                      {definition.category === 'buying_power' && <span className="usage-tag">Leverage</span>}
                    </div>
                    <button className="learn-more-btn">Learn More</button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="no-results-state">
            <div className="empty-state-illustration">
              <div className="search-illustration">🔍</div>
              <div className="floating-terms">
                <span className="term-bubble">Margin</span>
                <span className="term-bubble">Options</span>
                <span className="term-bubble">Futures</span>
              </div>
            </div>
            <div className="empty-state-content">
              <h3>No matches found</h3>
              <p>We couldn't find any terms matching "{searchTerm}"</p>
              <div className="suggestion-actions">
                <button 
                  onClick={() => setSearchTerm('')}
                  className="action-btn primary"
                >
                  Clear Search
                </button>
                <button 
                  onClick={() => setSelectedCategory('general')}
                  className="action-btn secondary"
                >
                  Browse All Categories
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Help Section */}
      <div className="glossary-help-section">
        <div className="help-card">
          <div className="help-icon">💡</div>
          <div className="help-content">
            <h3>Need More Help?</h3>
            <p>Can't find the term you're looking for? Our knowledge base is constantly growing.</p>
            <button className="contact-btn">Request a Definition</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialGlossary;