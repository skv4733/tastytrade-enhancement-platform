import React, { useState } from 'react';
import {
  Box,
  Button,
  TextField,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Chip,
  Paper,
  Alert
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ResponseViewer from './ResponseViewer';

interface ApiEndpoint {
  name: string;
  method: 'GET' | 'POST' | 'PATCH' | 'DELETE';
  path: string;
  description: string;
  buttonText?: string;
  parameters?: Array<{
    name: string;
    type: 'path' | 'query' | 'body';
    required: boolean;
    description: string;
    example?: string;
    defaultValue?: string;
  }>;
  apiCall: (params: any) => Promise<any>;
}

interface ApiTestComponentProps {
  endpoints: ApiEndpoint[];
  title: string;
}

const ApiTestComponent: React.FC<ApiTestComponentProps> = ({ endpoints, title }) => {
  const [results, setResults] = useState<{ [key: string]: any }>({});
  const [loading, setLoading] = useState<{ [key: string]: boolean }>({});
  const [error, setError] = useState<{ [key: string]: string }>({});
  const [params, setParams] = useState<{ [key: string]: any }>({});

  const handleParamChange = (endpointName: string, paramName: string, value: string) => {
    setParams(prev => ({
      ...prev,
      [endpointName]: {
        ...prev[endpointName],
        [paramName]: value
      }
    }));
  };

  const getDefaultValue = (endpoint: ApiEndpoint, param: any) => {
    if (params[endpoint.name]?.[param.name] !== undefined) {
      return params[endpoint.name][param.name];
    }
    if (param.defaultValue) {
      return param.defaultValue;
    }
    if (param.name === 'accountNumber' || param.name === 'account-number') {
      return '5WZ51117';
    }
    return param.example || '';
  };

  const handleApiCall = async (endpoint: ApiEndpoint) => {
    const key = endpoint.name;
    setLoading(prev => ({ ...prev, [key]: true }));
    setError(prev => ({ ...prev, [key]: '' }));
    
    try {
      // Build parameters with default values if not explicitly set
      const endpointParams = params[key] || {};
      const finalParams: any = {};
      
      if (endpoint.parameters) {
        endpoint.parameters.forEach(param => {
          if (endpointParams[param.name] !== undefined) {
            finalParams[param.name] = endpointParams[param.name];
          } else {
            finalParams[param.name] = getDefaultValue(endpoint, param);
          }
        });
      }
      
      const result = await endpoint.apiCall(finalParams);
      setResults(prev => ({ ...prev, [key]: result }));
    } catch (err: any) {
      setError(prev => ({ ...prev, [key]: err.message || 'An error occurred' }));
    } finally {
      setLoading(prev => ({ ...prev, [key]: false }));
    }
  };

  const getMethodColor = (method: string) => {
    switch (method) {
      case 'GET': return 'success';
      case 'POST': return 'primary';
      case 'PATCH': return 'warning';
      case 'DELETE': return 'error';
      default: return 'default';
    }
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        {title}
      </Typography>
      
      {endpoints.map((endpoint) => (
        <Accordion key={endpoint.name} sx={{ mb: 2, boxShadow: 2 }}>
          <AccordionSummary 
            expandIcon={<ExpandMoreIcon />}
            sx={{ 
              backgroundColor: 'rgba(25, 118, 210, 0.04)',
              '&:hover': { backgroundColor: 'rgba(25, 118, 210, 0.08)' }
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
              <Chip 
                label={endpoint.method} 
                color={getMethodColor(endpoint.method) as any}
                size="small"
                sx={{ fontWeight: 'bold' }}
              />
              <Typography variant="h6" sx={{ fontWeight: 'medium' }}>
                {endpoint.name}
              </Typography>
              <Typography 
                variant="body2" 
                color="text.secondary" 
                sx={{ ml: 'auto', fontFamily: 'monospace' }}
              >
                {endpoint.path}
              </Typography>
            </Box>
          </AccordionSummary>
          
          <AccordionDetails>
            <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 3 }}>
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography variant="body2" gutterBottom>
                  {endpoint.description}
                </Typography>
                
                {endpoint.parameters && endpoint.parameters.length > 0 && (
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Parameters:
                    </Typography>
                    {endpoint.parameters.map((param) => (
                      <Box key={param.name} sx={{ mb: 2 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label={`${param.name}${param.required ? ' *' : ''}`}
                          placeholder={param.example || param.description}
                          required={param.required}
                          value={getDefaultValue(endpoint, param)}
                          onChange={(e) => handleParamChange(endpoint.name, param.name, e.target.value)}
                          helperText={param.description}
                          variant="outlined"
                          sx={{ 
                            '& .MuiOutlinedInput-root': {
                              '&:hover fieldset': { borderColor: 'primary.main' }
                            }
                          }}
                        />
                      </Box>
                    ))}
                  </Box>
                )}
                
                <Button
                  variant="contained"
                  onClick={() => handleApiCall(endpoint)}
                  disabled={loading[endpoint.name]}
                  sx={{ 
                    mt: 2, 
                    px: 3, 
                    py: 1,
                    fontWeight: 'medium',
                    borderRadius: 2,
                    textTransform: 'none'
                  }}
                >
                  {loading[endpoint.name] ? 'Loading...' : (endpoint.buttonText || `Get ${endpoint.name}`)}
                </Button>
                
                {error[endpoint.name] && (
                  <Alert severity="error" sx={{ mt: 2 }}>
                    {error[endpoint.name]}
                  </Alert>
                )}
              </Box>
              
              <Box sx={{ flex: 1, minWidth: 0 }}>
                {results[endpoint.name] && (
                  <Box sx={{ maxHeight: 500, overflow: 'auto' }}>
                    <ResponseViewer 
                      data={results[endpoint.name]} 
                      endpointName={endpoint.name}
                    />
                  </Box>
                )}
              </Box>
            </Box>
          </AccordionDetails>
        </Accordion>
      ))}
    </Box>
  );
};

export default ApiTestComponent;