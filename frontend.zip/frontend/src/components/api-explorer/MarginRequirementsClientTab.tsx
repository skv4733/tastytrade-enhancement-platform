import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { marginRequirementsApi } from '../../services/unifiedTestingApi';

const MarginRequirementsClientTab: React.FC = () => {
  const endpoints = [
    // ===== MARGIN REQUIREMENTS =====
    {
      name: 'Get Margin Requirements',
      method: 'GET' as const,
      path: '/margin/accounts/{accountNumber}/requirements',
      description: 'Get margin requirements for an account with optional filters',
      buttonText: '📊 Get Margin Requirements',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'instrument-type',
          type: 'query' as const,
          required: false,
          description: 'Filter by instrument type',
          example: 'Equity'
        },
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Filter by symbol',
          example: 'AAPL'
        },
        {
          name: 'include-zero-requirements',
          type: 'query' as const,
          required: false,
          description: 'Include zero margin requirements',
          example: 'true'
        }
      ],
      apiCall: async (params: any) => {
        const { accountNumber, ...queryParams } = params;
        const cleanParams = Object.fromEntries(
          Object.entries(queryParams).filter(([_, value]) => value !== '')
        );
        const response = await marginRequirementsApi.getMarginRequirements(accountNumber, cleanParams);
        return response.data;
      }
    },
    {
      name: 'Get Symbol Margin Requirements',
      method: 'GET' as const,
      path: '/margin/accounts/{accountNumber}/requirements/symbol/{symbol}',
      description: 'Get margin requirements for a specific symbol',
      buttonText: '🎯 Get Symbol Margin Requirements',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Symbol to get margin requirements for',
          example: 'AAPL',
          defaultValue: 'AAPL'
        },
        {
          name: 'quantity',
          type: 'query' as const,
          required: false,
          description: 'Quantity for margin calculation',
          example: '100'
        },
        {
          name: 'side',
          type: 'query' as const,
          required: false,
          description: 'Position side',
          example: 'Long'
        }
      ],
      apiCall: async (params: any) => {
        const { accountNumber, symbol, ...queryParams } = params;
        const cleanParams = Object.fromEntries(
          Object.entries(queryParams).filter(([_, value]) => value !== '')
        );
        const response = await marginRequirementsApi.getSymbolMarginRequirements(accountNumber, symbol, cleanParams);
        return response.data;
      }
    },

    // ===== MARGIN CALCULATIONS =====
    {
      name: 'Calculate Margin Requirements',
      method: 'POST' as const,
      path: '/margin/accounts/{accountNumber}/calculate',
      description: 'Calculate margin requirements for a potential position',
      buttonText: '🧮 Calculate Margin Requirements',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'marginCalculationRequest',
          type: 'body' as const,
          required: true,
          description: 'Margin calculation request body',
          example: '{"positions": [{"symbol": "AAPL", "quantity": 100, "instrument-type": "Equity"}]}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marginRequirementsApi.calculateMarginRequirements(params.accountNumber, JSON.parse(params.marginCalculationRequest));
        return response.data;
      }
    },
    {
      name: 'Perform Margin Dry Run',
      method: 'POST' as const,
      path: '/margin/accounts/{accountNumber}/dry-run',
      description: 'Perform a margin dry run calculation',
      buttonText: '🔍 Perform Margin Dry Run',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'marginDryRunRequest',
          type: 'body' as const,
          required: true,
          description: 'Margin dry run request body',
          example: '{"orders": [{"legs": [{"instrument-type": "Equity", "symbol": "AAPL", "action": "Buy To Open", "quantity": 100}], "time-in-force": "Day", "order-type": "Market"}]}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marginRequirementsApi.performMarginDryRun(params.accountNumber, JSON.parse(params.marginDryRunRequest));
        return response.data;
      }
    },

    // ===== MARGIN UTILIZATION =====
    {
      name: 'Get Margin Utilization',
      method: 'GET' as const,
      path: '/margin/accounts/{accountNumber}/utilization',
      description: 'Get current margin utilization for an account',
      buttonText: '📈 Get Margin Utilization',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marginRequirementsApi.getMarginUtilization(params.accountNumber);
        return response.data;
      }
    },
    {
      name: 'Get Margin Utilization History',
      method: 'GET' as const,
      path: '/utilization/history',
      description: 'Get margin utilization history',
      buttonText: '📊 Get Margin Utilization History',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'from-date',
          type: 'query' as const,
          required: false,
          description: 'From date (YYYY-MM-DD)',
          example: '2025-01-01'
        },
        {
          name: 'to-date',
          type: 'query' as const,
          required: false,
          description: 'To date (YYYY-MM-DD)',
          example: '2025-12-31'
        },
        {
          name: 'granularity',
          type: 'query' as const,
          required: false,
          description: 'Data granularity',
          example: 'Daily'
        }
      ],
      apiCall: async (params: any) => {
        const { accountNumber, ...queryParams } = params;
        const cleanParams = Object.fromEntries(
          Object.entries(queryParams).filter(([_, value]) => value !== '')
        );
        const response = await marginRequirementsApi.getMarginUtilizationHistory(accountNumber, cleanParams);
        return response.data;
      }
    },

    // ===== PORTFOLIO MARGIN =====
    {
      name: 'Get Portfolio Margin Requirements',
      method: 'GET' as const,
      path: '/margin/accounts/{accountNumber}/portfolio-margin',
      description: 'Get portfolio margin requirements for an account',
      buttonText: '💼 Get Portfolio Margin Requirements',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marginRequirementsApi.getPortfolioMarginRequirements(params.accountNumber);
        return response.data;
      }
    },
    {
      name: 'Perform Portfolio Margin Dry Run',
      method: 'POST' as const,
      path: '/portfolio-margin/dry-run',
      description: 'Perform a portfolio margin dry run calculation',
      buttonText: '🔍 Portfolio Margin Dry Run',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'portfolioMarginRequest',
          type: 'body' as const,
          required: true,
          description: 'Portfolio margin dry run request body',
          example: '{"portfolio-scenarios": [{"positions": [{"symbol": "AAPL", "quantity": 100, "instrument-type": "Equity"}]}]}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marginRequirementsApi.performPortfolioMarginDryRun(params.accountNumber, JSON.parse(params.portfolioMarginRequest));
        return response.data;
      }
    },

    // ===== MARGIN ALERTS & STATUS =====
    {
      name: 'Get Margin Alerts',
      method: 'GET' as const,
      path: '/alerts',
      description: 'Get margin alerts for an account',
      buttonText: '🚨 Get Margin Alerts',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'status',
          type: 'query' as const,
          required: false,
          description: 'Alert status filter',
          example: 'Active'
        },
        {
          name: 'alert-type',
          type: 'query' as const,
          required: false,
          description: 'Alert type filter',
          example: 'Margin Call'
        }
      ],
      apiCall: async (params: any) => {
        const { accountNumber, ...queryParams } = params;
        const cleanParams = Object.fromEntries(
          Object.entries(queryParams).filter(([_, value]) => value !== '')
        );
        const response = await marginRequirementsApi.getMarginAlerts(accountNumber, cleanParams);
        return response.data;
      }
    },
    {
      name: 'Get Margin Call Status',
      method: 'GET' as const,
      path: '/margin-call',
      description: 'Get current margin call status for an account',
      buttonText: '📞 Get Margin Call Status',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marginRequirementsApi.getMarginCallStatus(params.accountNumber);
        return response.data;
      }
    },

    // ===== MARGIN CONFIGURATION =====
    {
      name: 'Get Margin Configuration',
      method: 'GET' as const,
      path: '/configuration',
      description: 'Get margin configuration and rules for an account',
      buttonText: '⚙️ Get Margin Configuration',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marginRequirementsApi.getMarginConfiguration(params.accountNumber);
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Margin Requirements"
      endpoints={endpoints}
    />
  );
};

export default MarginRequirementsClientTab;