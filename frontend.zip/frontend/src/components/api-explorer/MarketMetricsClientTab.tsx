import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { marketMetricsApi } from '../../services/unifiedTestingApi';

const MarketMetricsClientTab: React.FC = () => {
  const endpoints = [
    {
      name: 'Market Analytics',
      method: 'GET' as const,
      path: '/market-metrics',
      description: 'View implied volatility, liquidity rankings, and trading volume for stocks',
      buttonText: 'Get Market Analytics',
      parameters: [
        {
          name: 'symbols',
          type: 'query' as const,
          required: false,
          description: 'Stock symbols to analyze (comma-separated)',
          example: 'AAPL,MSFT,GOOGL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marketMetricsApi.getMarketMetrics(params.symbols || 'AAPL');
        return response.data;
      }
    },
    {
      name: 'Dividend History',
      method: 'GET' as const,
      path: '/market-metrics/historic-corporate-events/dividends/{symbol}',
      description: 'View dividend payment history, yields, and upcoming dividend dates',
      buttonText: 'Get Dividend History',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Stock symbol to check dividend history',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marketMetricsApi.getDividendHistory(params.symbol || 'AAPL');
        return response.data;
      }
    },
    {
      name: 'Earnings Reports',
      method: 'GET' as const,
      path: '/market-metrics/historic-corporate-events/earnings-reports/{symbol}',
      description: 'View historical earnings results, estimates, and surprises',
      buttonText: 'Get Earnings History',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Stock symbol to check earnings history',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marketMetricsApi.getEarningsReportHistory(params.symbol || 'AAPL');
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Market Analytics & Research"
      endpoints={endpoints}
    />
  );
};

export default MarketMetricsClientTab;