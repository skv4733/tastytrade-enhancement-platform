import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { marketTimeApi } from '../../services/unifiedTestingApi';

const MarketTimeClientTab: React.FC = () => {
  const endpoints = [
    // ===== MARKET STATUS & CALENDAR =====
    {
      name: 'Market Status',
      method: 'GET' as const,
      path: '/market-time/status',
      description: 'Check if markets are currently open or closed',
      buttonText: '🕒 Check Market Status',
      apiCall: async () => {
        const response = await marketTimeApi.getMarketStatus();
        return response.data;
      }
    },
    {
      name: 'Trading Calendar',
      method: 'GET' as const,
      path: '/market-time/calendar',
      description: 'View market schedule and trading days for specific date ranges',
      buttonText: '📅 Get Trading Calendar',
      parameters: [
        {
          name: 'from-date',
          type: 'query' as const,
          required: false,
          description: 'Start date for calendar (YYYY-MM-DD)',
          example: '2025-01-01'
        },
        {
          name: 'to-date',
          type: 'query' as const,
          required: false,
          description: 'End date for calendar (YYYY-MM-DD)',
          example: '2025-12-31'
        },
        {
          name: 'instrument-collection',
          type: 'query' as const,
          required: false,
          description: 'Market collection (e.g., CME, NYSE)',
          example: 'NYSE'
        }
      ],
      apiCall: async (params: any) => {
        const cleanParams = Object.fromEntries(
          Object.entries(params).filter(([_, value]) => value !== '')
        );
        const response = await marketTimeApi.getTradingCalendar(cleanParams);
        return response.data;
      }
    },
    {
      name: 'Extended Hours Trading',
      method: 'GET' as const,
      path: '/market-time/extended-hours/current',
      description: 'Check current extended hours trading availability',
      buttonText: '🌙 Check Extended Hours',
      apiCall: async () => {
        const response = await marketTimeApi.getCurrentExtendedHours();
        return response.data;
      }
    },

    // ===== MARKET SESSIONS =====
    {
      name: 'Get Market Sessions',
      method: 'GET' as const,
      path: '/market-time/sessions',
      description: 'Get market sessions with optional date and instrument filters',
      buttonText: '📊 Get Market Sessions',
      parameters: [
        {
          name: 'from-date',
          type: 'query' as const,
          required: false,
          description: 'Start date (YYYY-MM-DD)',
          example: '2025-01-01'
        },
        {
          name: 'to-date',
          type: 'query' as const,
          required: false,
          description: 'End date (YYYY-MM-DD)',
          example: '2025-01-31'
        },
        {
          name: 'instrument-collection',
          type: 'query' as const,
          required: false,
          description: 'Instrument collection filter',
          example: 'NYSE'
        }
      ],
      apiCall: async (params: any) => {
        const cleanParams = Object.fromEntries(
          Object.entries(params).filter(([_, value]) => value !== '')
        );
        const response = await marketTimeApi.getMarketSessions(cleanParams);
        return response.data;
      }
    },
    {
      name: 'Current Market Sessions',
      method: 'GET' as const,
      path: '/market-time/sessions/current',
      description: 'View currently active trading sessions',
      buttonText: '🔴 Get Current Sessions',
      parameters: [
        {
          name: 'instrument-collections',
          type: 'query' as const,
          required: false,
          description: 'Filter by market collections',
          example: 'NYSE,NASDAQ'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marketTimeApi.getCurrentMarketSessions(params['instrument-collections']);
        return response.data;
      }
    },
    {
      name: 'All Market Sessions',
      method: 'GET' as const,
      path: '/market-time/sessions/all',
      description: 'Get all market sessions',
      buttonText: '📋 Get All Market Sessions',
      apiCall: async () => {
        const response = await marketTimeApi.getAllMarketSessions();
        return response.data;
      }
    },

    // ===== EQUITY SESSIONS =====
    {
      name: 'Current Equity Session',
      method: 'GET' as const,
      path: '/market-time/equities/sessions/current',
      description: 'Current stock market trading session information',
      buttonText: '📈 Get Current Equity Session',
      apiCall: async () => {
        const response = await marketTimeApi.getCurrentEquitySession();
        return response.data;
      }
    },
    {
      name: 'Next Equity Session',
      method: 'GET' as const,
      path: '/market-time/equities/sessions/next',
      description: 'Information about the next stock trading session',
      buttonText: '⏭️ Get Next Equity Session',
      apiCall: async () => {
        const response = await marketTimeApi.getNextEquitySession();
        return response.data;
      }
    },
    {
      name: 'Previous Equity Session',
      method: 'GET' as const,
      path: '/market-time/equities/sessions/previous',
      description: 'Information about the previous stock trading session',
      buttonText: '⏮️ Get Previous Equity Session',
      apiCall: async () => {
        const response = await marketTimeApi.getPreviousEquitySession();
        return response.data;
      }
    },
    {
      name: 'Equity Holidays',
      method: 'GET' as const,
      path: '/market-time/equities/holidays',
      description: 'View stock market holidays and closure dates',
      buttonText: '🏖️ Get Equity Holidays',
      parameters: [
        {
          name: 'from-date',
          type: 'query' as const,
          required: false,
          description: 'Start date for holidays (YYYY-MM-DD)',
          example: '2025-01-01'
        },
        {
          name: 'to-date',
          type: 'query' as const,
          required: false,
          description: 'End date for holidays (YYYY-MM-DD)',
          example: '2025-12-31'
        }
      ],
      apiCall: async (params: any) => {
        const cleanParams = Object.fromEntries(
          Object.entries(params).filter(([_, value]) => value !== '')
        );
        const response = await marketTimeApi.getEquityHolidays(cleanParams);
        return response.data;
      }
    },

    // ===== FUTURES SESSIONS =====
    {
      name: 'Current Futures Session',
      method: 'GET' as const,
      path: '/market-time/futures/sessions/current',
      description: 'Current futures trading session information',
      buttonText: '📊 Get Current Futures Session',
      apiCall: async () => {
        const response = await marketTimeApi.getCurrentFuturesSession();
        return response.data;
      }
    },
    {
      name: 'Current Futures Session by Collection',
      method: 'GET' as const,
      path: '/market-time/futures/sessions/current/{instrumentCollection}',
      description: 'Current futures session for specific instrument collection',
      buttonText: '🏢 Get Current Futures Session (By Collection)',
      parameters: [
        {
          name: 'instrumentCollection',
          type: 'path' as const,
          required: true,
          description: 'Instrument collection (e.g., CME, NYMEX)',
          example: 'CME',
          defaultValue: 'CME'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marketTimeApi.getCurrentFuturesSessionByCollection(params.instrumentCollection);
        return response.data;
      }
    },
    {
      name: 'Previous Futures Session by Collection',
      method: 'GET' as const,
      path: '/market-time/futures/sessions/previous/{instrumentCollection}',
      description: 'Previous futures session for specific instrument collection',
      buttonText: '⏮️ Get Previous Futures Session (By Collection)',
      parameters: [
        {
          name: 'instrumentCollection',
          type: 'path' as const,
          required: true,
          description: 'Instrument collection (e.g., CME, NYMEX)',
          example: 'CME',
          defaultValue: 'CME'
        }
      ],
      apiCall: async (params: any) => {
        const response = await marketTimeApi.getPreviousFuturesSessionByCollection(params.instrumentCollection);
        return response.data;
      }
    },
    {
      name: 'Futures Holidays by Collection',
      method: 'GET' as const,
      path: '/market-time/futures/holidays/{instrumentCollection}',
      description: 'View futures market holidays for specific collection',
      buttonText: '🏖️ Get Futures Holidays (By Collection)',
      parameters: [
        {
          name: 'instrumentCollection',
          type: 'path' as const,
          required: true,
          description: 'Instrument collection (e.g., CME, NYMEX)',
          example: 'CME',
          defaultValue: 'CME'
        },
        {
          name: 'from-date',
          type: 'query' as const,
          required: false,
          description: 'Start date for holidays (YYYY-MM-DD)',
          example: '2025-01-01'
        },
        {
          name: 'to-date',
          type: 'query' as const,
          required: false,
          description: 'End date for holidays (YYYY-MM-DD)',
          example: '2025-12-31'
        }
      ],
      apiCall: async (params: any) => {
        const { instrumentCollection, ...queryParams } = params;
        const cleanParams = Object.fromEntries(
          Object.entries(queryParams).filter(([_, value]) => value !== '')
        );
        const response = await marketTimeApi.getFuturesHolidaysByCollection(instrumentCollection, cleanParams);
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Market Hours & Schedule"
      endpoints={endpoints}
    />
  );
};

export default MarketTimeClientTab;