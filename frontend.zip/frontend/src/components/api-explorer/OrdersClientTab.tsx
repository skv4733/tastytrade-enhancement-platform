import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { ordersApi } from '../../services/unifiedTestingApi';

const OrdersClientTab: React.FC = () => {
  const endpoints = [
    {
      name: 'Dry Run Order',
      method: 'POST' as const,
      path: '/accounts/{accountNumber}/orders/dry-run',
      description: 'Test an order without actually placing it - see fees, requirements, and validation',
      buttonText: 'Test Order (Dry Run)',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Your account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'orderRequest',
          type: 'body' as const,
          required: true,
          description: 'Order details (JSON format)',
          example: `{
  "time-in-force": "Day",
  "order-type": "Market",
  "legs": [
    {
      "instrument-type": "Equity",
      "symbol": "AAPL",
      "action": "Buy to Open",
      "quantity": 100
    }
  ]
}`
        }
      ],
      apiCall: async (params: any) => {
        let orderRequest;
        try {
          orderRequest = typeof params.orderRequest === 'string' 
            ? JSON.parse(params.orderRequest) 
            : params.orderRequest;
        } catch (e) {
          throw new Error('Invalid JSON format for order request');
        }
        const response = await ordersApi.dryRunOrder(
          params.accountNumber || '5WZ51117',
          orderRequest
        );
        return response.data;
      }
    },
    {
      name: 'Place Order',
      method: 'POST' as const,
      path: '/accounts/{accountNumber}/orders',
      description: '⚠️ LIVE ORDER - This will actually place a real trade! Use dry run first.',
      buttonText: '🚨 Place LIVE Order',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Your account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'orderRequest',
          type: 'body' as const,
          required: true,
          description: 'Order details (JSON format) - WILL EXECUTE REAL TRADE',
          example: `{
  "time-in-force": "Day",
  "order-type": "Market",
  "legs": [
    {
      "instrument-type": "Equity",
      "symbol": "AAPL",
      "action": "Buy to Open",
      "quantity": 1
    }
  ]
}`
        }
      ],
      apiCall: async (params: any) => {
        let orderRequest;
        try {
          orderRequest = typeof params.orderRequest === 'string' 
            ? JSON.parse(params.orderRequest) 
            : params.orderRequest;
        } catch (e) {
          throw new Error('Invalid JSON format for order request');
        }
        const response = await ordersApi.createOrder(
          params.accountNumber || '5WZ51117',
          orderRequest
        );
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Order Management"
      endpoints={endpoints}
    />
  );
};

export default OrdersClientTab;