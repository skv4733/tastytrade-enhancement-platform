import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { riskParametersApi } from '../../services/unifiedTestingApi';

const RiskParametersClientTab: React.FC = () => {
  const endpoints = [
    // ===== RISK PARAMETERS =====
    {
      name: 'Get Risk Parameters',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/risk-parameters',
      description: 'Get risk parameters for an account',
      buttonText: '⚠️ Get Risk Parameters',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await riskParametersApi.getRiskParameters(params.accountNumber);
        return response.data;
      }
    },
    {
      name: 'Get Risk Status',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/risk-status',
      description: 'Get current risk status for an account',
      buttonText: '📊 Get Risk Status',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await riskParametersApi.getRiskStatus(params.accountNumber);
        return response.data;
      }
    },

    // ===== BUYING POWER =====
    {
      name: 'Get Buying Power',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/buying-power',
      description: 'Get buying power for an account',
      buttonText: '💰 Get Buying Power',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await riskParametersApi.getBuyingPower(params.accountNumber);
        return response.data;
      }
    },
    {
      name: 'Calculate Buying Power Effect',
      method: 'POST' as const,
      path: '/accounts/{accountNumber}/buying-power/effect',
      description: 'Calculate buying power effect of a potential order',
      buttonText: '🧮 Calculate Buying Power Effect',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'orderRequest',
          type: 'body' as const,
          required: true,
          description: 'Order request for buying power calculation',
          example: '{"legs": [{"instrument-type": "Equity", "symbol": "AAPL", "action": "Buy To Open", "quantity": 100}], "time-in-force": "Day", "order-type": "Market"}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await riskParametersApi.calculateBuyingPowerEffect(params.accountNumber, JSON.parse(params.orderRequest));
        return response.data;
      }
    },

    // ===== MARGIN REQUIREMENTS =====
    {
      name: 'Get Effective Margin Requirements',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/margin-requirements/{symbol}/effective',
      description: 'Get effective margin requirements for a symbol',
      buttonText: '📏 Get Effective Margin Requirements',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Symbol to get margin requirements for',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await riskParametersApi.getEffectiveMarginRequirements(params.accountNumber, params.symbol);
        return response.data;
      }
    },

    // ===== POSITION LIMITS =====
    {
      name: 'Get Position Limits',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/position-limit',
      description: 'Get position limits for an account',
      buttonText: '📊 Get Position Limits',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await riskParametersApi.getPositionLimits(params.accountNumber);
        return response.data;
      }
    },
    {
      name: 'Update Position Limits',
      method: 'PATCH' as const,
      path: '/accounts/{accountNumber}/position-limit',
      description: 'Update position limits for an account',
      buttonText: '✏️ Update Position Limits',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'positionLimitRequest',
          type: 'body' as const,
          required: true,
          description: 'Position limit update request',
          example: '{"equity-position-limit": 10000, "option-position-limit": 1000}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await riskParametersApi.updatePositionLimits(params.accountNumber, JSON.parse(params.positionLimitRequest));
        return response.data;
      }
    },

    // ===== CONCENTRATION LIMITS =====
    {
      name: 'Get Concentration Limits',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/concentration-limits',
      description: 'Get concentration limits for an account',
      buttonText: '🎯 Get Concentration Limits',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await riskParametersApi.getConcentrationLimits(params.accountNumber);
        return response.data;
      }
    },
    {
      name: 'Update Concentration Limits',
      method: 'PATCH' as const,
      path: '/accounts/{accountNumber}/concentration-limits',
      description: 'Update concentration limits for an account',
      buttonText: '✏️ Update Concentration Limits',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'concentrationLimitsRequest',
          type: 'body' as const,
          required: true,
          description: 'Concentration limits update request',
          example: '{"single-security-limit": 25, "sector-concentration-limit": 40}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await riskParametersApi.updateConcentrationLimits(params.accountNumber, JSON.parse(params.concentrationLimitsRequest));
        return response.data;
      }
    },

    // ===== MARGIN CALLS =====
    {
      name: 'Get Margin Calls',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/margin-calls',
      description: 'Get margin calls for an account',
      buttonText: '📞 Get Margin Calls',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'status',
          type: 'query' as const,
          required: false,
          description: 'Status filter',
          example: 'Open'
        },
        {
          name: 'start-date',
          type: 'query' as const,
          required: false,
          description: 'Start date (YYYY-MM-DD)',
          example: '2025-01-01'
        },
        {
          name: 'end-date',
          type: 'query' as const,
          required: false,
          description: 'End date (YYYY-MM-DD)',
          example: '2025-12-31'
        }
      ],
      apiCall: async (params: any) => {
        const { accountNumber, ...queryParams } = params;
        const cleanParams = Object.fromEntries(
          Object.entries(queryParams).filter(([_, value]) => value !== '')
        );
        const response = await riskParametersApi.getMarginCalls(accountNumber, cleanParams);
        return response.data;
      }
    },

    // ===== LIQUIDATION HISTORY =====
    {
      name: 'Get Liquidation History',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/liquidations',
      description: 'Get liquidation history for an account',
      buttonText: '💧 Get Liquidation History',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'start-date',
          type: 'query' as const,
          required: false,
          description: 'Start date (YYYY-MM-DD)',
          example: '2025-01-01'
        },
        {
          name: 'end-date',
          type: 'query' as const,
          required: false,
          description: 'End date (YYYY-MM-DD)',
          example: '2025-12-31'
        }
      ],
      apiCall: async (params: any) => {
        const { accountNumber, ...queryParams } = params;
        const cleanParams = Object.fromEntries(
          Object.entries(queryParams).filter(([_, value]) => value !== '')
        );
        const response = await riskParametersApi.getLiquidationHistory(accountNumber, cleanParams);
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Risk Management & Limits"
      endpoints={endpoints}
    />
  );
};

export default RiskParametersClientTab;