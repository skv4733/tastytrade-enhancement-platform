import React from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Chip,
  List,
  ListItem,
  ListItemText,
  Accordion,
  AccordionSummary,
  AccordionDetails
} from '@mui/material';
import {
  Person,
  LocationOn,
  Work,
  ExpandMore,
  TrendingUp,
  AccountBalanceWallet,
  Security
} from '@mui/icons-material';

interface ResponseViewerProps {
  data: any;
  endpointName: string;
}

const ResponseViewer: React.FC<ResponseViewerProps> = ({ data, endpointName }) => {
  // Helper function to format currency
  const formatCurrency = (value: number | string) => {
    const num = typeof value === 'string' ? parseFloat(value) : value;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(num);
  };

  // Helper function to format date
  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Render customer profile data
  const renderCustomerProfile = (customerData: any) => {
    const person = customerData.person || {};
    const address = customerData.address || customerData['mailing-address'] || {};
    const suitability = customerData['customer-suitability'] || {};

    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          👤 Customer Profile
        </Typography>
        
        <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 3 }}>
          {/* Personal Information */}
          <Box sx={{ flex: 1 }}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Person color="primary" />
                  Personal Information
                </Typography>
                <List dense>
                  <ListItem>
                    <ListItemText 
                      primary="Full Name" 
                      secondary={`${person['first-name'] || customerData['first-name']} ${person['last-name'] || customerData['last-name']}`} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Email" 
                      secondary={customerData.email} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Phone" 
                      secondary={customerData['mobile-phone-number']} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Birth Date" 
                      secondary={formatDate(customerData['birth-date'])} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Citizenship" 
                      secondary={`${customerData['citizenship-country']} ${customerData['usa-citizenship-type']}`} 
                    />
                  </ListItem>
                </List>
              </CardContent>
            </Card>
          </Box>

          {/* Address Information */}
          <Box sx={{ flex: 1 }}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <LocationOn color="primary" />
                  Address
                </Typography>
                <Typography variant="body1">
                  {address['street-one']}<br />
                  {address['street-two'] && <>{address['street-two']}<br /></>}
                  {address.city}, {address['state-region']} {address['postal-code']}<br />
                  {address.country}
                </Typography>
                <Box sx={{ mt: 2 }}>
                  <Chip 
                    label={address['is-domestic'] ? 'Domestic Address' : 'Foreign Address'} 
                    color={address['is-domestic'] ? 'success' : 'warning'}
                    size="small"
                  />
                </Box>
              </CardContent>
            </Card>
          </Box>
        </Box>

        <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 3, mt: 3 }}>
          {/* Employment Information */}
          <Box sx={{ flex: 1 }}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Work color="primary" />
                  Employment
                </Typography>
                <List dense>
                  <ListItem>
                    <ListItemText 
                      primary="Employer" 
                      secondary={person['employer-name'] || suitability['employer-name']} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Job Title" 
                      secondary={person['job-title'] || suitability['job-title']} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Occupation" 
                      secondary={person.occupation || suitability.occupation} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Employment Status" 
                      secondary={person['employment-status'] || suitability['employment-status']} 
                    />
                  </ListItem>
                </List>
              </CardContent>
            </Card>
          </Box>

          {/* Financial Information */}
          <Box sx={{ flex: 1 }}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <AccountBalanceWallet color="primary" />
                  Financial Profile
                </Typography>
                <List dense>
                  <ListItem>
                    <ListItemText 
                      primary="Net Worth" 
                      secondary={suitability['net-worth'] ? formatCurrency(suitability['net-worth']) : 'Not disclosed'} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Liquid Net Worth" 
                      secondary={suitability['liquid-net-worth'] ? formatCurrency(suitability['liquid-net-worth']) : 'Not disclosed'} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Annual Income" 
                      secondary={suitability['annual-net-income'] ? formatCurrency(suitability['annual-net-income']) : 'Not disclosed'} 
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText 
                      primary="Dependents" 
                      secondary={person['number-of-dependents'] || suitability['number-of-dependents'] || 0} 
                    />
                  </ListItem>
                </List>
              </CardContent>
            </Card>
          </Box>
        </Box>

        {/* Trading Experience */}
        <Box sx={{ mt: 3 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <TrendingUp color="primary" />
                Trading Experience
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                <Box sx={{ minWidth: 120 }}>
                  <Typography variant="subtitle2" color="text.secondary">Stocks</Typography>
                  <Chip 
                    label={suitability['stock-trading-experience'] || 'Not specified'} 
                    color="primary" 
                    variant="outlined"
                  />
                </Box>
                <Box sx={{ minWidth: 120 }}>
                  <Typography variant="subtitle2" color="text.secondary">Options (Covered)</Typography>
                  <Chip 
                    label={suitability['covered-options-trading-experience'] || 'Not specified'} 
                    color="secondary" 
                    variant="outlined"
                  />
                </Box>
                <Box sx={{ minWidth: 120 }}>
                  <Typography variant="subtitle2" color="text.secondary">Options (Uncovered)</Typography>
                  <Chip 
                    label={suitability['uncovered-options-trading-experience'] || 'Not specified'} 
                    color="warning" 
                    variant="outlined"
                  />
                </Box>
                <Box sx={{ minWidth: 120 }}>
                  <Typography variant="subtitle2" color="text.secondary">Futures</Typography>
                  <Chip 
                    label={suitability['futures-trading-experience'] || 'Not specified'} 
                    color="error" 
                    variant="outlined"
                  />
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Box>

        {/* Account Types */}
        {customerData['permitted-account-types'] && (
          <Box sx={{ mt: 3 }}>
            <Accordion>
              <AccordionSummary expandIcon={<ExpandMore />}>
                <Typography variant="h6" sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Security color="primary" />
                  Available Account Types ({customerData['permitted-account-types'].length})
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                  {customerData['permitted-account-types'].map((accountType: any, index: number) => (
                    <Box key={index} sx={{ minWidth: 300, flex: '1 1 auto' }}>
                      <Card variant="outlined">
                        <CardContent>
                          <Typography variant="subtitle1" fontWeight="bold">
                            {accountType.name}
                          </Typography>
                          <Box sx={{ mt: 1, mb: 1 }}>
                            {accountType.is_tax_advantaged && (
                              <Chip label="Tax Advantaged" color="success" size="small" sx={{ mr: 1, mb: 1 }} />
                            )}
                            {accountType.has_multiple_owners && (
                              <Chip label="Multiple Owners" color="info" size="small" sx={{ mr: 1, mb: 1 }} />
                            )}
                          </Box>
                          <Typography variant="body2" color="text.secondary">
                            Margin Options: {accountType.margin_types?.map((mt: any) => mt.name).join(', ')}
                          </Typography>
                        </CardContent>
                      </Card>
                    </Box>
                  ))}
                </Box>
              </AccordionDetails>
            </Accordion>
          </Box>
        )}
      </Box>
    );
  };

  // Render account balances
  const renderAccountBalances = (balanceData: any) => {
    const data = balanceData.data || balanceData;
    
    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          💰 Account Balances
        </Typography>
        
        {/* Summary Cards */}
        <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 3, mb: 4 }}>
          <Box sx={{ flex: 1 }}>
            <Card sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white' }}>
              <CardContent>
                <Typography variant="h6">Cash Balance</Typography>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                  {formatCurrency(data['cash-balance'] || 0)}
                </Typography>
              </CardContent>
            </Card>
          </Box>
          <Box sx={{ flex: 1 }}>
            <Card sx={{ background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', color: 'white' }}>
              <CardContent>
                <Typography variant="h6">Net Liquidating Value</Typography>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                  {formatCurrency(data['net-liquidating-value'] || 0)}
                </Typography>
              </CardContent>
            </Card>
          </Box>
          <Box sx={{ flex: 1 }}>
            <Card sx={{ background: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', color: 'white' }}>
              <CardContent>
                <Typography variant="h6">Equity Buying Power</Typography>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                  {formatCurrency(data['equity-buying-power'] || 0)}
                </Typography>
              </CardContent>
            </Card>
          </Box>
        </Box>

        {/* Detailed Balance Information */}
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
              💳 Detailed Balance Information
            </Typography>
            
            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr 1fr' }, gap: 3 }}>
              {/* Cash & Equity Values */}
              <Box>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>Cash & Equity</Typography>
                <List dense>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Cash Available to Withdraw" 
                      secondary={formatCurrency(data['cash-available-to-withdraw'] || 0)}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Long Equity Value" 
                      secondary={formatCurrency(data['long-equity-value'] || 0)}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Short Equity Value" 
                      secondary={formatCurrency(data['short-equity-value'] || 0)}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Available Trading Funds" 
                      secondary={formatCurrency(data['available-trading-funds'] || 0)}
                    />
                  </ListItem>
                </List>
              </Box>

              {/* Buying Power */}
              <Box>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>Buying Power</Typography>
                <List dense>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Day Trading Buying Power" 
                      secondary={formatCurrency(data['day-trading-buying-power'] || 0)}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Derivative Buying Power" 
                      secondary={formatCurrency(data['derivative-buying-power'] || 0)}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Day Trade Excess" 
                      secondary={formatCurrency(data['day-trade-excess'] || 0)}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Maintenance Excess" 
                      secondary={formatCurrency(data['maintenance-excess'] || 0)}
                    />
                  </ListItem>
                </List>
              </Box>

              {/* Margin & Requirements */}
              <Box>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>Margin & Requirements</Typography>
                <List dense>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Maintenance Requirement" 
                      secondary={formatCurrency(data['maintenance-requirement'] || 0)}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Futures Margin Requirement" 
                      secondary={formatCurrency(data['futures-margin-requirement'] || 0)}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Reg T Margin Requirement" 
                      secondary={formatCurrency(data['reg-t-margin-requirement'] || 0)}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Pending Cash" 
                      secondary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography variant="body2">{formatCurrency(data['pending-cash'] || 0)}</Typography>
                          {data['pending-cash-effect'] && (
                            <Chip 
                              label={data['pending-cash-effect']} 
                              color={data['pending-cash-effect'] === 'Credit' ? 'success' : 'error'}
                              size="small"
                            />
                          )}
                        </Box>
                      }
                    />
                  </ListItem>
                </List>
              </Box>
            </Box>

            {/* Futures & Derivatives Section */}
            {(data['long-futures-value'] || data['short-futures-value'] || data['long-derivative-value'] || data['short-derivative-value']) && (
              <Box sx={{ mt: 3, pt: 2, borderTop: '1px solid #e0e0e0' }}>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>Futures & Derivatives</Typography>
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2 }}>
                  <List dense>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Long Futures Value" 
                        secondary={formatCurrency(data['long-futures-value'] || 0)}
                      />
                    </ListItem>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Long Derivative Value" 
                        secondary={formatCurrency(data['long-derivative-value'] || 0)}
                      />
                    </ListItem>
                  </List>
                  <List dense>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Short Futures Value" 
                        secondary={formatCurrency(data['short-futures-value'] || 0)}
                      />
                    </ListItem>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Short Derivative Value" 
                        secondary={formatCurrency(data['short-derivative-value'] || 0)}
                      />
                    </ListItem>
                  </List>
                </Box>
              </Box>
            )}

            {/* Account Info */}
            <Box sx={{ mt: 2, pt: 2, borderTop: '1px solid #e0e0e0' }}>
              <Typography variant="caption" color="text.secondary">
                Account: {data['account-number'] || 'N/A'} | 
                Updated: {formatDate(data['updated-at'])} |
                {data['snapshot-date'] && ` Snapshot: ${formatDate(data['snapshot-date'])}`}
              </Typography>
            </Box>
          </CardContent>
        </Card>

        {/* Raw JSON View */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMore />}>
            <Typography variant="h6">📄 Raw JSON Response</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Card>
              <CardContent>
                <pre style={{ 
                  whiteSpace: 'pre-wrap', fontSize: '0.875rem', maxHeight: '400px', overflow: 'auto',
                  backgroundColor: '#f5f5f5', padding: '16px', borderRadius: '4px', margin: 0
                }}>
                  {JSON.stringify(balanceData, null, 2)}
                </pre>
              </CardContent>
            </Card>
          </AccordionDetails>
        </Accordion>
      </Box>
    );
  };

  // Render market data
  const renderMarketData = (marketData: any) => {
    const items = marketData.data?.items || marketData.items || [];
    
    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          📈 Market Data
        </Typography>
        
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
          {items.map((item: any, index: number) => (
            <Box key={index} sx={{ minWidth: 300, flex: '1 1 auto' }}>
              <Card>
                <CardContent>
                  <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                    {item.symbol}
                  </Typography>
                  <Typography variant="h4" color="primary.main" sx={{ fontWeight: 'bold' }}>
                    ${item.last || item.mark || 'N/A'}
                  </Typography>
                  <Box sx={{ mt: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Bid: ${item.bid || 'N/A'} | Ask: ${item.ask || 'N/A'}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Volume: {item.volume?.toLocaleString() || 'N/A'}
                    </Typography>
                  </Box>
                </CardContent>
              </Card>
            </Box>
          ))}
        </Box>
      </Box>
    );
  };

  // Render search results
  const renderSearchResults = (searchData: any) => {
    const items = searchData.data?.items || searchData.items || [];
    
    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          🔎 Search Results
        </Typography>
        
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
          {items.map((item: any, index: number) => (
            <Box key={index} sx={{ minWidth: 300, flex: '1 1 auto' }}>
              <Card>
                <CardContent>
                  <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                    {item.symbol}
                  </Typography>
                  <Typography variant="body1">
                    {item.description || item['short-description'] || 'No description'}
                  </Typography>
                  <Box sx={{ mt: 1 }}>
                    <Chip 
                      label={item['instrument-type'] || 'Unknown'} 
                      color="primary" 
                      size="small" 
                    />
                  </Box>
                </CardContent>
              </Card>
            </Box>
          ))}
        </Box>
      </Box>
    );
  };

  // Render positions data
  const renderPositions = (positionsData: any) => {
    const items = positionsData.data?.items || positionsData.items || [];
    
    if (items.length === 0) {
      return (
        <Box>
          <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
            📊 Current Positions
          </Typography>
          <Card>
            <CardContent>
              <Typography variant="body1" color="text.secondary" textAlign="center">
                No positions found. Your portfolio is currently empty.
              </Typography>
            </CardContent>
          </Card>
          
          {/* Raw JSON View */}
          <Accordion sx={{ mt: 2 }}>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Typography variant="h6">📄 Raw JSON Response</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Card>
                <CardContent>
                  <pre style={{ 
                    whiteSpace: 'pre-wrap', fontSize: '0.875rem', maxHeight: '400px', overflow: 'auto',
                    backgroundColor: '#f5f5f5', padding: '16px', borderRadius: '4px', margin: 0
                  }}>
                    {JSON.stringify(positionsData, null, 2)}
                  </pre>
                </CardContent>
              </Card>
            </AccordionDetails>
          </Accordion>
        </Box>
      );
    }
    
    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          📊 Current Positions ({items.length})
        </Typography>
        
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mb: 3 }}>
          {items.map((position: any, index: number) => {
            const isProfit = position['realized-day-gain'] > 0 || (position['market-value'] - position['average-open-price'] * position.quantity) > 0;
            const totalValue = position['market-value'] || position['net-liquidating-value'] || 0;
            const unrealizedPL = totalValue - (position['average-open-price'] * position.quantity);
            
            return (
              <Card key={index} sx={{ '&:hover': { boxShadow: 4 }, transition: 'box-shadow 0.2s ease-in-out' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                    <Box>
                      <Typography variant="h6" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                        📈 {position.symbol}
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                        <Chip 
                          label={position['instrument-type'] || position.instrumentType || 'Unknown'}
                          color="primary"
                          size="small"
                        />
                        {position['underlying-symbol'] && position['underlying-symbol'] !== position.symbol && (
                          <Chip 
                            label={`Underlying: ${position['underlying-symbol']}`}
                            color="secondary"
                            variant="outlined"
                            size="small"
                          />
                        )}
                        <Chip 
                          label={`${position.quantity >= 0 ? 'LONG' : 'SHORT'} ${Math.abs(position.quantity)}`}
                          color={position.quantity >= 0 ? 'success' : 'error'}
                          size="small"
                        />
                      </Box>
                    </Box>
                    <Box sx={{ textAlign: 'right' }}>
                      <Typography variant="h6" color={isProfit ? 'success.main' : 'error.main'}>
                        {formatCurrency(totalValue)}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Current Value
                      </Typography>
                    </Box>
                  </Box>
                  
                  <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr 1fr' }, gap: 2 }}>
                    <Box>
                      <Typography variant="subtitle2" color="text.secondary">Position Details</Typography>
                      <List dense>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Quantity" 
                            secondary={`${position.quantity} ${position.multiplier ? `(${position.multiplier}x)` : ''}`}
                          />
                        </ListItem>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Avg Open Price" 
                            secondary={formatCurrency(position['average-open-price'] || 0)}
                          />
                        </ListItem>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Close Price" 
                            secondary={formatCurrency(position['close-price'] || position.mark || 0)}
                          />
                        </ListItem>
                      </List>
                    </Box>
                    
                    <Box>
                      <Typography variant="subtitle2" color="text.secondary">Performance</Typography>
                      <List dense>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Unrealized P&L" 
                            secondary={
                              <Typography color={unrealizedPL >= 0 ? 'success.main' : 'error.main'}>
                                {formatCurrency(unrealizedPL)}
                              </Typography>
                            }
                          />
                        </ListItem>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Day Gain" 
                            secondary={
                              <Typography color={(position['realized-day-gain'] || 0) >= 0 ? 'success.main' : 'error.main'}>
                                {formatCurrency(position['realized-day-gain'] || 0)}
                              </Typography>
                            }
                          />
                        </ListItem>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Today's Realized" 
                            secondary={
                              <Typography color={(position['realized-today'] || 0) >= 0 ? 'success.main' : 'error.main'}>
                                {formatCurrency(position['realized-today'] || 0)}
                              </Typography>
                            }
                          />
                        </ListItem>
                      </List>
                    </Box>
                    
                    <Box>
                      <Typography variant="subtitle2" color="text.secondary">Additional Info</Typography>
                      <List dense>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Days to Expiry" 
                            secondary={position['days-to-expiration'] || 'N/A'}
                          />
                        </ListItem>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Updated" 
                            secondary={formatDate(position['updated-at'])}
                          />
                        </ListItem>
                      </List>
                    </Box>
                  </Box>
                  
                  {(position['is-frozen'] || position['is-suppressed']) && (
                    <Box sx={{ mt: 2 }}>
                      {position['is-frozen'] && <Chip label="FROZEN" color="error" size="small" sx={{ mr: 1 }} />}
                      {position['is-suppressed'] && <Chip label="SUPPRESSED" color="warning" size="small" />}
                    </Box>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </Box>
        
        {/* Raw JSON View */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMore />}>
            <Typography variant="h6">📄 Raw JSON Response</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Card>
              <CardContent>
                <pre style={{ 
                  whiteSpace: 'pre-wrap', fontSize: '0.875rem', maxHeight: '400px', overflow: 'auto',
                  backgroundColor: '#f5f5f5', padding: '16px', borderRadius: '4px', margin: 0
                }}>
                  {JSON.stringify(positionsData, null, 2)}
                </pre>
              </CardContent>
            </Card>
          </AccordionDetails>
        </Accordion>
      </Box>
    );
  };

  // Render balance snapshots data
  const renderBalanceSnapshots = (snapshotsData: any) => {
    const items = snapshotsData.data?.items || snapshotsData.items || [];
    
    if (items.length === 0) {
      return (
        <Box>
          <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
            📈 Balance History
          </Typography>
          <Card>
            <CardContent>
              <Typography variant="body1" color="text.secondary" textAlign="center">
                No balance history found.
              </Typography>
            </CardContent>
          </Card>
          
          {/* Raw JSON View */}
          <Accordion sx={{ mt: 2 }}>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Typography variant="h6">📄 Raw JSON Response</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Card>
                <CardContent>
                  <pre style={{ 
                    whiteSpace: 'pre-wrap', fontSize: '0.875rem', maxHeight: '400px', overflow: 'auto',
                    backgroundColor: '#f5f5f5', padding: '16px', borderRadius: '4px', margin: 0
                  }}>
                    {JSON.stringify(snapshotsData, null, 2)}
                  </pre>
                </CardContent>
              </Card>
            </AccordionDetails>
          </Accordion>
        </Box>
      );
    }
    
    // Sort by date
    const sortedItems = [...items].sort((a, b) => new Date(b['snapshot-date']).getTime() - new Date(a['snapshot-date']).getTime());
    
    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          📈 Balance History ({items.length} snapshots)
        </Typography>
        
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mb: 3 }}>
          {sortedItems.map((snapshot: any, index: number) => {
            return (
              <Card key={index} sx={{ '&:hover': { boxShadow: 4 }, transition: 'box-shadow 0.2s ease-in-out' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                    <Typography variant="h6" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                      📅 {formatDate(snapshot['snapshot-date'])}
                    </Typography>
                    <Typography variant="h6" color="primary.main">
                      {formatCurrency(snapshot['net-liquidating-value'] || 0)}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr 1fr' }, gap: 2 }}>
                    <Box>
                      <List dense>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Cash Balance" 
                            secondary={formatCurrency(snapshot['cash-balance'] || 0)}
                          />
                        </ListItem>
                      </List>
                    </Box>
                    <Box>
                      <List dense>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Total Equity" 
                            secondary={formatCurrency(snapshot['total-equity'] || 0)}
                          />
                        </ListItem>
                      </List>
                    </Box>
                    <Box>
                      <List dense>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Net Liquidating Value" 
                            secondary={formatCurrency(snapshot['net-liquidating-value'] || 0)}
                          />
                        </ListItem>
                      </List>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            );
          })}
        </Box>
        
        {/* Raw JSON View */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMore />}>
            <Typography variant="h6">📄 Raw JSON Response</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Card>
              <CardContent>
                <pre style={{ 
                  whiteSpace: 'pre-wrap', fontSize: '0.875rem', maxHeight: '400px', overflow: 'auto',
                  backgroundColor: '#f5f5f5', padding: '16px', borderRadius: '4px', margin: 0
                }}>
                  {JSON.stringify(snapshotsData, null, 2)}
                </pre>
              </CardContent>
            </Card>
          </AccordionDetails>
        </Accordion>
      </Box>
    );
  };

  // Render trading status data
  const renderTradingStatus = (statusData: any) => {
    const data = statusData.data || statusData;
    
    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          🎯 Account Trading Status
        </Typography>
        
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
              <Typography variant="h6" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                📊 Account: {data['account-number'] || data.accountNumber}
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                {data['is-frozen'] && <Chip label="FROZEN" color="error" size="small" />}
                {data['is-closed'] && <Chip label="CLOSED" color="error" size="small" />}
                {data['is-closing-only'] && <Chip label="CLOSING ONLY" color="warning" size="small" />}
                {data['is-risk-reducing-only'] && <Chip label="RISK REDUCING ONLY" color="warning" size="small" />}
                {data['is-pattern-day-trader'] && <Chip label="PDT" color="info" size="small" />}
              </Box>
            </Box>

            {/* Account Status Overview */}
            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr 1fr' }, gap: 3, mb: 3 }}>
              <Box>
                <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                  📈 Trading Status
                </Typography>
                <List dense>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Account Status"
                      secondary={
                        <Box sx={{ display: 'flex', gap: 1, mt: 0.5 }}>
                          {data['is-frozen'] ? 
                            <Chip label="Frozen" color="error" size="small" /> :
                            data['is-closed'] ? 
                            <Chip label="Closed" color="error" size="small" /> :
                            data['is-closing-only'] ? 
                            <Chip label="Closing Only" color="warning" size="small" /> :
                            <Chip label="Active" color="success" size="small" />
                          }
                        </Box>
                      }
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Pattern Day Trader"
                      secondary={data['is-pattern-day-trader'] ? 'Yes' : 'No'}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="In Margin Call"
                      secondary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          {data['is-in-margin-call'] ? (
                            <>
                              <Chip label="YES" color="error" size="small" />
                              {data['is-in-day-trade-equity-maintenance-call'] && 
                                <Chip label="Day Trade Call" color="warning" size="small" />
                              }
                            </>
                          ) : (
                            <Chip label="NO" color="success" size="small" />
                          )}
                        </Box>
                      }
                    />
                  </ListItem>
                </List>
              </Box>

              <Box>
                <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                  🎛️ Options Trading
                </Typography>
                <List dense>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Options Level"
                      secondary={
                        <Chip 
                          label={data['options-level'] || 'Not Set'} 
                          color="primary" 
                          size="small"
                        />
                      }
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Short Calls Enabled"
                      secondary={data['short-calls-enabled'] ? 'Yes' : 'No'}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Deep ITM Carry Options"
                      secondary={data['are-deep-itm-carry-options-enabled'] ? 'Enabled' : 'Disabled'}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Far OTM Restrictions"
                      secondary={data['are-far-otm-net-options-restricted'] ? 'Yes' : 'No'}
                    />
                  </ListItem>
                </List>
              </Box>

              <Box>
                <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                  📊 Margin & Risk
                </Typography>
                <List dense>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Portfolio Margin"
                      secondary={data['is-portfolio-margin-enabled'] ? 'Enabled' : 'Standard Margin'}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Intraday Equities Margin"
                      secondary={data['has-intraday-equities-margin'] ? 'Yes' : 'No'}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Full Equity Margin Required"
                      secondary={data['is-full-equity-margin-required'] ? 'Yes' : 'No'}
                    />
                  </ListItem>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemText 
                      primary="Margin Calculation"
                      secondary={data['equities-margin-calculation-type'] || 'Standard'}
                    />
                  </ListItem>
                </List>
              </Box>
            </Box>

            {/* Futures Trading Section */}
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                🌾 Futures Trading
              </Typography>
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2 }}>
                <Box>
                  <List dense>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Futures Enabled"
                        secondary={
                          data['is-futures-enabled'] ? 
                            <Chip label="YES" color="success" size="small" /> :
                            <Chip label="NO" color="default" size="small" />
                        }
                      />
                    </ListItem>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Futures Closing Only"
                        secondary={data['is-futures-closing-only'] ? 'Yes' : 'No'}
                      />
                    </ListItem>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Intraday Futures"
                        secondary={data['is-futures-intra-day-enabled'] ? 'Enabled' : 'Disabled'}
                      />
                    </ListItem>
                  </List>
                </Box>
                <Box>
                  <List dense>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Margin Rate Multiplier"
                        secondary={data['futures-margin-rate-multiplier'] || 'Standard'}
                      />
                    </ListItem>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Small Notional Intraday"
                        secondary={data['is-small-notional-futures-intra-day-enabled'] ? 'Yes' : 'No'}
                      />
                    </ListItem>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Small Notional Multiplier"
                        secondary={data['small-notional-futures-margin-rate-multiplier'] || 'N/A'}
                      />
                    </ListItem>
                  </List>
                </Box>
              </Box>
            </Box>

            {/* Alternative Investments Section */}
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                🪙 Alternative Investments
              </Typography>
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2 }}>
                <Box>
                  <List dense>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Cryptocurrency Trading"
                        secondary={
                          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                            {data['is-cryptocurrency-enabled'] ? 
                              <Chip label="Enabled" color="success" size="small" /> :
                              <Chip label="Disabled" color="default" size="small" />
                            }
                            {data['is-cryptocurrency-closing-only'] && 
                              <Chip label="Closing Only" color="warning" size="small" />
                            }
                          </Box>
                        }
                      />
                    </ListItem>
                  </List>
                </Box>
                <Box>
                  <List dense>
                    <ListItem sx={{ px: 0 }}>
                      <ListItemText 
                        primary="Equity Offerings"
                        secondary={
                          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                            {data['is-equity-offering-enabled'] ? 
                              <Chip label="Enabled" color="success" size="small" /> :
                              <Chip label="Disabled" color="default" size="small" />
                            }
                            {data['is-equity-offering-closing-only'] && 
                              <Chip label="Closing Only" color="warning" size="small" />
                            }
                          </Box>
                        }
                      />
                    </ListItem>
                  </List>
                </Box>
              </Box>
            </Box>

            {/* Account Information */}
            <Box sx={{ pt: 2, borderTop: '1px solid #e0e0e0' }}>
              <Typography variant="caption" color="text.secondary">
                Fee Schedule: {data['fee-schedule-name'] || 'Standard'} | 
                Updated: {formatDate(data['updated-at'])} |
                {data['enhanced-fraud-safeguards-enabled-at'] && 
                  ` Enhanced Fraud Protection: ${formatDate(data['enhanced-fraud-safeguards-enabled-at'])}`
                }
              </Typography>
            </Box>
          </CardContent>
        </Card>

        {/* Raw JSON View */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMore />}>
            <Typography variant="h6">
              📄 Raw JSON Response
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Card>
              <CardContent>
                <pre style={{ 
                  whiteSpace: 'pre-wrap', 
                  fontSize: '0.875rem',
                  maxHeight: '400px',
                  overflow: 'auto',
                  backgroundColor: '#f5f5f5',
                  padding: '16px',
                  borderRadius: '4px',
                  margin: 0
                }}>
                  {JSON.stringify(statusData, null, 2)}
                </pre>
              </CardContent>
            </Card>
          </AccordionDetails>
        </Accordion>
      </Box>
    );
  };

  // Render account data
  const renderAccounts = (accountData: any) => {
    const items = accountData.data?.items || accountData.items || [];
    
    if (items.length === 0) {
      return (
        <Box>
          <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
            🏦 My Accounts
          </Typography>
          <Card>
            <CardContent>
              <Typography variant="body1" color="text.secondary" textAlign="center">
                No accounts found.
              </Typography>
            </CardContent>
          </Card>
        </Box>
      );
    }
    
    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          🏦 My Accounts ({items.length})
        </Typography>
        
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {items.map((item: any, index: number) => {
            const account = item.account || item;
            
            return (
              <Card key={index} sx={{ 
                width: '100%',
                '&:hover': { boxShadow: 4 },
                transition: 'box-shadow 0.2s ease-in-out'
              }}>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                    <Typography variant="h6" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                      💼 {account['account-number'] || account.accountNumber}
                    </Typography>
                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 1 }}>
                      <Chip 
                        label={account['account-type-name'] || account.accountTypeName || 'Unknown Type'}
                        color="primary"
                        size="small"
                      />
                      {item['authority-level'] && (
                        <Chip 
                          label={`Authority: ${item['authority-level']}`}
                          color="secondary"
                          variant="outlined"
                          size="small"
                        />
                      )}
                    </Box>
                  </Box>
                  
                  <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2, mb: 2 }}>
                    <Box>
                      <Typography variant="subtitle2" color="text.secondary">Account Details</Typography>
                      <List dense>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Nickname" 
                            secondary={account.nickname || 'No nickname set'} 
                          />
                        </ListItem>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Account Type" 
                            secondary={account['margin-or-cash'] || account.marginOrCash || 'N/A'} 
                          />
                        </ListItem>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Opened Date" 
                            secondary={formatDate(account['opened-at'] || account.openedAt)} 
                          />
                        </ListItem>
                      </List>
                    </Box>
                    
                    <Box>
                      <Typography variant="subtitle2" color="text.secondary">Trading Information</Typography>
                      <List dense>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Day Trader Status" 
                            secondary={account['day-trader-status'] || account.dayTraderStatus ? 'Yes' : 'No'} 
                          />
                        </ListItem>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Options Level" 
                            secondary={account['suitable-options-level'] || account.suitableOptionsLevel || 'N/A'} 
                          />
                        </ListItem>
                        <ListItem sx={{ px: 0 }}>
                          <ListItemText 
                            primary="Futures Approved" 
                            secondary={account['is-futures-approved'] || account.isFuturesApproved ? 'Yes' : 'No'} 
                          />
                        </ListItem>
                      </List>
                    </Box>
                  </Box>
                  
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 2 }}>
                    {(account['is-closed'] || account.isClosed) && (
                      <Chip label="Closed" color="error" size="small" />
                    )}
                    {(account['is-test-drive'] || account.isTestDrive) && (
                      <Chip label="Test Drive" color="warning" size="small" />
                    )}
                    {(account['is-foreign'] || account.isForeign) && (
                      <Chip label="Foreign Account" color="info" size="small" />
                    )}
                    {(account['is-firm-proprietary'] || account.isFirmProprietary) && (
                      <Chip label="Firm Proprietary" color="default" size="small" />
                    )}
                  </Box>
                  
                  {(account['funding-date'] || account.fundingDate) && (
                    <Box sx={{ mt: 2, pt: 1, borderTop: '1px solid #e0e0e0' }}>
                      <Typography variant="caption" color="text.secondary">
                        Funding Date: {formatDate(account['funding-date'] || account.fundingDate)} | 
                        Created: {formatDate(account['created-at'] || account.createdAt)}
                      </Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </Box>
      </Box>
    );
  };

  // Render pairs watchlist data
  const renderPairsWatchlists = (watchlistData: any) => {
    const items = watchlistData.data?.items || watchlistData.items || [];
    
    if (items.length === 0) {
      return (
        <Box>
          <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
            📈 Pairs Trading Watchlists
          </Typography>
          <Card>
            <CardContent>
              <Typography variant="body1" color="text.secondary" textAlign="center">
                No pairs watchlists found. Create your first pairs trading strategy!
              </Typography>
            </CardContent>
          </Card>
        </Box>
      );
    }
    
    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          📈 Pairs Trading Watchlists ({items.length})
        </Typography>
        
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {items.map((watchlist: any, index: number) => (
            <Card key={index} sx={{ 
              width: '100%',
              '&:hover': { boxShadow: 4 },
              transition: 'box-shadow 0.2s ease-in-out'
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                  <Typography variant="h6" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                    ⚖️ {watchlist.name}
                  </Typography>
                  <Chip 
                    label={`${watchlist['pairs-equations']?.length || 0} pairs`}
                    color="secondary"
                    size="small"
                  />
                </Box>
                
                <Box sx={{ mb: 2, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                  <Chip 
                    label={`ID: ${watchlist.id}`}
                    color="info"
                    variant="outlined"
                    size="small"
                  />
                  <Chip 
                    label={`Order: ${watchlist['order-index']}`}
                    color="default"
                    variant="outlined"
                    size="small"
                  />
                </Box>
                
                {watchlist['pairs-equations'] && watchlist['pairs-equations'].length > 0 ? (
                  <Box>
                    <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 'medium' }}>
                      Trading Pairs:
                    </Typography>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                      {watchlist['pairs-equations'].map((pair: any, pairIndex: number) => (
                        <Card key={pairIndex} variant="outlined" sx={{ bgcolor: 'grey.50' }}>
                          <CardContent sx={{ py: 1.5 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2 }}>
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <Chip 
                                  label={pair['left-action']} 
                                  color={pair['left-action'] === 'Buy' ? 'success' : 'error'}
                                  size="small"
                                  sx={{ fontWeight: 'bold' }}
                                />
                                <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                                  {pair['left-symbol']}
                                </Typography>
                                <Typography variant="caption" color="text.secondary">
                                  (×{pair['left-quantity']})
                                </Typography>
                              </Box>
                              
                              <Typography variant="h6" color="text.secondary">
                                vs
                              </Typography>
                              
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <Chip 
                                  label={pair['right-action']} 
                                  color={pair['right-action'] === 'Buy' ? 'success' : 'error'}
                                  size="small"
                                  sx={{ fontWeight: 'bold' }}
                                />
                                <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                                  {pair['right-symbol']}
                                </Typography>
                                <Typography variant="caption" color="text.secondary">
                                  (×{pair['right-quantity']})
                                </Typography>
                              </Box>
                            </Box>
                          </CardContent>
                        </Card>
                      ))}
                    </Box>
                  </Box>
                ) : (
                  <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                    No trading pairs defined
                  </Typography>
                )}
                
                {watchlist['created-at'] && (
                  <Box sx={{ mt: 2, pt: 1, borderTop: '1px solid #e0e0e0' }}>
                    <Typography variant="caption" color="text.secondary">
                      Created: {formatDate(watchlist['created-at'])} | 
                      Updated: {formatDate(watchlist['updated-at'])}
                    </Typography>
                  </Box>
                )}
              </CardContent>
            </Card>
          ))}
        </Box>
      </Box>
    );
  };

  // Render regular watchlist data
  const renderWatchlists = (watchlistData: any) => {
    const items = watchlistData.data?.items || watchlistData.items || [];
    
    if (items.length === 0) {
      return (
        <Box>
          <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
            📋 My Watchlists
          </Typography>
          <Card>
            <CardContent>
              <Typography variant="body1" color="text.secondary" textAlign="center">
                No watchlists found. Create your first watchlist to start tracking symbols!
              </Typography>
            </CardContent>
          </Card>
        </Box>
      );
    }
    
    return (
      <Box>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          📋 My Watchlists ({items.length})
        </Typography>
        
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {items.map((watchlist: any, index: number) => (
            <Card key={index} sx={{ 
              width: '100%',
              '&:hover': { boxShadow: 4 },
              transition: 'box-shadow 0.2s ease-in-out'
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                  <Typography variant="h6" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                    📊 {watchlist.name}
                  </Typography>
                  <Chip 
                    label={`${watchlist['watchlist-entries']?.length || 0} symbols`}
                    color="secondary"
                    size="small"
                  />
                </Box>
                
                {watchlist['group-name'] && (
                  <Box sx={{ mb: 2 }}>
                    <Chip 
                      label={`Group: ${watchlist['group-name']}`}
                      color="info"
                      variant="outlined"
                      size="small"
                    />
                  </Box>
                )}
                
                {watchlist['watchlist-entries'] && watchlist['watchlist-entries'].length > 0 ? (
                  <Box>
                    <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 'medium' }}>
                      Tracked Symbols:
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                      {watchlist['watchlist-entries'].map((entry: any, entryIndex: number) => {
                        const colorMap: any = {
                          'Equity': 'primary',
                          'Option': 'secondary',
                          'Future': 'warning',
                          'Cryptocurrency': 'success'
                        };
                        
                        return (
                          <Chip
                            key={entryIndex}
                            label={entry.symbol}
                            color={colorMap[entry['instrument-type']] || 'default'}
                            variant="outlined"
                            size="small"
                            sx={{ fontWeight: 'medium' }}
                          />
                        );
                      })}
                    </Box>
                    
                    {/* Instrument type summary */}
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="caption" color="text.secondary">
                        Types: {
                          Array.from(new Set(watchlist['watchlist-entries'].map((e: any) => e['instrument-type'])))
                          .join(', ')
                        }
                      </Typography>
                    </Box>
                  </Box>
                ) : (
                  <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                    This watchlist is empty
                  </Typography>
                )}
              </CardContent>
            </Card>
          ))}
        </Box>
      </Box>
    );
  };

  // Main render logic based on endpoint type and data structure
  const renderResponse = () => {
    if (!data) return null;

    // Check for customer profile data
    if (data.data && (data.data.person || data.data['first-name'] || data.data.email)) {
      return renderCustomerProfile(data.data);
    }

    // Check for account balances
    if (data.data && (data.data['cash-balance'] || data.data['net-liquidating-value'] || data.data['equity-buying-power']) && 
        endpointName.toLowerCase().includes('balance')) {
      return renderAccountBalances(data);
    }

    // Check for positions data (must come before market data check)
    if ((data.data?.items && Array.isArray(data.data.items)) && endpointName.toLowerCase().includes('position')) {
      const firstItem = data.data.items[0];
      if (firstItem && (firstItem.symbol || firstItem['account-number'] || firstItem.quantity !== undefined)) {
        return renderPositions(data);
      }
    }

    // Check for balance snapshots data (must come before market data check)
    if ((data.data?.items && Array.isArray(data.data.items)) && 
        (endpointName.toLowerCase().includes('balance-snapshot') || endpointName.toLowerCase().includes('balance history'))) {
      const firstItem = data.data.items[0];
      if (firstItem && (firstItem['snapshot-date'] || firstItem['cash-balance'] || firstItem['total-equity'])) {
        return renderBalanceSnapshots(data);
      }
    }

    // Check for trading status data (must come before generic account check)
    if (endpointName.toLowerCase().includes('trading-status') || endpointName.toLowerCase().includes('trading status')) {
      return renderTradingStatus(data);
    }

    // Check for accounts data (must come before market data check)
    if ((data.data?.items && Array.isArray(data.data.items)) && endpointName.toLowerCase().includes('account')) {
      // Additional check to ensure it's account data and not market data
      const firstItem = data.data.items[0];
      if (firstItem && (firstItem.account || firstItem['account-number'] || firstItem['authority-level'])) {
        return renderAccounts(data);
      }
    }

    // Check for pairs watchlist data (must come before regular watchlist check)
    if ((data.data?.items && Array.isArray(data.data.items)) && endpointName.toLowerCase().includes('pairs')) {
      return renderPairsWatchlists(data);
    }

    // Check for regular watchlist data (must come before market data check)
    if ((data.data?.items && Array.isArray(data.data.items)) && endpointName.toLowerCase().includes('watchlist')) {
      return renderWatchlists(data);
    }

    // Check for search results
    if ((data.data?.items && Array.isArray(data.data.items)) && endpointName.toLowerCase().includes('search')) {
      return renderSearchResults(data);
    }

    // Check for market data
    if ((data.data?.items && Array.isArray(data.data.items)) || (data.items && Array.isArray(data.items))) {
      return renderMarketData(data);
    }

    // Fallback: show formatted JSON for other responses
    return (
      <Box>
        <Typography variant="h6" gutterBottom>
          📄 Response Data
        </Typography>
        <Card>
          <CardContent>
            <pre style={{ 
              whiteSpace: 'pre-wrap', 
              fontSize: '0.875rem',
              maxHeight: '400px',
              overflow: 'auto',
              backgroundColor: '#f5f5f5',
              padding: '16px',
              borderRadius: '4px',
              margin: 0
            }}>
              {JSON.stringify(data, null, 2)}
            </pre>
          </CardContent>
        </Card>
      </Box>
    );
  };

  return (
    <Box sx={{ mt: 2 }}>
      {renderResponse()}
    </Box>
  );
};

export default ResponseViewer;