import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { instrumentsApi } from '../../services/unifiedTestingApi';

const InstrumentsClientTab: React.FC = () => {
  const endpoints = [
    // ===== EQUITIES =====
    {
      name: 'Search Equities',
      method: 'GET' as const,
      path: '/instruments/equities',
      description: 'Search for equity instruments',
      buttonText: '🔍 Search Equities',
      parameters: [
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Symbol to search for',
          example: 'AAPL'
        },
        {
          name: 'lendability',
          type: 'query' as const,
          required: false,
          description: 'Lendability filter',
          example: 'Easy To Borrow'
        },
        {
          name: 'is-index',
          type: 'query' as const,
          required: false,
          description: 'Filter for index funds',
          example: 'true'
        },
        {
          name: 'is-etf',
          type: 'query' as const,
          required: false,
          description: 'Filter for ETFs',
          example: 'true'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.searchEquities(params);
        return response.data;
      }
    },
    {
      name: 'Get Equity',
      method: 'GET' as const,
      path: '/instruments/equities/{symbol}',
      description: 'Get specific equity by symbol',
      buttonText: '📈 Get Equity Details',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Equity symbol',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getEquity(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Create Equity',
      method: 'POST' as const,
      path: '/instruments/equities',
      description: 'Create a new equity instrument',
      buttonText: '➕ Create Equity',
      parameters: [
        {
          name: 'equityRequest',
          type: 'body' as const,
          required: true,
          description: 'Equity creation request body',
          example: '{"symbol": "TEST", "description": "Test Equity"}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.createEquity(JSON.parse(params.equityRequest));
        return response.data;
      }
    },
    {
      name: 'Get Active Equities',
      method: 'GET' as const,
      path: '/instruments/equities/active',
      description: 'Get active equity instruments',
      buttonText: '⚡ Get Active Equities',
      parameters: [
        {
          name: 'lendability',
          type: 'query' as const,
          required: false,
          description: 'Lendability filter',
          example: 'Easy To Borrow'
        },
        {
          name: 'per-page',
          type: 'query' as const,
          required: false,
          description: 'Results per page',
          example: '10'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getActiveEquities(params);
        return response.data;
      }
    },
    {
      name: 'Update Equity',
      method: 'PATCH' as const,
      path: '/instruments/equities/{symbol}',
      description: 'Update an equity instrument',
      buttonText: '✏️ Update Equity',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Equity symbol to update',
          example: 'AAPL'
        },
        {
          name: 'equityPatch',
          type: 'body' as const,
          required: true,
          description: 'Equity update request body',
          example: '{"description": "Updated Apple Inc."}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.updateEquity(params.symbol, JSON.parse(params.equityPatch));
        return response.data;
      }
    },

    // ===== FUTURES =====
    {
      name: 'Search Futures',
      method: 'GET' as const,
      path: '/instruments/futures',
      description: 'Search for futures instruments',
      buttonText: '🔍 Search Futures',
      parameters: [
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Symbol to search for',
          example: '/ES'
        },
        {
          name: 'product-code',
          type: 'query' as const,
          required: false,
          description: 'Product code filter',
          example: 'ES'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.searchFutures(params);
        return response.data;
      }
    },
    {
      name: 'Get Future',
      method: 'GET' as const,
      path: '/instruments/futures/{symbol}',
      description: 'Get specific future by symbol',
      buttonText: '📊 Get Future Details',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Future symbol (URL encoded)',
          example: '%2FESH25',
          defaultValue: '%2FESH25'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFuture(params.symbol);
        return response.data;
      }
    },

    // ===== OPTION CHAINS =====
    {
      name: 'Get Nested Option Chain',
      method: 'GET' as const,
      path: '/instruments/option-chains/{symbol}/nested',
      description: 'Get nested option chain for a symbol',
      buttonText: '🔗 Get Nested Option Chain',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Underlying symbol',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getNestedOptionChain(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Get Compact Option Chain',
      method: 'GET' as const,
      path: '/instruments/option-chains/{symbol}/compact',
      description: 'Get compact option chain for a symbol',
      buttonText: '📝 Get Compact Option Chain',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Underlying symbol',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getCompactOptionChain(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Get Detailed Option Chain',
      method: 'GET' as const,
      path: '/option-chains/{underlyingSymbol}',
      description: 'Get detailed option chain for underlying symbol',
      buttonText: '📋 Get Detailed Option Chain',
      parameters: [
        {
          name: 'underlyingSymbol',
          type: 'path' as const,
          required: true,
          description: 'Underlying symbol',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getDetailedOptionChain(params.underlyingSymbol);
        return response.data;
      }
    },
    {
      name: 'Get Option Detail for Single Option',
      method: 'GET' as const,
      path: '/option-chains/market-data/by-type',
      description: 'Get option details for a single option',
      buttonText: '🎯 Get Single Option Detail',
      parameters: [
        {
          name: 'equity-option',
          type: 'query' as const,
          required: true,
          description: 'Equity option symbol',
          example: 'AAPL  250117C00150000'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getOptionDetailForSingleOption(params['equity-option']);
        return response.data;
      }
    },

    // ===== EQUITY OPTIONS =====
    {
      name: 'Get Equity Options',
      method: 'GET' as const,
      path: '/instruments/equity-options',
      description: 'Get equity options, optionally filtered by symbol',
      buttonText: '🔍 Get Equity Options',
      parameters: [
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Symbol filter',
          example: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getEquityOptions(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Get Equity Option',
      method: 'GET' as const,
      path: '/instruments/equity-options/{symbol}',
      description: 'Get specific equity option by symbol',
      buttonText: '📈 Get Equity Option Details',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Equity option symbol',
          example: 'AAPL  250117C00150000'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getEquityOption(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Update Equity Option',
      method: 'PATCH' as const,
      path: '/instruments/equity-options/{symbol}',
      description: 'Update an equity option',
      buttonText: '✏️ Update Equity Option',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Equity option symbol to update',
          example: 'AAPL  250117C00150000'
        },
        {
          name: 'optionPatch',
          type: 'body' as const,
          required: true,
          description: 'Option update request body',
          example: '{"description": "Updated AAPL Call Option"}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.updateEquityOption(params.symbol, JSON.parse(params.optionPatch));
        return response.data;
      }
    },

    // ===== FUTURES OPTIONS =====
    {
      name: 'Get Futures Nested Option Chain',
      method: 'GET' as const,
      path: '/futures-option-chains/{underlyingSymbol}/nested',
      description: 'Get nested futures option chain',
      buttonText: '🔗 Get Futures Nested Option Chain',
      parameters: [
        {
          name: 'underlyingSymbol',
          type: 'path' as const,
          required: true,
          description: 'Underlying futures symbol (URL encoded)',
          example: '%2FESH25'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFuturesNestedOptionChain(params.underlyingSymbol);
        return response.data;
      }
    },
    {
      name: 'Get Futures Detailed Option Chain',
      method: 'GET' as const,
      path: '/futures-option-chains/{underlyingSymbol}',
      description: 'Get detailed futures option chain',
      buttonText: '📋 Get Futures Detailed Option Chain',
      parameters: [
        {
          name: 'underlyingSymbol',
          type: 'path' as const,
          required: true,
          description: 'Underlying futures symbol (URL encoded)',
          example: '%2FESH25'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFuturesDetailedOptionChain(params.underlyingSymbol);
        return response.data;
      }
    },
    {
      name: 'Get Future Options',
      method: 'GET' as const,
      path: '/instruments/future-options',
      description: 'Get future options, optionally filtered by symbol',
      buttonText: '🔍 Get Future Options',
      parameters: [
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Symbol filter',
          example: '/ESH25'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFutureOptions(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Get Future Option',
      method: 'GET' as const,
      path: '/instruments/future-options/{symbol}',
      description: 'Get specific future option by symbol',
      buttonText: '📊 Get Future Option Details',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Future option symbol (URL encoded)',
          example: '.%2FESH25C4950'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFutureOption(params.symbol);
        return response.data;
      }
    },

    // ===== FUTURE PRODUCTS =====
    {
      name: 'Get Future Products',
      method: 'GET' as const,
      path: '/instruments/future-products',
      description: 'Get all future products',
      buttonText: '📦 Get Future Products',
      apiCall: async () => {
        const response = await instrumentsApi.getFutureProducts();
        return response.data;
      }
    },
    {
      name: 'Get Future Product by Exchange & Code',
      method: 'GET' as const,
      path: '/instruments/future-products/{exchange}/{code}',
      description: 'Get future product by exchange and code',
      buttonText: '🏢 Get Future Product (Exchange/Code)',
      parameters: [
        {
          name: 'exchange',
          type: 'path' as const,
          required: true,
          description: 'Exchange',
          example: 'CME'
        },
        {
          name: 'code',
          type: 'path' as const,
          required: true,
          description: 'Product code',
          example: 'ES'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFutureProduct(params.exchange, params.code);
        return response.data;
      }
    },
    {
      name: 'Get Future Product by Code',
      method: 'GET' as const,
      path: '/instruments/future-products/{code}',
      description: 'Get future product by code only',
      buttonText: '🏷️ Get Future Product (Code Only)',
      parameters: [
        {
          name: 'code',
          type: 'path' as const,
          required: true,
          description: 'Product code',
          example: 'ES',
          defaultValue: 'ES'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFutureProductByCode(params.code);
        return response.data;
      }
    },
    {
      name: 'Update Future Product',
      method: 'PATCH' as const,
      path: '/instruments/future-products/{id}',
      description: 'Update a future product',
      buttonText: '✏️ Update Future Product',
      parameters: [
        {
          name: 'id',
          type: 'path' as const,
          required: true,
          description: 'Future product ID',
          example: '123'
        },
        {
          name: 'productPatch',
          type: 'body' as const,
          required: true,
          description: 'Product update request body',
          example: '{"description": "Updated ES product"}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.updateFutureProduct(params.id, JSON.parse(params.productPatch));
        return response.data;
      }
    },

    // ===== FUTURE OPTION PRODUCTS =====
    {
      name: 'Get Future Option Products',
      method: 'GET' as const,
      path: '/instruments/future-option-products',
      description: 'Get all future option products',
      buttonText: '📦 Get Future Option Products',
      apiCall: async () => {
        const response = await instrumentsApi.getFutureOptionProducts();
        return response.data;
      }
    },
    {
      name: 'Get Future Option Product by Exchange & Symbol',
      method: 'GET' as const,
      path: '/instruments/future-option-products/{exchange}/{rootSymbol}',
      description: 'Get future option product by exchange and root symbol',
      buttonText: '🏢 Get Future Option Product (Exchange/Symbol)',
      parameters: [
        {
          name: 'exchange',
          type: 'path' as const,
          required: true,
          description: 'Exchange',
          example: 'CME'
        },
        {
          name: 'rootSymbol',
          type: 'path' as const,
          required: true,
          description: 'Root symbol',
          example: 'ES'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFutureOptionProduct(params.exchange, params.rootSymbol);
        return response.data;
      }
    },
    {
      name: 'Get Future Option Product by Symbol',
      method: 'GET' as const,
      path: '/instruments/future-option-products/{rootSymbol}',
      description: 'Get future option product by root symbol only',
      buttonText: '🏷️ Get Future Option Product (Symbol Only)',
      parameters: [
        {
          name: 'rootSymbol',
          type: 'path' as const,
          required: true,
          description: 'Root symbol',
          example: 'ES',
          defaultValue: 'ES'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFutureOptionProductBySymbol(params.rootSymbol);
        return response.data;
      }
    },
    {
      name: 'Update Future Option Product',
      method: 'PATCH' as const,
      path: '/instruments/future-option-products/{id}',
      description: 'Update a future option product',
      buttonText: '✏️ Update Future Option Product',
      parameters: [
        {
          name: 'id',
          type: 'path' as const,
          required: true,
          description: 'Future option product ID',
          example: '456'
        },
        {
          name: 'productPatch',
          type: 'body' as const,
          required: true,
          description: 'Product update request body',
          example: '{"description": "Updated ES option product"}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.updateFutureOptionProduct(params.id, JSON.parse(params.productPatch));
        return response.data;
      }
    },

    // ===== CRYPTOCURRENCIES =====
    {
      name: 'Search Cryptocurrencies',
      method: 'GET' as const,
      path: '/instruments/cryptocurrencies',
      description: 'Search cryptocurrencies, optionally filtered by symbol',
      buttonText: '🪙 Search Cryptocurrencies',
      parameters: [
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Symbol filter',
          example: 'BTC/USD'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.searchCryptocurrencies(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Get Cryptocurrency',
      method: 'GET' as const,
      path: '/instruments/cryptocurrencies/{symbol}',
      description: 'Get specific cryptocurrency by symbol',
      buttonText: '💰 Get Cryptocurrency Details',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Cryptocurrency symbol',
          example: 'BTC/USD',
          defaultValue: 'BTC/USD'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getCryptocurrency(params.symbol);
        return response.data;
      }
    },

    // ===== BONDS =====
    {
      name: 'Get Bonds',
      method: 'GET' as const,
      path: '/instruments/bonds',
      description: 'Search bonds, optionally filtered by symbol',
      buttonText: '🏦 Search Bonds',
      parameters: [
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Symbol filter',
          example: 'BOND123'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getBonds(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Get Bond',
      method: 'GET' as const,
      path: '/instruments/bonds/{symbol}',
      description: 'Get specific bond by symbol',
      buttonText: '📜 Get Bond Details',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Bond symbol',
          example: 'BOND123'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getBond(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Update Bond',
      method: 'PATCH' as const,
      path: '/instruments/bonds/{symbol}',
      description: 'Update a bond',
      buttonText: '✏️ Update Bond',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Bond symbol to update',
          example: 'BOND123'
        },
        {
          name: 'bondPatch',
          type: 'body' as const,
          required: true,
          description: 'Bond update request body',
          example: '{"description": "Updated bond description"}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.updateBond(params.symbol, JSON.parse(params.bondPatch));
        return response.data;
      }
    },

    // ===== WARRANTS =====
    {
      name: 'Get Warrants',
      method: 'GET' as const,
      path: '/instruments/warrants',
      description: 'Search warrants, optionally filtered by symbol',
      buttonText: '📝 Search Warrants',
      parameters: [
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Symbol filter',
          example: 'WARRANT1'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getWarrants(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Get Warrant',
      method: 'GET' as const,
      path: '/instruments/warrants/{symbol}',
      description: 'Get specific warrant by symbol',
      buttonText: '🎟️ Get Warrant Details',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Warrant symbol',
          example: 'WARRANT1'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getWarrant(params.symbol);
        return response.data;
      }
    },
    {
      name: 'Update Warrant',
      method: 'PATCH' as const,
      path: '/instruments/warrants/{symbol}',
      description: 'Update a warrant',
      buttonText: '✏️ Update Warrant',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Warrant symbol to update',
          example: 'WARRANT1'
        },
        {
          name: 'warrantPatch',
          type: 'body' as const,
          required: true,
          description: 'Warrant update request body',
          example: '{"description": "Updated warrant description"}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.updateWarrant(params.symbol, JSON.parse(params.warrantPatch));
        return response.data;
      }
    },

    // ===== OTHER INSTRUMENTS =====
    {
      name: 'Get Quantity Decimal Precisions',
      method: 'GET' as const,
      path: '/instruments/quantity-decimal-precisions',
      description: 'Get quantity decimal precisions for instruments',
      buttonText: '🔢 Get Quantity Decimal Precisions',
      apiCall: async () => {
        const response = await instrumentsApi.getQuantityDecimalPrecisions();
        return response.data;
      }
    },
    {
      name: 'Get Instrument Lookup',
      method: 'GET' as const,
      path: '/instruments/lookup',
      description: 'Lookup instrument by various criteria',
      buttonText: '🔍 Instrument Lookup',
      parameters: [
        {
          name: 'active-at',
          type: 'query' as const,
          required: false,
          description: 'Active at date',
          example: '2025-01-15'
        },
        {
          name: 'exchange',
          type: 'query' as const,
          required: false,
          description: 'Exchange filter',
          example: 'NASDAQ'
        },
        {
          name: 'security-id',
          type: 'query' as const,
          required: false,
          description: 'Security ID',
          example: '12345'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getInstrumentLookup(params);
        return response.data;
      }
    },
    {
      name: 'Search Instruments',
      method: 'POST' as const,
      path: '/instruments/search',
      description: 'Search instruments with complex criteria',
      buttonText: '🔎 Advanced Instrument Search',
      parameters: [
        {
          name: 'searchRequest',
          type: 'body' as const,
          required: true,
          description: 'Search request body',
          example: '{"instrument-types": ["Equity"], "symbol": "AAPL"}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.searchInstruments(JSON.parse(params.searchRequest));
        return response.data;
      }
    },
    {
      name: 'Create Instrument',
      method: 'POST' as const,
      path: '/instruments',
      description: 'Create a new instrument',
      buttonText: '➕ Create Instrument',
      parameters: [
        {
          name: 'instrumentRequest',
          type: 'body' as const,
          required: true,
          description: 'Instrument creation request body',
          example: '{"symbol": "TEST", "instrument-type": "Equity"}'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.createInstrument(JSON.parse(params.instrumentRequest));
        return response.data;
      }
    },
    {
      name: 'Get Equity Deliverables',
      method: 'GET' as const,
      path: '/instruments/equity-deliverables',
      description: 'Get equity deliverables',
      buttonText: '📦 Get Equity Deliverables',
      parameters: [
        {
          name: 'root-symbol',
          type: 'query' as const,
          required: false,
          description: 'Root symbol filter',
          example: 'AAPL'
        },
        {
          name: 'page-offset',
          type: 'query' as const,
          required: false,
          description: 'Page offset',
          example: '0'
        },
        {
          name: 'per-page',
          type: 'query' as const,
          required: false,
          description: 'Results per page',
          example: '10'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getEquityDeliverables(params);
        return response.data;
      }
    },
    {
      name: 'Get Fixed Income Securities',
      method: 'GET' as const,
      path: '/instruments/fixed-income-securities',
      description: 'Get fixed income securities',
      buttonText: '🏛️ Get Fixed Income Securities',
      parameters: [
        {
          name: 'page-offset',
          type: 'query' as const,
          required: false,
          description: 'Page offset',
          example: '0'
        },
        {
          name: 'per-page',
          type: 'query' as const,
          required: false,
          description: 'Results per page',
          example: '10'
        },
        {
          name: 'active',
          type: 'query' as const,
          required: false,
          description: 'Active filter',
          example: 'true'
        },
        {
          name: 'is-closing-only',
          type: 'query' as const,
          required: false,
          description: 'Closing only filter',
          example: 'false'
        },
        {
          name: 'maturity-date-after',
          type: 'query' as const,
          required: false,
          description: 'Maturity date after',
          example: '2025-01-01'
        },
        {
          name: 'maturity-date-before',
          type: 'query' as const,
          required: false,
          description: 'Maturity date before',
          example: '2026-12-31'
        },
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Symbol filter',
          example: 'FIS123'
        }
      ],
      apiCall: async (params: any) => {
        const response = await instrumentsApi.getFixedIncomeSecurities(params);
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Instruments Client"
      endpoints={endpoints}
    />
  );
};

export default InstrumentsClientTab;