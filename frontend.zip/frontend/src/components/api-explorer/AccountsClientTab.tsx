import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { accountsApi } from '../../services/unifiedTestingApi';

const AccountsClientTab: React.FC = () => {
  const endpoints = [
    {
      name: 'Customer Profile',
      method: 'GET' as const,
      path: '/customers/me',
      description: 'View your customer profile information and account details',
      buttonText: 'Get My Profile',
      apiCall: async () => {
        const response = await accountsApi.getCustomerInfo();
        return response.data;
      }
    },
    {
      name: 'My Accounts',
      method: 'GET' as const,
      path: '/customers/me/accounts',
      description: 'View all your trading accounts and their basic information',
      buttonText: 'Get My Accounts',
      apiCall: async () => {
        const response = await accountsApi.getCustomerAccounts();
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="My Profile & Accounts"
      endpoints={endpoints}
    />
  );
};

export default AccountsClientTab;