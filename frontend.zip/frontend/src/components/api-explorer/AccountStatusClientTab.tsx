import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { accountStatusApi } from '../../services/unifiedTestingApi';

const AccountStatusClientTab: React.FC = () => {
  const endpoints = [
    {
      name: 'Account Trading Status',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/trading-status',
      description: 'View current trading status and permissions for your account',
      buttonText: 'Check Trading Status',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number to check trading status',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await accountStatusApi.getAccountTradingStatus(params.accountNumber || '5WZ51117');
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Account Status & Permissions"
      endpoints={endpoints}
    />
  );
};

export default AccountStatusClientTab;