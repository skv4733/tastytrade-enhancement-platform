import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { searchSymbolsApi } from '../../services/unifiedTestingApi';

const SearchSymbolsClientTab: React.FC = () => {
  const endpoints = [
    {
      name: 'General Symbol Search',
      method: 'GET' as const,
      path: '/symbols/search/{symbol}',
      description: 'Search for any type of trading symbol (stocks, futures, options, etc.)',
      buttonText: 'Search Symbol',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Enter a symbol to search for',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await searchSymbolsApi.searchSymbols(params.symbol || 'AAPL');
        return response.data;
      }
    },
    {
      name: 'Stock Symbol Search',
      method: 'GET' as const,
      path: '/symbols/search/equity/{symbol}',
      description: 'Find stocks and equity instruments by symbol or company name',
      buttonText: 'Search Stocks',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Stock symbol or partial name',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await searchSymbolsApi.searchEquitySymbols(params.symbol || 'AAPL');
        return response.data;
      }
    },
    {
      name: 'Futures Symbol Search',
      method: 'GET' as const,
      path: '/symbols/search/futures/{symbol}',
      description: 'Search for futures contracts (ES for S&P 500, NQ for Nasdaq, CL for Crude Oil, etc.)',
      buttonText: 'Search Futures',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Futures symbol (e.g., ES, NQ, CL)',
          example: 'ES',
          defaultValue: 'ES'
        }
      ],
      apiCall: async (params: any) => {
        const response = await searchSymbolsApi.searchFuturesSymbols(params.symbol || 'ES');
        return response.data;
      }
    },
    {
      name: 'Options Symbol Search',
      method: 'GET' as const,
      path: '/symbols/search/options/{symbol}',
      description: 'Find options contracts and underlying symbols for option trading',
      buttonText: 'Search Options',
      parameters: [
        {
          name: 'symbol',
          type: 'path' as const,
          required: true,
          description: 'Underlying symbol for options',
          example: 'AAPL',
          defaultValue: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const response = await searchSymbolsApi.searchOptionSymbols(params.symbol || 'AAPL');
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Symbol Search & Discovery"
      endpoints={endpoints}
    />
  );
};

export default SearchSymbolsClientTab;