import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { watchlistsApi } from '../../services/unifiedTestingApi';

const WatchlistsClientTab: React.FC = () => {
  const endpoints = [
    {
      name: 'Get Public Watchlists',
      method: 'GET' as const,
      path: '/public-watchlists',
      description: 'Get all public watchlists available',
      buttonText: 'Get Public Watchlists',
      apiCall: async () => {
        const response = await watchlistsApi.getPublicWatchlists();
        return response.data;
      }
    },
    {
      name: 'Get Account Watchlists',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/watchlists',
      description: 'Get watchlists for a specific account',
      buttonText: 'Get My Watchlists',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Account number to get watchlists for',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await watchlistsApi.getAccountWatchlists(params.accountNumber);
        return response.data;
      }
    },
    {
      name: 'Get All Watchlists',
      method: 'GET' as const,
      path: '/watchlists',
      description: 'Get all watchlists for the current user',
      buttonText: 'Get All Watchlists',
      apiCall: async () => {
        const response = await watchlistsApi.getWatchlists();
        return response.data;
      }
    },
    {
      name: 'Get Pairs Watchlists',
      method: 'GET' as const,
      path: '/pairs-watchlists',
      description: 'Get pairs trading watchlists',
      buttonText: 'Get Pairs Watchlists',
      apiCall: async () => {
        const response = await watchlistsApi.getPairsWatchlists();
        return response.data;
      }
    },
    {
      name: 'Get Watchlist By ID',
      method: 'GET' as const,
      path: '/watchlists/{watchlistId}',
      description: 'Get a specific watchlist by its ID',
      buttonText: 'Get Watchlist Details',
      parameters: [
        {
          name: 'watchlistId',
          type: 'path' as const,
          required: true,
          description: 'Watchlist ID to retrieve',
          example: '12345',
          defaultValue: '12345'
        }
      ],
      apiCall: async (params: any) => {
        const response = await watchlistsApi.getWatchlistById(params.watchlistId);
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Watchlists Client"
      endpoints={endpoints}
    />
  );
};

export default WatchlistsClientTab;