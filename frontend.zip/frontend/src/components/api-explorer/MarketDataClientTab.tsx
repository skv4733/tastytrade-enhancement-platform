import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { marketDataApi } from '../../services/unifiedTestingApi';

const MarketDataClientTab: React.FC = () => {
  const endpoints = [
    {
      name: 'Live Market Data',
      method: 'GET' as const,
      path: '/market-data/by-type',
      description: 'Get real-time market data for stocks, options, futures, and other instruments',
      buttonText: 'Get Market Data',
      parameters: [
        {
          name: 'equity',
          type: 'query' as const,
          required: false,
          description: 'Stock symbols (comma-separated)',
          example: 'AAPL,MSFT,GOOGL',
          defaultValue: 'AAPL'
        },
        {
          name: 'equityOption',
          type: 'query' as const,
          required: false,
          description: 'Equity option symbols',
          example: 'AAPL  250117C00150000'
        },
        {
          name: 'future',
          type: 'query' as const,
          required: false,
          description: 'Futures symbols',
          example: '/ESH25,/NQH25'
        },
        {
          name: 'futureOption',
          type: 'query' as const,
          required: false,
          description: 'Futures option symbols',
          example: './ESH25 240315C4600'
        },
        {
          name: 'cryptocurrency',
          type: 'query' as const,
          required: false,
          description: 'Cryptocurrency pairs',
          example: 'BTC/USD,ETH/USD'
        },
        {
          name: 'bond',
          type: 'query' as const,
          required: false,
          description: 'Bond symbols',
          example: 'TLT'
        },
        {
          name: 'warrant',
          type: 'query' as const,
          required: false,
          description: 'Warrant symbols',
          example: 'TWTRW'
        }
      ],
      apiCall: async (params: any) => {
        const cleanParams = Object.fromEntries(
          Object.entries(params).filter(([_, value]) => value !== '')
        );
        // If no parameters provided, default to AAPL
        if (Object.keys(cleanParams).length === 0) {
          cleanParams.equity = 'AAPL';
        }
        const response = await marketDataApi.getMarketDataByType(cleanParams);
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Real-Time Market Data"
      endpoints={endpoints}
    />
  );
};

export default MarketDataClientTab;