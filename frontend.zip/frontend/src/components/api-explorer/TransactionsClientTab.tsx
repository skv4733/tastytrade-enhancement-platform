import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { transactionsApi } from '../../services/unifiedTestingApi';

const TransactionsClientTab: React.FC = () => {
  const endpoints = [
    {
      name: 'Account Transactions',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/transactions',
      description: 'View your trading history and transaction details',
      buttonText: 'Get Transactions',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Your account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'startDate',
          type: 'query' as const,
          required: false,
          description: 'Filter transactions from this date (YYYY-MM-DD)',
          example: '2024-01-01'
        },
        {
          name: 'endDate',
          type: 'query' as const,
          required: false,
          description: 'Filter transactions to this date (YYYY-MM-DD)',
          example: '2024-12-31'
        },
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Filter by specific symbol',
          example: 'AAPL'
        },
        {
          name: 'type',
          type: 'query' as const,
          required: false,
          description: 'Filter by transaction type',
          example: 'Trade'
        }
      ],
      apiCall: async (params: any) => {
        const cleanParams = Object.fromEntries(
          Object.entries(params).filter(([_, value]) => value !== '')
        );
        const response = await transactionsApi.getAccountTransactions(
          params.accountNumber || '5WZ51117', 
          cleanParams
        );
        return response.data;
      }
    },
    {
      name: 'Transaction Details',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/transactions/{transactionId}',
      description: 'Get detailed information about a specific transaction',
      buttonText: 'Get Transaction Details',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Your account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'transactionId',
          type: 'path' as const,
          required: true,
          description: 'The specific transaction ID to lookup',
          example: '12345'
        }
      ],
      apiCall: async (params: any) => {
        const response = await transactionsApi.getAccountTransaction(
          params.accountNumber || '5WZ51117',
          params.transactionId
        );
        return response.data;
      }
    },
    {
      name: 'Total Transaction Fees',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/transactions/total-fees',
      description: 'Calculate total trading fees for your account',
      buttonText: 'Calculate Total Fees',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Your account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'startDate',
          type: 'query' as const,
          required: false,
          description: 'Calculate fees from this date (YYYY-MM-DD)',
          example: '2024-01-01'
        },
        {
          name: 'endDate',
          type: 'query' as const,
          required: false,
          description: 'Calculate fees to this date (YYYY-MM-DD)',
          example: '2024-12-31'
        },
        {
          name: 'symbol',
          type: 'query' as const,
          required: false,
          description: 'Calculate fees for specific symbol only',
          example: 'AAPL'
        }
      ],
      apiCall: async (params: any) => {
        const cleanParams = Object.fromEntries(
          Object.entries(params).filter(([_, value]) => value !== '')
        );
        const response = await transactionsApi.getTotalTransactionFees(
          params.accountNumber || '5WZ51117',
          cleanParams
        );
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Transactions"
      endpoints={endpoints}
    />
  );
};

export default TransactionsClientTab;