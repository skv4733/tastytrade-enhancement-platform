import React from 'react';
import ApiTestComponent from './ApiTestComponent';
import { accountBalanceAndPositionsApi } from '../../services/unifiedTestingApi';

const AccountBalanceAndPositionsClientTab: React.FC = () => {
  const endpoints = [
    {
      name: 'Account Balances',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/balances',
      description: 'View your current cash balances, buying power, and account values',
      buttonText: 'Get Account Balances',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Your account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await accountBalanceAndPositionsApi.getAccountBalances(params.accountNumber || '5WZ51117');
        return response.data;
      }
    },
    {
      name: 'Current Positions',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/positions',
      description: 'View all your current stock, option, and futures positions',
      buttonText: 'Get My Positions',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Your account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        }
      ],
      apiCall: async (params: any) => {
        const response = await accountBalanceAndPositionsApi.getAccountPositions(params.accountNumber || '5WZ51117');
        return response.data;
      }
    },
    {
      name: 'Balance History',
      method: 'GET' as const,
      path: '/accounts/{accountNumber}/balance-snapshots',
      description: 'View historical balance snapshots and account performance over time',
      buttonText: 'Get Balance History',
      parameters: [
        {
          name: 'accountNumber',
          type: 'path' as const,
          required: true,
          description: 'Your account number',
          example: '5WZ51117',
          defaultValue: '5WZ51117'
        },
        {
          name: 'snapshotDate',
          type: 'query' as const,
          required: false,
          description: 'Specific snapshot date (YYYY-MM-DD)',
          example: '2024-01-15'
        }
      ],
      apiCall: async (params: any) => {
        const response = await accountBalanceAndPositionsApi.getBalanceSnapshots(
          params.accountNumber || '5WZ51117', 
          params.snapshotDate
        );
        return response.data;
      }
    }
  ];

  return (
    <ApiTestComponent
      title="Balance & Positions"
      endpoints={endpoints}
    />
  );
};

export default AccountBalanceAndPositionsClientTab;