import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { accountApi } from '../services/api';
import { ApiResponse, CustomerInfoResponse, CustomerData } from '../types/api';
import Tooltip from './Tooltip';
import { getDefinition } from '../utils/financialDefinitions';

const CustomerInfo: React.FC = () => {
  const [customerData, setCustomerData] = useState<CustomerData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>(''); 
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCustomerInfo = async () => {
      try {
        setLoading(true);
        const response: ApiResponse<CustomerInfoResponse> = await accountApi.getCustomerInfo();
        
        if (response.success && response.data) {
          setCustomerData(response.data.data);
        } else {
          setError(response.message || 'Failed to fetch customer information');
        }
      } catch (err) {
        setError('Error fetching customer information: ' + (err as Error).message);
      } finally {
        setLoading(false);
      }
    };

    fetchCustomerInfo();
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="customer-profile-dashboard">
        <div className="dashboard-loading">
          <div className="loading-icon">👤</div>
          <h2>Loading Customer Profile</h2>
          <p>Gathering your personal information...</p>
          <div className="loading-spinner"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="customer-profile-dashboard">
        <div className="dashboard-error">
          <div className="error-icon">⚠️</div>
          <h2>Customer Profile</h2>
          <p className="error-message">{error}</p>
          <button onClick={() => window.location.reload()} className="retry-btn">
            🔄 Retry Loading
          </button>
        </div>
      </div>
    );
  }

  if (!customerData) {
    return (
      <div className="customer-profile-dashboard">
        <div className="empty-state">
          <div className="empty-icon">👤</div>
          <h2>No Customer Data</h2>
          <p>Customer information is not available at this time.</p>
        </div>
      </div>
    );
  }

  const getExperienceLevel = (experience: string) => {
    switch (experience?.toLowerCase()) {
      case 'extensive': return { level: 'Expert', color: 'expert', icon: '🏆' };
      case 'good': return { level: 'Advanced', color: 'advanced', icon: '📈' };
      case 'limited': return { level: 'Intermediate', color: 'intermediate', icon: '📊' };
      case 'none': return { level: 'Beginner', color: 'beginner', icon: '🌱' };
      default: return { level: 'Not Specified', color: 'unknown', icon: '❓' };
    }
  };

  return (
    <div className="customer-dashboard">
      {/* Header Section */}
      <div className="customer-header">
        <div className="dashboard-header">
          <div className="header-section">
            <div className="section-title">Customer Profile</div>
            <div className="customer-name">{customerData['first-name']} {customerData['last-name']}</div>
          </div>
          
          <div className="header-metrics">
            <div className="metric-group">
              <div className="metric-label">Customer ID</div>
              <div className="metric-value">{customerData.id}</div>
            </div>
            
            <div className="metric-group">
              <div className="metric-label">Member Since</div>
              <div className="metric-value">{new Date(customerData['created-at']).getFullYear()}</div>
            </div>
            
            <div className="metric-group">
              <div className="metric-label">Account Type</div>
              <div className="metric-value">{customerData['is-professional'] ? 'Professional' : 'Retail'}</div>
            </div>
            
            <div className="metric-group">
              <div className="metric-label">Country</div>
              <div className="metric-value">{customerData['citizenship-country']}</div>
            </div>
          </div>
          
          <div className="header-status">
            <div className="status-indicator">
              <span className={`status-dot ${customerData['agreed-to-terms'] ? 'verified' : 'pending'}`}></span>
              <span className="status-label">{customerData['agreed-to-terms'] ? 'Verified' : 'Pending'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Information */}
      <div className="content-section">
        <div className="section-title">Contact Information</div>
        <div className="data-grid">
          <div className="data-card">
            <div className="data-label">Email Address</div>
            <div className="data-value">{customerData.email}</div>
          </div>
          <div className="data-card">
            <div className="data-label">Mobile Phone</div>
            <div className="data-value">{customerData['mobile-phone-number'] || 'Not provided'}</div>
          </div>
          <div className="data-card">
            <div className="data-label">Birth Date</div>
            <div className="data-value">{customerData['birth-date'] ? formatDate(customerData['birth-date']) : 'Not provided'}</div>
          </div>
        </div>
      </div>

      {/* Address Information */}
      <div className="content-section">
        <div className="section-title">Address Information</div>
        {customerData.address ? (
          <div className="address-display">
            <div className="address-content">
              <div className="address-line">{customerData.address['street-one']}</div>
              {customerData.address['street-two'] && (
                <div className="address-line">{customerData.address['street-two']}</div>
              )}
              <div className="address-line">
                {customerData.address.city}, {customerData.address['state-region']} {customerData.address['postal-code']}
              </div>
              <div className="address-line">{customerData.address.country}</div>
            </div>
          </div>
        ) : (
          <div className="empty-state">No address information available</div>
        )}
      </div>

      {/* Financial Information */}
      {customerData['customer-suitability'] && (
        <div className="content-section">
          <div className="section-title">Financial Profile</div>
          <div className="data-grid">
            <div className="data-card">
              <div className="data-label">Annual Net Income</div>
              <div className="data-value primary">
                {customerData['customer-suitability']['annual-net-income'] 
                  ? formatCurrency(customerData['customer-suitability']['annual-net-income']) 
                  : 'Not Disclosed'}
              </div>
            </div>
            
            <div className="data-card">
              <div className="data-label">Total Net Worth</div>
              <div className="data-value primary">
                {customerData['customer-suitability']['net-worth'] 
                  ? formatCurrency(customerData['customer-suitability']['net-worth']) 
                  : 'Not Disclosed'}
              </div>
            </div>
            
            <div className="data-card">
              <div className="data-label">Liquid Net Worth</div>
              <div className="data-value primary">
                {customerData['customer-suitability']['liquid-net-worth'] 
                  ? formatCurrency(customerData['customer-suitability']['liquid-net-worth']) 
                  : 'Not Disclosed'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Employment Information */}
      {customerData['customer-suitability'] && (
        <div className="content-section">
          <div className="section-title">Employment Information</div>
          <div className="data-grid">
            <div className="data-card">
              <div className="data-label">Employment Status</div>
              <div className="data-value">
                {customerData['customer-suitability']['employment-status']?.toUpperCase() || 'Not Specified'}
              </div>
            </div>
            <div className="data-card">
              <div className="data-label">Employer</div>
              <div className="data-value">{customerData['customer-suitability']['employer-name'] || 'Not Provided'}</div>
            </div>
            <div className="data-card">
              <div className="data-label">Job Title</div>
              <div className="data-value">{customerData['customer-suitability']['job-title'] || 'Not Provided'}</div>
            </div>
            <div className="data-card">
              <div className="data-label">Occupation</div>
              <div className="data-value">{customerData['customer-suitability'].occupation || 'Not Specified'}</div>
            </div>
          </div>
        </div>
      )}

      {/* Personal Details */}
      {customerData['customer-suitability'] && (
        <div className="content-section">
          <div className="section-title">Personal Details</div>
          <div className="data-grid">
            <div className="data-card">
              <div className="data-label">Marital Status</div>
              <div className="data-value">{customerData['customer-suitability']['marital-status'] || 'Not Specified'}</div>
            </div>
            <div className="data-card">
              <div className="data-label">Dependents</div>
              <div className="data-value">{customerData['customer-suitability']['number-of-dependents'] || 'Not Specified'}</div>
            </div>
            <div className="data-card">
              <div className="data-label">Tax ID Type</div>
              <div className="data-value">{customerData['tax-number-type'] || 'Not Specified'}</div>
            </div>
            <div className="data-card">
              <div className="data-label">Citizenship</div>
              <div className="data-value">{customerData['usa-citizenship-type'] || 'Not Specified'}</div>
            </div>
          </div>
        </div>
      )}

      {/* Trading Experience */}
      {customerData['customer-suitability'] && (
        <div className="content-section">
          <div className="section-title">Trading Experience</div>
          <div className="data-grid">
            <div className="data-card">
              <div className="data-label">Stock Trading</div>
              <div className="data-value">
                {getExperienceLevel(customerData['customer-suitability']['stock-trading-experience']).level}
              </div>
            </div>
            
            <div className="data-card">
              <div className="data-label">Covered Options</div>
              <div className="data-value">
                {getExperienceLevel(customerData['customer-suitability']['covered-options-trading-experience']).level}
              </div>
            </div>
            
            <div className="data-card">
              <div className="data-label">Uncovered Options</div>
              <div className="data-value">
                {getExperienceLevel(customerData['customer-suitability']['uncovered-options-trading-experience']).level}
              </div>
            </div>
            
            <div className="data-card">
              <div className="data-label">Futures Trading</div>
              <div className="data-value">
                {getExperienceLevel(customerData['customer-suitability']['futures-trading-experience']).level}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Account Status */}
      <div className="content-section">
        <div className="section-title">Account Status</div>
        <div className="data-grid">
          <div className="data-card">
            <div className="data-label">Terms & Conditions</div>
            <div className={`data-value ${customerData['agreed-to-terms'] ? 'positive' : 'negative'}`}>
              {customerData['agreed-to-terms'] ? 'Agreed' : 'Not Agreed'}
            </div>
          </div>
          
          <div className="data-card">
            <div className="data-label">Margin Trading</div>
            <div className={`data-value ${customerData['agreed-to-margining'] ? 'positive' : 'negative'}`}>
              {customerData['agreed-to-margining'] ? 'Approved' : 'Not Approved'}
            </div>
          </div>
          
          <div className="data-card">
            <div className="data-label">Application Status</div>
            <div className="data-value">
              {customerData['has-pending-or-approved-application'] ? 'Active' : 'None'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerInfo;