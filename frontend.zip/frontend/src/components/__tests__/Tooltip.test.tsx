import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import Tooltip from '../Tooltip';

// Mock getBoundingClientRect for positioning tests
const mockGetBoundingClientRect = jest.fn();
HTMLElement.prototype.getBoundingClientRect = mockGetBoundingClientRect;

// Mock window dimensions
Object.defineProperty(window, 'innerWidth', {
  writable: true,
  configurable: true,
  value: 1024,
});

Object.defineProperty(window, 'innerHeight', {
  writable: true,
  configurable: true,
  value: 768,
});

describe('Tooltip Component', () => {
  beforeEach(() => {
    mockGetBoundingClientRect.mockReset();
  });

  test('renders children correctly', () => {
    render(
      <Tooltip content="Test tooltip content">
        <button>Hover me</button>
      </Tooltip>
    );

    expect(screen.getByText('Hover me')).toBeInTheDocument();
  });

  test('shows tooltip on hover', async () => {
    render(
      <Tooltip content="Test tooltip content">
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    
    // Initially tooltip should not be visible
    expect(screen.queryByText('Test tooltip content')).not.toBeInTheDocument();

    // Hover to show tooltip
    fireEvent.mouseEnter(trigger);
    
    await waitFor(() => {
      expect(screen.getByText('Test tooltip content')).toBeInTheDocument();
    });
  });

  test('hides tooltip on mouse leave', async () => {
    render(
      <Tooltip content="Test tooltip content">
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    
    // Show tooltip
    fireEvent.mouseEnter(trigger);
    await waitFor(() => {
      expect(screen.getByText('Test tooltip content')).toBeInTheDocument();
    });

    // Hide tooltip
    fireEvent.mouseLeave(trigger);
    await waitFor(() => {
      expect(screen.queryByText('Test tooltip content')).not.toBeInTheDocument();
    });
  });

  test('uses fixed position when specified', async () => {
    render(
      <Tooltip content="Test tooltip content" position="top">
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    fireEvent.mouseEnter(trigger);
    
    await waitFor(() => {
      const tooltip = screen.getByText('Test tooltip content').closest('.tooltip');
      expect(tooltip).toHaveClass('tooltip-top');
    });
  });

  test('auto-positions tooltip when position="auto"', async () => {
    // Mock element positioning - tooltip near top of screen
    mockGetBoundingClientRect
      .mockReturnValueOnce({
        top: 50,
        bottom: 70,
        left: 100,
        right: 200,
        width: 100,
        height: 20,
      }) // wrapper element
      .mockReturnValueOnce({
        width: 200,
        height: 40,
      }); // tooltip element

    render(
      <Tooltip content="Test tooltip content" position="auto">
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    fireEvent.mouseEnter(trigger);
    
    await waitFor(() => {
      const tooltip = screen.getByText('Test tooltip content').closest('.tooltip');
      // Should position below when there's not enough space above
      expect(tooltip).toHaveClass('tooltip-bottom');
    });
  });

  test('positions tooltip to the right when no vertical space', async () => {
    // Mock element positioning - tooltip in middle of screen
    mockGetBoundingClientRect
      .mockReturnValueOnce({
        top: 400,
        bottom: 420,
        left: 100,
        right: 200,
        width: 100,
        height: 20,
      }) // wrapper element
      .mockReturnValueOnce({
        width: 200,
        height: 100, // Large tooltip that won't fit above or below
      }); // tooltip element

    render(
      <Tooltip content="This is a long tooltip content that requires more space" position="auto">
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    fireEvent.mouseEnter(trigger);
    
    await waitFor(() => {
      const tooltip = screen.getByText('This is a long tooltip content that requires more space').closest('.tooltip');
      // Should position to the right when no vertical space
      expect(tooltip).toHaveClass('tooltip-right');
    });
  });

  test('positions tooltip to the left when no space on right', async () => {
    // Mock element positioning - near right edge of screen
    mockGetBoundingClientRect
      .mockReturnValueOnce({
        top: 400,
        bottom: 420,
        left: 900,
        right: 1000,
        width: 100,
        height: 20,
      }) // wrapper element near right edge
      .mockReturnValueOnce({
        width: 200,
        height: 100,
      }); // tooltip element

    render(
      <Tooltip content="Test tooltip content" position="auto">
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    fireEvent.mouseEnter(trigger);
    
    await waitFor(() => {
      const tooltip = screen.getByText('Test tooltip content').closest('.tooltip');
      // Should position to the left when no space on right
      expect(tooltip).toHaveClass('tooltip-left');
    });
  });

  test('applies custom className', () => {
    render(
      <Tooltip content="Test tooltip content" className="custom-tooltip">
        <button>Hover me</button>
      </Tooltip>
    );

    const wrapper = screen.getByText('Hover me').closest('.tooltip-wrapper');
    expect(wrapper).toHaveClass('custom-tooltip');
  });

  test('tooltip has smart styling class', async () => {
    render(
      <Tooltip content="Test tooltip content">
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    fireEvent.mouseEnter(trigger);
    
    await waitFor(() => {
      const tooltip = screen.getByText('Test tooltip content').closest('.tooltip');
      expect(tooltip).toHaveClass('tooltip-smart');
    });
  });

  test('tooltip appears with animation', async () => {
    render(
      <Tooltip content="Test tooltip content">
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    fireEvent.mouseEnter(trigger);
    
    await waitFor(() => {
      const tooltip = screen.getByText('Test tooltip content').closest('.tooltip');
      expect(tooltip).toHaveStyle('animation: tooltip-appear 0.2s ease-out');
    });
  });

  test('handles long content properly', async () => {
    const longContent = "This is a very long tooltip content that should wrap properly within the maximum width constraints and display correctly without breaking the layout or causing overflow issues in the user interface.";
    
    render(
      <Tooltip content={longContent}>
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    fireEvent.mouseEnter(trigger);
    
    await waitFor(() => {
      expect(screen.getByText(longContent)).toBeInTheDocument();
    });
  });

  test('tooltip arrow is positioned correctly', async () => {
    render(
      <Tooltip content="Test tooltip content" position="top">
        <button>Hover me</button>
      </Tooltip>
    );

    const trigger = screen.getByText('Hover me');
    fireEvent.mouseEnter(trigger);
    
    await waitFor(() => {
      const tooltip = screen.getByText('Test tooltip content').closest('.tooltip');
      const arrow = tooltip?.querySelector('.tooltip-arrow');
      expect(arrow).toBeInTheDocument();
    });
  });

  describe('Edge Cases', () => {
    test('handles empty content gracefully', async () => {
      render(
        <Tooltip content="">
          <button>Hover me</button>
        </Tooltip>
      );

      const trigger = screen.getByText('Hover me');
      fireEvent.mouseEnter(trigger);
      
      // Should still render tooltip but with empty content
      await waitFor(() => {
        const tooltip = document.querySelector('.tooltip');
        expect(tooltip).toBeInTheDocument();
      });
    });

    test('handles rapid hover events', async () => {
      render(
        <Tooltip content="Test tooltip content">
          <button>Hover me</button>
        </Tooltip>
      );

      const trigger = screen.getByText('Hover me');
      
      // Rapidly hover and leave
      fireEvent.mouseEnter(trigger);
      fireEvent.mouseLeave(trigger);
      fireEvent.mouseEnter(trigger);
      
      await waitFor(() => {
        expect(screen.getByText('Test tooltip content')).toBeInTheDocument();
      });
    });

    test('works with different viewport sizes', async () => {
      // Test mobile viewport
      Object.defineProperty(window, 'innerWidth', {
        writable: true,
        configurable: true,
        value: 375,
      });

      Object.defineProperty(window, 'innerHeight', {
        writable: true,
        configurable: true,
        value: 667,
      });

      mockGetBoundingClientRect
        .mockReturnValueOnce({
          top: 300,
          bottom: 320,
          left: 50,
          right: 150,
          width: 100,
          height: 20,
        })
        .mockReturnValueOnce({
          width: 200,
          height: 40,
        });

      render(
        <Tooltip content="Test tooltip content" position="auto">
          <button>Hover me</button>
        </Tooltip>
      );

      const trigger = screen.getByText('Hover me');
      fireEvent.mouseEnter(trigger);
      
      await waitFor(() => {
        const tooltip = screen.getByText('Test tooltip content').closest('.tooltip');
        expect(tooltip).toBeInTheDocument();
      });
    });
  });

  describe('Accessibility', () => {
    test('tooltip content is accessible', async () => {
      render(
        <Tooltip content="Accessible tooltip content">
          <button>Accessible button</button>
        </Tooltip>
      );

      const trigger = screen.getByText('Accessible button');
      fireEvent.mouseEnter(trigger);
      
      await waitFor(() => {
        const tooltipContent = screen.getByText('Accessible tooltip content');
        expect(tooltipContent).toBeInTheDocument();
        // Tooltip should be readable by screen readers
        expect(tooltipContent).toBeVisible();
      });
    });

    test('supports keyboard navigation', async () => {
      render(
        <Tooltip content="Test tooltip content">
          <button>Focusable button</button>
        </Tooltip>
      );

      const trigger = screen.getByText('Focusable button');
      
      // Focus should work
      trigger.focus();
      expect(trigger).toHaveFocus();
    });
  });
});