import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import '@testing-library/jest-dom';
import AccountBalances from '../AccountBalances';
import AccountPositions from '../AccountPositions';
import AccountDetail from '../AccountDetail';
import { accountApi } from '../../services/api';

// Mock the API
jest.mock('../../services/api');
const mockAccountApi = accountApi as jest.Mocked<typeof accountApi>;

// Mock react-router-dom
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useParams: () => ({ accountNumber: '5WZ51117' }),
  useNavigate: () => mockNavigate,
}));

// Test wrapper component
const TestWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <BrowserRouter>{children}</BrowserRouter>
);

// Mock data
const mockAccountData = {
  success: true,
  accounts: [
    {
      info: {
        'account-number': '5WZ51117',
        nickname: 'Test Account',
        'account-type-name': 'Individual',
        'is-closed': false,
        'margin-or-cash': 'Margin',
        'day-trader-status': true,
        'is-futures-approved': true,
        'suitable-options-level': 3,
        'created-at': '2023-01-01T00:00:00Z',
        'opened-at': '2023-01-01T00:00:00Z',
        'funding-date': '2023-01-01T00:00:00Z',
      },
      balances: {
        data: {
          'net-liquidating-value': 100000,
          'cash-balance': 50000,
          'equity-buying-power': 80000,
          'day-trading-buying-power': 160000,
          'margin-equity': 95000,
          'maintenance-requirement': 5000,
          'maintenance-excess': 90000,
          'cash-available-to-withdraw': 45000,
          'long-equity-value': 45000,
          'short-equity-value': 0,
          'long-derivative-value': 5000,
          'short-derivative-value': 0,
          'long-futures-value': 0,
          'short-futures-value': 0,
          'derivative-buying-power': 60000,
          'reg-t-margin-requirement': 4000,
          'day-trade-excess': 155000,
          'long-cryptocurrency-value': 0,
          'long-bond-value': 0,
          'pending-cash': 0,
          'updated-at': '2023-12-01T12:00:00Z',
        },
      },
      positions: {
        data: {
          items: [
            {
              symbol: 'AAPL',
              'instrument-type': 'Equity',
              quantity: 100,
              'average-open-price': 150.00,
              'close-price': 155.00,
              'created-at': '2023-11-01T00:00:00Z',
              multiplier: 1,
            },
            {
              symbol: 'TSLA',
              'instrument-type': 'Equity',
              quantity: -50,
              'average-open-price': 250.00,
              'close-price': 245.00,
              'created-at': '2023-11-15T00:00:00Z',
              multiplier: 1,
            },
            {
              symbol: 'SPY_123120C450',
              'instrument-type': 'Option',
              quantity: 10,
              'average-open-price': 5.50,
              'close-price': 6.25,
              'created-at': '2023-11-20T00:00:00Z',
              multiplier: 100,
            },
          ],
        },
      },
    },
  ],
};

describe('Account Components', () => {
  beforeEach(() => {
    mockAccountApi.getAccountSummary.mockResolvedValue(mockAccountData);
    mockNavigate.mockClear();
  });

  describe('AccountBalances Component', () => {
    test('renders account balances with correct data', async () => {
      render(
        <TestWrapper>
          <AccountBalances />
        </TestWrapper>
      );

      // Check loading state initially
      expect(screen.getByText('Loading account balances...')).toBeInTheDocument();

      // Wait for data to load
      await waitFor(() => {
        expect(screen.getByText('Account Balances')).toBeInTheDocument();
      });

      // Check account number display
      expect(screen.getByText('#5WZ51117')).toBeInTheDocument();

      // Check portfolio value display
      expect(screen.getByText('Total Portfolio Value')).toBeInTheDocument();
      expect(screen.getByText('$100,000.00')).toBeInTheDocument();

      // Check trading power cards
      expect(screen.getByText('Cash Available')).toBeInTheDocument();
      expect(screen.getByText('Equity Buying Power')).toBeInTheDocument();
      expect(screen.getByText('Day Trading Power')).toBeInTheDocument();
    });

    test('navigation buttons work correctly', async () => {
      render(
        <TestWrapper>
          <AccountBalances />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('Account Balances')).toBeInTheDocument();
      });

      // Test Account Details button
      const accountDetailsBtn = screen.getByText('← Account Details');
      fireEvent.click(accountDetailsBtn);
      expect(mockNavigate).toHaveBeenCalledWith('/accounts/5WZ51117');

      // Test View Positions button
      const viewPositionsBtn = screen.getByText('📊 View Positions');
      fireEvent.click(viewPositionsBtn);
      expect(mockNavigate).toHaveBeenCalledWith('/accounts/5WZ51117/positions');

      // Test All Accounts button
      const allAccountsBtn = screen.getByText('🏦 All Accounts');
      fireEvent.click(allAccountsBtn);
      expect(mockNavigate).toHaveBeenCalledWith('/accounts');
    });

    test('filter functionality works', async () => {
      render(
        <TestWrapper>
          <AccountBalances />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('Account Balances')).toBeInTheDocument();
      });

      // Test filter buttons
      const cashEquityFilter = screen.getByText('Cash & Equity');
      fireEvent.click(cashEquityFilter);

      const derivativesFilter = screen.getByText('Derivatives');
      fireEvent.click(derivativesFilter);

      const requirementsFilter = screen.getByText('Requirements');
      fireEvent.click(requirementsFilter);

      const allCategoriesFilter = screen.getByText('All Categories');
      fireEvent.click(allCategoriesFilter);

      // Verify the active filter changes are applied
      expect(cashEquityFilter).toBeInTheDocument();
      expect(derivativesFilter).toBeInTheDocument();
      expect(requirementsFilter).toBeInTheDocument();
      expect(allCategoriesFilter).toBeInTheDocument();
    });

    test('handles error state correctly', async () => {
      mockAccountApi.getAccountSummary.mockRejectedValue(new Error('API Error'));

      render(
        <TestWrapper>
          <AccountBalances />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText(/Error: Error fetching account balances/)).toBeInTheDocument();
      });
    });
  });

  describe('AccountPositions Component', () => {
    test('renders positions with P&L calculations', async () => {
      render(
        <TestWrapper>
          <AccountPositions />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('Portfolio Positions')).toBeInTheDocument();
      });

      // Check position symbols
      expect(screen.getByText('AAPL')).toBeInTheDocument();
      expect(screen.getByText('TSLA')).toBeInTheDocument();
      expect(screen.getByText('SPY_123120C450')).toBeInTheDocument();

      // Check position directions
      expect(screen.getAllByText('LONG')).toHaveLength(2); // AAPL and SPY option
      expect(screen.getByText('SHORT')).toBeInTheDocument(); // TSLA

      // Verify P&L calculations
      // AAPL: (155 - 150) * 100 = +$500
      expect(screen.getByText('+$500.00')).toBeInTheDocument();
      // TSLA: (245 - 250) * -50 = +$250 (short position, price went down)
      expect(screen.getByText('+$250.00')).toBeInTheDocument();
    });

    test('displays performance dashboard correctly', async () => {
      render(
        <TestWrapper>
          <AccountPositions />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('Portfolio Positions')).toBeInTheDocument();
      });

      // Check performance cards
      expect(screen.getByText('Total Market Value')).toBeInTheDocument();
      expect(screen.getByText('Total P&L')).toBeInTheDocument();
      expect(screen.getByText('Position Types')).toBeInTheDocument();

      // Check position type breakdown
      expect(screen.getByText('Equity')).toBeInTheDocument();
      expect(screen.getByText('Options')).toBeInTheDocument();
    });

    test('shows empty state when no positions', async () => {
      const emptyData = {
        ...mockAccountData,
        accounts: [
          {
            ...mockAccountData.accounts[0],
            positions: { data: { items: [] } },
          },
        ],
      };
      mockAccountApi.getAccountSummary.mockResolvedValue(emptyData);

      render(
        <TestWrapper>
          <AccountPositions />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('No Positions Found')).toBeInTheDocument();
      });

      expect(screen.getByText("This account doesn't currently have any active positions.")).toBeInTheDocument();
    });
  });

  describe('AccountDetail Component', () => {
    test('renders account details correctly', async () => {
      render(
        <TestWrapper>
          <AccountDetail />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('Test Account')).toBeInTheDocument();
      });

      // Check account information
      expect(screen.getByText('Individual')).toBeInTheDocument();
      expect(screen.getByText('Active')).toBeInTheDocument();
      expect(screen.getByText('5WZ51117')).toBeInTheDocument();

      // Check trading permissions
      expect(screen.getByText('Day Trading')).toBeInTheDocument();
      expect(screen.getByText('Futures Trading')).toBeInTheDocument();
      expect(screen.getByText('Options Level')).toBeInTheDocument();
      expect(screen.getByText('Margin Trading')).toBeInTheDocument();

      // Check quick actions
      expect(screen.getByText('Account Balances')).toBeInTheDocument();
      expect(screen.getByText('Portfolio Positions')).toBeInTheDocument();
    });

    test('handles account not found', async () => {
      const notFoundData = {
        success: true,
        accounts: [],
      };
      mockAccountApi.getAccountSummary.mockResolvedValue(notFoundData);

      render(
        <TestWrapper>
          <AccountDetail />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('Account Not Found')).toBeInTheDocument();
      });
    });
  });

  describe('Tooltip Functionality', () => {
    test('tooltips appear on hover and auto-position correctly', async () => {
      render(
        <TestWrapper>
          <AccountBalances />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('Account Balances')).toBeInTheDocument();
      });

      // Find help icons and test hover
      const helpIcons = screen.getAllByText('?');
      expect(helpIcons.length).toBeGreaterThan(0);

      // Test hover on first help icon
      fireEvent.mouseEnter(helpIcons[0]);
      
      // Note: Testing actual tooltip content would require more complex setup
      // due to the async nature of the auto-positioning logic
    });
  });

  describe('Responsive Design', () => {
    test('components render correctly on mobile viewport', async () => {
      // Simulate mobile viewport
      Object.defineProperty(window, 'innerWidth', {
        writable: true,
        configurable: true,
        value: 375,
      });

      render(
        <TestWrapper>
          <AccountBalances />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('Account Balances')).toBeInTheDocument();
      });

      // Components should still render all content
      expect(screen.getByText('Total Portfolio Value')).toBeInTheDocument();
      expect(screen.getByText('Cash Available')).toBeInTheDocument();
    });
  });

  describe('Currency Formatting', () => {
    test('formats currency values correctly', async () => {
      render(
        <TestWrapper>
          <AccountBalances />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('$100,000.00')).toBeInTheDocument();
      });

      // Check various currency formats
      expect(screen.getByText('$50,000.00')).toBeInTheDocument(); // Cash balance
      expect(screen.getByText('$80,000.00')).toBeInTheDocument(); // Equity buying power
    });
  });

  describe('Performance Calculations', () => {
    test('calculates P&L correctly for different position types', async () => {
      render(
        <TestWrapper>
          <AccountPositions />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('Portfolio Positions')).toBeInTheDocument();
      });

      // AAPL long position: (155 - 150) * 100 = +$500
      expect(screen.getByText('+$500.00')).toBeInTheDocument();
      
      // TSLA short position: (245 - 250) * -50 = +$250
      expect(screen.getByText('+$250.00')).toBeInTheDocument();
      
      // SPY option: (6.25 - 5.50) * 10 * 100 = +$750
      expect(screen.getByText('+$750.00')).toBeInTheDocument();
    });
  });

  describe('API Integration', () => {
    test('makes correct API calls', async () => {
      render(
        <TestWrapper>
          <AccountBalances />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(mockAccountApi.getAccountSummary).toHaveBeenCalled();
      });

      expect(mockAccountApi.getAccountSummary).toHaveBeenCalledTimes(1);
    });

    test('handles API failures gracefully', async () => {
      mockAccountApi.getAccountSummary.mockRejectedValue(new Error('Network error'));

      render(
        <TestWrapper>
          <AccountBalances />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText(/Error:/)).toBeInTheDocument();
      });
    });
  });
});