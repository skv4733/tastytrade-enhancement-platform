import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { accountApi } from '../services/api';
import { ApiResponse, AccountPositionsResponse, Position } from '../types/api';
import Tooltip from './Tooltip';
import { getDefinition } from '../utils/financialDefinitions';

type SortKey = 'symbol' | 'type' | 'quantity' | 'avgCost' | 'currentPrice' | 'marketValue' | 'pnl' | 'pnlPercent' | 'daysToExpiry';
type SortDirection = 'asc' | 'desc';

const AccountPositions: React.FC = () => {
  const { accountNumber } = useParams<{ accountNumber: string }>();
  const navigate = useNavigate();
  const [positions, setPositions] = useState<Position[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');
  const [sortKey, setSortKey] = useState<SortKey>('symbol');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  const getPositionPnL = (position: Position) => {
    // Use net liquidating value if available, otherwise calculate from close price
    if (position['net-liquidating-value']) {
      const costBasis = position['average-open-price'] * Math.abs(position.quantity);
      return position['net-liquidating-value'] - costBasis;
    }
    return (position['close-price'] - position['average-open-price']) * position.quantity;
  };
  
  const getPositionPnLPercent = (position: Position) => {
    if (position['average-open-price'] === 0) return 0;
    return ((position['close-price'] - position['average-open-price']) / position['average-open-price']) * 100;
  };

  const getCurrentValue = (position: Position) => {
    // Use market value if available, otherwise calculate
    if (position['market-value']) return position['market-value'];
    if (position['net-liquidating-value']) return position['net-liquidating-value'];
    return position['close-price'] * position.quantity;
  };

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  const getSortValue = (position: Position, key: SortKey): number | string => {
    switch (key) {
      case 'symbol': return position.symbol || '';
      case 'type': return position['instrument-type'] || '';
      case 'quantity': return Math.abs(position.quantity);
      case 'avgCost': return position['average-open-price'];
      case 'currentPrice': return position.mark || position['close-price'];
      case 'marketValue': return getCurrentValue(position);
      case 'pnl': return getPositionPnL(position);
      case 'pnlPercent': return getPositionPnLPercent(position);
      case 'daysToExpiry': return position['days-to-expiration'] ?? 999999;
      default: return '';
    }
  };

  const sortedPositions = useMemo(() => {
    return [...positions].sort((a, b) => {
      const aValue = getSortValue(a, sortKey);
      const bValue = getSortValue(b, sortKey);
      
      let comparison = 0;
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        comparison = aValue.localeCompare(bValue);
      } else {
        comparison = (aValue as number) - (bValue as number);
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [positions, sortKey, sortDirection]);

  useEffect(() => {
    if (!accountNumber) {
      setError('No account number provided');
      setLoading(false);
      return;
    }

    const fetchPositions = async () => {
      try {
        setLoading(true);
        // Use the summary endpoint since individual endpoints work better
        const response = await accountApi.getAccountSummary();
        
        if (response.success && response.accounts) {
          // Find the account with matching account number
          const accountDetail = response.accounts.find((acc: any) => 
            acc.info && acc.info['account-number'] === accountNumber
          );
          
          if (accountDetail && accountDetail.positions && accountDetail.positions.data) {
            setPositions(accountDetail.positions.data.items || []);
          } else {
            setError(`Positions for account ${accountNumber} not found`);
          }
        } else {
          setError('Failed to fetch account positions');
        }
      } catch (err) {
        setError('Error fetching account positions: ' + (err as Error).message);
      } finally {
        setLoading(false);
      }
    };

    fetchPositions();
  }, [accountNumber]);

  if (loading) return <div className="loading">Loading account positions...</div>;
  if (error) return <div className="error">Error: {error}</div>;

  const formatCurrency = (amount: number | string) => {
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(num || 0);
  };

  const formatQuantity = (quantity: number | string) => {
    const num = typeof quantity === 'string' ? parseFloat(quantity) : quantity;
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }).format(num || 0);
  };

  const getPositionTypeIcon = (instrumentType: string) => {
    switch (instrumentType?.toLowerCase()) {
      case 'equity': return '📈';
      case 'option': return '⚡';
      case 'future': return '📊';
      case 'cryptocurrency': return '₿';
      case 'bond': return '🏛️';
      default: return '💼';
    }
  };

  const getPositionTypeColor = (instrumentType: string) => {
    switch (instrumentType?.toLowerCase()) {
      case 'equity': return 'equity';
      case 'option': return 'option';
      case 'future': return 'future';
      case 'cryptocurrency': return 'crypto';
      case 'bond': return 'bond';
      default: return 'default';
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: '2-digit'
      });
    } catch {
      return 'Invalid Date';
    }
  };

  const formatDaysToExpiration = (days?: number) => {
    if (days === undefined || days === null) return null;
    if (days === 0) return 'Today';
    if (days === 1) return '1 day';
    return `${days} days`;
  };

  const getOptionTypeDisplay = (optionType?: string) => {
    if (!optionType) return '';
    return optionType === 'C' ? 'Call' : optionType === 'P' ? 'Put' : optionType;
  };
  
  const getTotalPnL = () => {
    return positions.reduce((sum, pos) => sum + getPositionPnL(pos), 0);
  };
  
  const getTotalPnLPercent = () => {
    const totalCost = positions.reduce((sum, pos) => sum + (pos['average-open-price'] * Math.abs(pos.quantity)), 0);
    return totalCost > 0 ? (getTotalPnL() / totalCost) * 100 : 0;
  };

  const getTotalMarketValue = () => {
    return positions.reduce((sum, pos) => sum + getCurrentValue(pos), 0);
  };
  
  const getPositionsByType = () => {
    const types = positions.reduce((acc, pos) => {
      const type = pos['instrument-type']?.toLowerCase() || 'other';
      acc[type] = (acc[type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    return {
      equity: types.equity || 0,
      option: types.option || 0,
      future: types.future || 0,
      crypto: types.cryptocurrency || 0,
      other: Object.keys(types).reduce((sum, key) => {
        if (!['equity', 'option', 'future', 'cryptocurrency'].includes(key)) {
          return sum + types[key];
        }
        return sum;
      }, 0)
    };
  };

  return (
    <div className="positions-dashboard">
      {/* Elegant Hero Header */}
      <div className="positions-hero-header">
        <div className="hero-background-pattern"></div>
        <div className="hero-content-wrapper">
          <div className="positions-title-section">
            <div className="title-icon-large">📊</div>
            <div className="title-content">
              <h1>Portfolio Positions</h1>
              <div className="account-info">
                <span className="account-badge">#{accountNumber}</span>
                <span className="live-indicator">
                  <span className="pulse-dot"></span>
                  Real-time Data
                </span>
              </div>
            </div>
          </div>
          <div className="header-actions">
            <div className="view-toggle-wrapper">
              <button 
                onClick={() => setViewMode('table')} 
                className={`view-toggle-btn ${viewMode === 'table' ? 'active' : ''}`}
              >
                📊 Table
              </button>
              <button 
                onClick={() => setViewMode('cards')} 
                className={`view-toggle-btn ${viewMode === 'cards' ? 'active' : ''}`}
              >
                🃏 Cards
              </button>
            </div>
            <button onClick={() => navigate(`/accounts/${accountNumber}`)} className="dashboard-btn secondary">
              ← Account Details
            </button>
            <button onClick={() => navigate(`/accounts/${accountNumber}/balances`)} className="dashboard-btn primary">
              💰 View Balances
            </button>
            <button onClick={() => navigate('/accounts')} className="dashboard-btn tertiary">
              🏦 All Accounts
            </button>
          </div>
        </div>
      </div>
      
      {positions.length > 0 ? (
        <>
          {/* Portfolio Performance Dashboard */}
          <div className="portfolio-performance-dashboard">
            <div className="performance-hero">
              <div className="performance-card primary">
                <div className="performance-icon">💎</div>
                <div className="performance-content">
                  <h3>Total Market Value</h3>
                  <div className="performance-amount">
                    {formatCurrency(getTotalMarketValue())}
                  </div>
                  <div className="performance-subtitle">{positions.length} active positions</div>
                </div>
              </div>
              
              <div className="performance-card secondary">
                <div className="performance-icon">📈</div>
                <div className="performance-content">
                  <h3>Total P&L</h3>
                  <div className={`performance-amount ${getTotalPnL() >= 0 ? 'positive' : 'negative'}`}>
                    {formatCurrency(getTotalPnL())}
                  </div>
                  <div className="performance-subtitle">
                    {getTotalPnLPercent() >= 0 ? '+' : ''}{getTotalPnLPercent().toFixed(2)}% overall
                  </div>
                </div>
              </div>
              
              <div className="performance-card tertiary">
                <div className="performance-icon">⚖️</div>
                <div className="performance-content">
                  <h3>Position Types</h3>
                  <div className="performance-breakdown">
                    <div className="breakdown-item">
                      <span className="type-count">{getPositionsByType().equity}</span>
                      <span className="type-label">Equity</span>
                    </div>
                    <div className="breakdown-item">
                      <span className="type-count">{getPositionsByType().option}</span>
                      <span className="type-label">Options</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Positions Display */}
          {viewMode === 'table' ? (
            <div className="positions-table-container">
              <div className="positions-table-wrapper">
                <table className="positions-table">
                  <thead>
                    <tr>
                      <th className="sortable" onClick={() => handleSort('symbol')}>
                        <div className="th-content">
                          <span>Symbol</span>
                          {sortKey === 'symbol' && <span className="sort-indicator">{sortDirection === 'asc' ? '↑' : '↓'}</span>}
                        </div>
                      </th>
                      <th className="sortable" onClick={() => handleSort('type')}>
                        <div className="th-content">
                          <span>Type</span>
                          {sortKey === 'type' && <span className="sort-indicator">{sortDirection === 'asc' ? '↑' : '↓'}</span>}
                        </div>
                      </th>
                      <th className="sortable" onClick={() => handleSort('quantity')}>
                        <div className="th-content">
                          <span>Position</span>
                          {sortKey === 'quantity' && <span className="sort-indicator">{sortDirection === 'asc' ? '↑' : '↓'}</span>}
                        </div>
                      </th>
                      <th className="sortable" onClick={() => handleSort('avgCost')}>
                        <div className="th-content">
                          <span>Avg Cost</span>
                          {sortKey === 'avgCost' && <span className="sort-indicator">{sortDirection === 'asc' ? '↑' : '↓'}</span>}
                        </div>
                      </th>
                      <th className="sortable" onClick={() => handleSort('currentPrice')}>
                        <div className="th-content">
                          <span>Current Price</span>
                          {sortKey === 'currentPrice' && <span className="sort-indicator">{sortDirection === 'asc' ? '↑' : '↓'}</span>}
                        </div>
                      </th>
                      <th className="sortable" onClick={() => handleSort('marketValue')}>
                        <div className="th-content">
                          <span>Market Value</span>
                          {sortKey === 'marketValue' && <span className="sort-indicator">{sortDirection === 'asc' ? '↑' : '↓'}</span>}
                        </div>
                      </th>
                      <th className="sortable" onClick={() => handleSort('pnl')}>
                        <div className="th-content">
                          <span>P&L</span>
                          {sortKey === 'pnl' && <span className="sort-indicator">{sortDirection === 'asc' ? '↑' : '↓'}</span>}
                        </div>
                      </th>
                      <th className="sortable" onClick={() => handleSort('pnlPercent')}>
                        <div className="th-content">
                          <span>P&L %</span>
                          {sortKey === 'pnlPercent' && <span className="sort-indicator">{sortDirection === 'asc' ? '↑' : '↓'}</span>}
                        </div>
                      </th>
                      <th>Options Data</th>
                      <th>Additional Info</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortedPositions.map((position, index) => {
                      const pnl = getPositionPnL(position);
                      const pnlPercent = getPositionPnLPercent(position);
                      const isLong = position.quantity >= 0;
                      const isOption = position['instrument-type']?.toLowerCase() === 'option';
                      
                      return (
                        <tr key={index} className={`position-row ${getPositionTypeColor(position['instrument-type'])}`}>
                          <td className="symbol-cell">
                            <div className="symbol-wrapper">
                              <span className="position-type-icon">{getPositionTypeIcon(position['instrument-type'])}</span>
                              <div className="symbol-info">
                                <div className="symbol-name">{position.symbol}</div>
                                <div className="instrument-type">{position['instrument-type']}</div>
                              </div>
                            </div>
                          </td>
                          <td className="type-cell">
                            <span className={`position-badge ${position['instrument-type']?.toLowerCase()}`}>
                              {position['instrument-type']}
                            </span>
                          </td>
                          <td className="quantity-cell">
                            <div className="position-quantity">
                              <span className={`direction-badge ${isLong ? 'long' : 'short'}`}>
                                {isLong ? 'LONG' : 'SHORT'}
                              </span>
                              <span className="quantity-value">{formatQuantity(Math.abs(position.quantity))}</span>
                            </div>
                          </td>
                          <td className="price-cell">
                            {formatCurrency(position['average-open-price'])}
                          </td>
                          <td className="price-cell">
                            <div className="current-price">
                              <span className="price-value">{formatCurrency(position.mark || position['close-price'])}</span>
                              {position.mark && <span className="price-type">Mark</span>}
                            </div>
                          </td>
                          <td className="value-cell">
                            <span className="market-value">{formatCurrency(getCurrentValue(position))}</span>
                          </td>
                          <td className="pnl-cell">
                            <span className={`pnl-value ${pnl >= 0 ? 'positive' : 'negative'}`}>
                              {pnl >= 0 ? '+' : ''}{formatCurrency(pnl)}
                            </span>
                          </td>
                          <td className="pnl-percent-cell">
                            <span className={`pnl-percent ${pnlPercent >= 0 ? 'positive' : 'negative'}`}>
                              {pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(2)}%
                            </span>
                          </td>
                          <td className="options-data-cell">
                            {isOption ? (
                              <div className="options-info">
                                {position.instrument?.['option-type'] && (
                                  <div className="option-item">
                                    <span className="option-label">Type:</span>
                                    <span className="option-value">{getOptionTypeDisplay(position.instrument['option-type'])}</span>
                                  </div>
                                )}
                                {position.instrument?.['strike-price'] && (
                                  <div className="option-item">
                                    <span className="option-label">Strike:</span>
                                    <span className="option-value">{formatCurrency(position.instrument['strike-price'])}</span>
                                  </div>
                                )}
                                {position['days-to-expiration'] !== undefined && (
                                  <div className="option-item">
                                    <span className="option-label">DTE:</span>
                                    <span className={`option-value ${position['days-to-expiration'] <= 7 ? 'expiring-soon' : ''}`}>
                                      {formatDaysToExpiration(position['days-to-expiration'])}
                                    </span>
                                  </div>
                                )}
                                {position['expires-at'] && (
                                  <div className="option-item">
                                    <span className="option-label">Expires:</span>
                                    <span className="option-value">{formatDate(position['expires-at'])}</span>
                                  </div>
                                )}
                              </div>
                            ) : (
                              <span className="no-options-data">—</span>
                            )}
                          </td>
                          <td className="additional-info-cell">
                            <div className="additional-info">
                              {position['realized-today'] !== 0 && (
                                <div className="info-item">
                                  <span className="info-label">Realized Today:</span>
                                  <span className={`info-value ${position['realized-today'] >= 0 ? 'positive' : 'negative'}`}>
                                    {formatCurrency(position['realized-today'])}
                                  </span>
                                </div>
                              )}
                              {position['buying-power-effect'] && (
                                <div className="info-item">
                                  <span className="info-label">BP Effect:</span>
                                  <span className="info-value">{formatCurrency(position['buying-power-effect'])}</span>
                                </div>
                              )}
                              {position['created-at'] && (
                                <div className="info-item">
                                  <span className="info-label">Opened:</span>
                                  <span className="info-value">{formatDate(position['created-at'])}</span>
                                </div>
                              )}
                              {position['multiplier'] && (
                                <div className="info-item">
                                  <span className="info-label">Multiplier:</span>
                                  <span className="info-value">{position['multiplier']}x</span>
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="actions-cell">
                            <div className="table-actions">
                              <button className="table-action-btn primary" title="View Details">
                                📊
                              </button>
                              <button className="table-action-btn secondary" title="Trade">
                                ⚡
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            /* Card View - Existing Implementation */
            <div className="modern-positions-grid">
              {positions.map((position, index) => {
                const pnl = getPositionPnL(position);
                const pnlPercent = getPositionPnLPercent(position);
                
                return (
                  <div key={index} className={`modern-position-card ${getPositionTypeColor(position['instrument-type'])}`}>
                    <div className="position-card-header">
                      <div className="symbol-section">
                        <div className="position-icon-wrapper">
                          <span className="position-icon">{getPositionTypeIcon(position['instrument-type'])}</span>
                        </div>
                        <div className="symbol-details">
                          <h3 className="position-symbol">{position.symbol}</h3>
                          <span className="instrument-badge">{position['instrument-type']}</span>
                        </div>
                      </div>
                      <div className={`position-direction ${position.quantity >= 0 ? 'long' : 'short'}`}>
                        <span className="direction-label">{position.quantity >= 0 ? 'LONG' : 'SHORT'}</span>
                        <span className="quantity-badge">{formatQuantity(Math.abs(position.quantity))}</span>
                      </div>
                    </div>

                    <div className="position-performance">
                      <div className="current-value">
                        <span className="value-label">Market Value</span>
                        <span className="value-amount">{formatCurrency(getCurrentValue(position))}</span>
                      </div>
                      <div className={`pnl-section ${pnl >= 0 ? 'profit' : 'loss'}`}>
                        <div className="pnl-amount">
                          <span className="pnl-currency">{pnl >= 0 ? '+' : ''}{formatCurrency(pnl)}</span>
                          <span className="pnl-percent">({pnl >= 0 ? '+' : ''}{pnlPercent.toFixed(2)}%)</span>
                        </div>
                        <div className="pnl-indicator">
                          <div className={`pnl-arrow ${pnl >= 0 ? 'up' : 'down'}`}>
                            {pnl >= 0 ? '↗' : '↘'}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="position-details-grid">
                      <div className="detail-item">
                        <span className="detail-label">
                          Avg. Cost
                          <Tooltip content={getDefinition('average-open-price')} position="auto">
                            <span className="help-icon">?</span>
                          </Tooltip>
                        </span>
                        <span className="detail-value">{formatCurrency(position['average-open-price'])}</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">
                          {position.mark ? 'Mark Price' : 'Last Price'}
                          <Tooltip content={position.mark ? 'Current mark price used for position valuation' : getDefinition('close-price')} position="auto">
                            <span className="help-icon">?</span>
                          </Tooltip>
                        </span>
                        <span className="detail-value">{formatCurrency(position.mark || position['close-price'])}</span>
                      </div>
                      {position['multiplier'] && (
                        <div className="detail-item">
                          <span className="detail-label">Multiplier</span>
                          <span className="detail-value">{position['multiplier']}x</span>
                        </div>
                      )}
                      {position['created-at'] && (
                        <div className="detail-item">
                          <span className="detail-label">Opened</span>
                          <span className="detail-value">{formatDate(position['created-at'])}</span>
                        </div>
                      )}
                      
                      {/* Option-specific fields */}
                      {position.instrument?.['option-type'] && (
                        <div className="detail-item">
                          <span className="detail-label">Option Type</span>
                          <span className="detail-value">
                            {getOptionTypeDisplay(position.instrument['option-type'])}
                          </span>
                        </div>
                      )}
                      {position.instrument?.['strike-price'] && (
                        <div className="detail-item">
                          <span className="detail-label">Strike Price</span>
                          <span className="detail-value">{formatCurrency(position.instrument['strike-price'])}</span>
                        </div>
                      )}
                      {position['expires-at'] && (
                        <div className="detail-item">
                          <span className="detail-label">Expiration</span>
                          <span className="detail-value">{formatDate(position['expires-at'])}</span>
                        </div>
                      )}
                      {position['days-to-expiration'] !== undefined && (
                        <div className="detail-item">
                          <span className="detail-label">
                            DTE
                            <Tooltip content="Days to expiration for option contracts" position="auto">
                              <span className="help-icon">?</span>
                            </Tooltip>
                          </span>
                          <span className={`detail-value ${position['days-to-expiration'] <= 7 ? 'expiring-soon' : ''}`}>
                            {formatDaysToExpiration(position['days-to-expiration'])}
                          </span>
                        </div>
                      )}
                      
                      {/* Additional position details */}
                      {position['realized-today'] !== 0 && (
                        <div className="detail-item">
                          <span className="detail-label">
                            Realized Today
                            <Tooltip content="Profit/Loss realized from trades today" position="auto">
                              <span className="help-icon">?</span>
                            </Tooltip>
                          </span>
                          <span className={`detail-value ${position['realized-today'] >= 0 ? 'positive' : 'negative'}`}>
                            {formatCurrency(position['realized-today'])}
                          </span>
                        </div>
                      )}
                      {position['buying-power-effect'] && (
                        <div className="detail-item">
                          <span className="detail-label">
                            BP Effect
                            <Tooltip content="Effect on buying power from this position" position="auto">
                              <span className="help-icon">?</span>
                            </Tooltip>
                          </span>
                          <span className="detail-value">{formatCurrency(position['buying-power-effect'])}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="position-actions-modern">
                      <button className="action-btn-modern primary">
                        <span className="btn-icon">📊</span>
                        Details
                      </button>
                      <button className="action-btn-modern secondary">
                        <span className="btn-icon">⚡</span>
                        Trade
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      ) : (
        <div className="empty-positions-state">
          <div className="empty-positions-bg"></div>
          <div className="empty-content">
            <div className="empty-icon">📊</div>
            <h2>No Positions Found</h2>
            <p>This account doesn't currently have any active positions.</p>
            <p>Start trading to see your portfolio positions here.</p>
            <div className="empty-actions">
              <button onClick={() => navigate(`/accounts/${accountNumber}/balances`)} className="empty-btn primary">
                💰 View Account Balances
              </button>
              <button onClick={() => navigate('/accounts')} className="empty-btn secondary">
                ← Back to Accounts
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountPositions;