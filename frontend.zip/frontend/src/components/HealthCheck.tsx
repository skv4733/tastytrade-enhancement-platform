import React, { useState, useEffect } from 'react';
import { accountApi } from '../services/api';

interface HealthStatus {
  status: string;
  service: string;
  timestamp: number;
}

const HealthCheck: React.FC = () => {
  const [healthData, setHealthData] = useState<HealthStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const checkHealth = async () => {
      try {
        setLoading(true);
        const data = await accountApi.getHealthCheck();
        setHealthData(data);
        setError(null);
      } catch (err) {
        setError('Failed to check service health');
        console.error('Error checking health:', err);
      } finally {
        setLoading(false);
      }
    };

    checkHealth();
    
    // Check health every 30 seconds
    const interval = setInterval(checkHealth, 30000);
    return () => clearInterval(interval);
  }, []);

  const formatDateTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  if (loading) {
    return (
      <div className="health-check loading">
        <span className="status-indicator checking">🔄</span>
        <span>Checking service health...</span>
      </div>
    );
  }

  if (error || !healthData) {
    return (
      <div className="health-check error">
        <span className="status-indicator error">❌</span>
        <span>{error || 'Health check failed'}</span>
      </div>
    );
  }

  const isHealthy = healthData.status === 'healthy';

  return (
    <div className={`health-check ${isHealthy ? 'healthy' : 'unhealthy'}`}>
      <span className={`status-indicator ${isHealthy ? 'healthy' : 'unhealthy'}`}>
        {isHealthy ? '✅' : '⚠️'}
      </span>
      <div className="health-info">
        <span className="service-name">{healthData.service}</span>
        <span className="status-text">{healthData.status}</span>
        <span className="timestamp">{formatDateTime(healthData.timestamp)}</span>
      </div>
    </div>
  );
};

export default HealthCheck;