import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { accountApi } from '../services/api';
import Tooltip from './Tooltip';
import { getDefinition } from '../utils/financialDefinitions';

interface AccountSummaryData {
  customer?: any;
  accounts?: any[];
  accountCount?: number;
  success: boolean;
  timestamp: number;
  errors?: string[];
  partialData?: boolean;
}

const AccountSummary: React.FC = () => {
  const [summaryData, setSummaryData] = useState<AccountSummaryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const navigate = useNavigate();

  const fetchAccountSummary = async (showRefreshing = false) => {
    try {
      if (showRefreshing) setRefreshing(true);
      else setLoading(true);
      
      const data = await accountApi.getAccountSummary();
      setSummaryData(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch account summary');
      console.error('Error fetching account summary:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchAccountSummary();
  }, []);

  // Auto-refresh every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      if (!loading) {
        fetchAccountSummary(true);
      }
    }, 300000); // 5 minutes

    return () => clearInterval(interval);
  }, [loading]);

  const formatCurrency = (amount: number | string) => {
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(num || 0);
  };

  const formatDateTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const calculateTotalPortfolioValue = () => {
    if (!summaryData?.accounts) return 0;
    return summaryData.accounts.reduce((total, accountDetail) => {
      const balances = accountDetail.balances?.data;
      return total + (balances?.['net-liquidating-value'] || 0);
    }, 0);
  };

  const calculateTotalPositions = () => {
    if (!summaryData?.accounts) return 0;
    return summaryData.accounts.reduce((total, accountDetail) => {
      const positions = accountDetail.positions?.data?.items;
      return total + (positions?.length || 0);
    }, 0);
  };

  const getMarketStatus = () => {
    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay(); // 0 = Sunday, 6 = Saturday
    
    // Simple market hours check (9:30 AM - 4:00 PM ET on weekdays)
    if (day === 0 || day === 6) return { status: 'Closed', color: 'closed', icon: '🏁' };
    if (hour >= 9 && hour < 16) return { status: 'Open', color: 'open', icon: '🟢' };
    if (hour >= 4 && hour < 9) return { status: 'Pre-Market', color: 'premarket', icon: '🟡' };
    return { status: 'After Hours', color: 'afterhours', icon: '🟠' };
  };

  if (loading) {
    return (
      <div className="portfolio-dashboard">
        <div className="dashboard-loading">
          <div className="loading-icon">📊</div>
          <h2>Loading Portfolio Dashboard</h2>
          <p>Gathering your account data...</p>
          <div className="loading-spinner"></div>
        </div>
      </div>
    );
  }

  if (error || !summaryData) {
    return (
      <div className="portfolio-dashboard">
        <div className="dashboard-error">
          <div className="error-icon">⚠️</div>
          <h2>Portfolio Dashboard</h2>
          <p className="error-message">{error || 'No data available'}</p>
          <button onClick={() => fetchAccountSummary()} className="retry-btn">
            🔄 Retry Loading
          </button>
        </div>
      </div>
    );
  }

  const marketStatus = getMarketStatus();
  const totalValue = calculateTotalPortfolioValue();
  const totalPositions = calculateTotalPositions();

  return (
    <div className="portfolio-dashboard">
      {/* Hero Section */}
      <div className="dashboard-hero">
        <div className="hero-content">
          <div className="welcome-section">
            <h1>Welcome back, {summaryData.customer?.data?.['first-name'] || 'Trader'}!</h1>
            <p>Your complete portfolio overview and market insights</p>
          </div>
          
          <div className="market-status-card">
            <div className="market-info">
              <span className="market-icon">{marketStatus.icon}</span>
              <div className="market-details">
                <span className="market-label">Market Status</span>
                <span className={`market-status ${marketStatus.color}`}>{marketStatus.status}</span>
              </div>
            </div>
            <div className="last-updated">
              <span className="update-icon">🕐</span>
              <span className="update-text">
                {refreshing ? 'Updating...' : `Updated ${formatDateTime(summaryData.timestamp)}`}
              </span>
            </div>
          </div>
        </div>

        <div className="hero-actions">
          <button onClick={() => navigate('/accounts')} className="hero-btn primary">
            📊 View All Accounts
          </button>
          <button onClick={() => fetchAccountSummary(true)} className="hero-btn secondary">
            {refreshing ? '⏳' : '🔄'} Refresh Data
          </button>
          <button onClick={() => navigate('/glossary')} className="hero-btn tertiary">
            📖 Help Center
          </button>
        </div>
      </div>

      {/* Portfolio Overview Cards */}
      <div className="portfolio-overview">
        <div className="overview-card total-value">
          <div className="card-icon">💎</div>
          <div className="card-content">
            <h3>
              Total Portfolio Value
              <Tooltip content={getDefinition('net-liquidating-value')} position="top">
                <span className="help-icon">?</span>
              </Tooltip>
            </h3>
            <div className="card-value">{formatCurrency(totalValue)}</div>
            <div className="card-subtitle">{summaryData.accountCount || 0} accounts</div>
          </div>
        </div>

        <div className="overview-card total-positions">
          <div className="card-icon">📈</div>
          <div className="card-content">
            <h3>Active Positions</h3>
            <div className="card-value">{totalPositions}</div>
            <div className="card-subtitle">Across all accounts</div>
          </div>
        </div>

        <div className="overview-card account-types">
          <div className="card-icon">🏦</div>
          <div className="card-content">
            <h3>Account Types</h3>
            <div className="account-type-stats">
              <div className="type-stat">
                <span className="type-count">
                  {summaryData.accounts?.filter(acc => acc.info?.['margin-or-cash']?.toLowerCase() === 'margin').length || 0}
                </span>
                <span className="type-label">Margin</span>
              </div>
              <div className="type-stat">
                <span className="type-count">
                  {summaryData.accounts?.filter(acc => acc.info?.['margin-or-cash']?.toLowerCase() === 'cash').length || 0}
                </span>
                <span className="type-label">Cash</span>
              </div>
            </div>
          </div>
        </div>

        <div className="overview-card data-status">
          <div className="card-icon">{summaryData.success ? '✅' : '⚠️'}</div>
          <div className="card-content">
            <h3>Data Status</h3>
            <div className="card-value">{summaryData.success ? 'Complete' : 'Partial'}</div>
            <div className="card-subtitle">
              {summaryData.errors?.length ? `${summaryData.errors.length} issues` : 'All systems normal'}
            </div>
          </div>
        </div>
      </div>

      {/* Error Summary */}
      {summaryData.errors && summaryData.errors.length > 0 && (
        <div className="alerts-section">
          <div className="alert-card warning">
            <div className="alert-icon">⚠️</div>
            <div className="alert-content">
              <h4>Data Collection Issues</h4>
              <ul>
                {summaryData.errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Customer Profile Section */}
      {summaryData.customer && (
        <div className="customer-profile-section">
          <div className="profile-card">
            <div className="profile-header">
              <div className="profile-avatar">👤</div>
              <div className="profile-info">
                <h3>{summaryData.customer.data?.['first-name']} {summaryData.customer.data?.['last-name']}</h3>
                <p>Active Trading Customer</p>
              </div>
              <button onClick={() => navigate('/customer')} className="profile-btn">
                View Profile
              </button>
            </div>
            
            <div className="profile-details">
              <div className="detail-item">
                <span className="detail-icon">📧</span>
                <span className="detail-text">{summaryData.customer.data?.email}</span>
              </div>
              <div className="detail-item">
                <span className="detail-icon">🆔</span>
                <span className="detail-text">ID: {summaryData.customer.data?.['external-id']}</span>
              </div>
              <div className="detail-item">
                <span className="detail-icon">📅</span>
                <span className="detail-text">
                  Member since {new Date(summaryData.customer.data?.['created-at']).getFullYear()}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Accounts Grid */}
      <div className="accounts-dashboard-section">
        <div className="section-header">
          <h2>Account Details</h2>
          <button onClick={() => navigate('/accounts')} className="section-btn">
            View All Accounts →
          </button>
        </div>
        
        {summaryData.accounts && summaryData.accounts.length > 0 ? (
          <div className="dashboard-accounts-grid">
            {summaryData.accounts.map((accountDetail: any, index: number) => {
              const account = accountDetail.info;
              const balances = accountDetail.balances?.data;
              const positions = accountDetail.positions?.data?.items || [];

              return (
                <div 
                  key={account['account-number'] || index} 
                  className="dashboard-account-card"
                  onClick={() => navigate(`/accounts/${account['account-number']}`)}
                >
                  <div className="account-card-header">
                    <div className="account-icon">
                      {account['margin-or-cash']?.toLowerCase() === 'margin' ? '📊' : '💰'}
                    </div>
                    <div className="account-title-section">
                      <h4>{account.nickname || `Account ${account['account-number']}`}</h4>
                      <span className="account-id">#{account['account-number']}</span>
                    </div>
                    <div className={`account-status-indicator ${account['is-closed'] ? 'closed' : 'active'}`}>
                      {account['is-closed'] ? 'Closed' : 'Active'}
                    </div>
                  </div>

                  <div className="account-metrics">
                    <div className="metric-card primary">
                      <div className="metric-label">
                        Net Value
                        <Tooltip content={getDefinition('net-liquidating-value')} position="top">
                          <span className="help-icon">?</span>
                        </Tooltip>
                      </div>
                      <div className="metric-value">
                        {formatCurrency(balances?.['net-liquidating-value'] || 0)}
                      </div>
                    </div>

                    <div className="metric-card secondary">
                      <div className="metric-label">Cash Balance</div>
                      <div className="metric-value">
                        {formatCurrency(balances?.['cash-balance'] || 0)}
                      </div>
                    </div>

                    <div className="metric-card tertiary">
                      <div className="metric-label">Positions</div>
                      <div className="metric-value">{positions.length}</div>
                    </div>
                  </div>

                  <div className="account-features">
                    <div className={`feature-tag ${account['day-trader-status'] ? 'enabled' : 'disabled'}`}>
                      🚀 Day Trader
                    </div>
                    <div className={`feature-tag ${account['is-futures-approved'] ? 'enabled' : 'disabled'}`}>
                      📈 Futures
                    </div>
                  </div>

                  <div className="account-actions">
                    <button 
                      onClick={(e) => { e.stopPropagation(); navigate(`/accounts/${account['account-number']}/balances`); }}
                      className="action-btn compact"
                    >
                      💰 Balances
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); navigate(`/accounts/${account['account-number']}/positions`); }}
                      className="action-btn compact"
                    >
                      📊 Positions
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-icon">🏦</div>
            <h3>No Accounts Available</h3>
            <p>Your account data couldn't be loaded at this time.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AccountSummary;