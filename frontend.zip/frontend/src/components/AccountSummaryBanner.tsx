import React, { useState, useEffect } from 'react';
import { accountApi } from '../services/api';
import { AccountBalances } from '../types/api';
import Tooltip from './Tooltip';
import { getDefinition } from '../utils/financialDefinitions';

interface AccountSummaryBannerProps {
  accountNumber: string;
}

const AccountSummaryBanner: React.FC<AccountSummaryBannerProps> = ({ accountNumber }) => {
  const [balances, setBalances] = useState<AccountBalances | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const fetchBalances = async () => {
      try {
        setLoading(true);
        // Use the summary endpoint since it works consistently
        const response = await accountApi.getAccountSummary();
        
        if (response.success && response.accounts) {
          const accountDetail = response.accounts.find((acc: any) => 
            acc.info && acc.info['account-number'] === accountNumber
          );
          
          if (accountDetail && accountDetail.balances && accountDetail.balances.data) {
            setBalances(accountDetail.balances.data);
          } else {
            setError(`Balances for account ${accountNumber} not found`);
          }
        } else {
          setError('Failed to fetch account balances');
        }
      } catch (err) {
        console.error('Error fetching banner balances:', err);
        setError('Error fetching balance summary');
      } finally {
        setLoading(false);
      }
    };

    fetchBalances();
  }, [accountNumber]);

  const formatCurrency = (amount: number | string) => {
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(num || 0);
  };

  const calculatePercentage = (value: number, total: number) => {
    if (total === 0) return 0;
    return ((value / total) * 100);
  };

  const getLeverageInfo = (buyingPower: number, equity: number) => {
    if (equity === 0) return '1x';
    const leverage = buyingPower / equity;
    return `${leverage.toFixed(1)}x`;
  };

  if (loading) {
    return (
      <div className="account-summary-banner loading">
        <div className="banner-loading">
          <div className="loading-spinner"></div>
          <span>Loading account summary...</span>
        </div>
      </div>
    );
  }

  if (error || !balances) {
    return (
      <div className="account-summary-banner error">
        <div className="banner-error">
          <span className="error-icon">⚠️</span>
          <span>Unable to load account summary</span>
        </div>
      </div>
    );
  }

  const cashAvailable = balances['cash-available-to-withdraw'] || 0;
  const equityBuyingPower = balances['equity-buying-power'] || 0;
  const dayTradingPower = balances['day-trading-buying-power'] || 0;
  const marginEquity = balances['margin-equity'] || 0;
  const netLiquidatingValue = balances['net-liquidating-value'] || 0;

  return (
    <div className="account-summary-banner">
      <div className="banner-container">
        <div className="banner-item">
          <div className="banner-icon">💵</div>
          <div className="banner-content">
            <div className="banner-header">
              <span className="banner-title">Cash Available</span>
              <Tooltip content={getDefinition('cash-available-to-withdraw')} position="auto">
                <span className="banner-help">?</span>
              </Tooltip>
            </div>
            <div className="banner-subtitle">Ready to withdraw</div>
            <div className="banner-value">{formatCurrency(cashAvailable)}</div>
            <div className="banner-extra">
              {calculatePercentage(cashAvailable, netLiquidatingValue).toFixed(1)}% of portfolio
            </div>
          </div>
        </div>

        <div className="banner-item">
          <div className="banner-icon">⚡</div>
          <div className="banner-content">
            <div className="banner-header">
              <span className="banner-title">Equity Buying Power</span>
              <Tooltip content={getDefinition('equity-buying-power')} position="auto">
                <span className="banner-help">?</span>
              </Tooltip>
            </div>
            <div className="banner-subtitle">Stock purchases</div>
            <div className="banner-value">{formatCurrency(equityBuyingPower)}</div>
            <div className="banner-extra">
              {getLeverageInfo(equityBuyingPower, marginEquity)} Leverage
            </div>
          </div>
        </div>

        <div className="banner-item">
          <div className="banner-icon">🚀</div>
          <div className="banner-content">
            <div className="banner-header">
              <span className="banner-title">Day Trading Power</span>
              <Tooltip content={getDefinition('day-trading-buying-power')} position="auto">
                <span className="banner-help">?</span>
              </Tooltip>
            </div>
            <div className="banner-subtitle">Intraday trades</div>
            <div className="banner-value">{formatCurrency(dayTradingPower)}</div>
            <div className="banner-extra">
              {getLeverageInfo(dayTradingPower, marginEquity)} Leverage
            </div>
          </div>
        </div>

        <div className="banner-item">
          <div className="banner-icon">📊</div>
          <div className="banner-content">
            <div className="banner-header">
              <span className="banner-title">Margin Equity</span>
              <Tooltip content={getDefinition('margin-equity')} position="auto">
                <span className="banner-help">?</span>
              </Tooltip>
            </div>
            <div className="banner-subtitle">Total equity value</div>
            <div className="banner-value">{formatCurrency(marginEquity)}</div>
            <div className="banner-extra">
              {marginEquity >= 2000 ? 'Healthy' : 'Low Balance'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSummaryBanner;