import React, { useState, useEffect, useMemo } from 'react';
import { instrumentsApi, NestedOptionChain, NestedExpiration, NestedStrike, InstrumentData, FuturesOptionChainData, FuturesOptionExpiration } from '../services/instrumentsApi';
import './OptionChainViewer.css';

interface OptionChainViewerProps {
  underlyingSymbol: string;
  onOptionSelect?: (optionSymbol: string, optionType: 'call' | 'put', strikePrice: string, expirationDate: string) => void;
}

interface OptionRowData {
  strike: string;
  callSymbol?: string;
  callBid?: number;
  callAsk?: number;
  callVolume?: number;
  callIV?: number;
  putSymbol?: string;
  putBid?: number;
  putAsk?: number;
  putVolume?: number;
  putIV?: number;
}

const OptionChainViewer: React.FC<OptionChainViewerProps> = ({ 
  underlyingSymbol, 
  onOptionSelect 
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [optionChain, setOptionChain] = useState<NestedOptionChain | FuturesOptionChainData | null>(null);
  const [selectedExpiration, setSelectedExpiration] = useState<string>('');
  const [strategy, setStrategy] = useState<'STOCK' | 'OPTION'>('STOCK');
  const [direction, setDirection] = useState<'LONG' | 'SHORT'>('LONG');
  const [strikes, setStrikes] = useState<'ALL' | 'ITM' | 'OTM' | 'ATM'>('ALL');

  useEffect(() => {
    if (underlyingSymbol) {
      fetchOptionChain();
    }
  }, [underlyingSymbol]);

  const fetchOptionChain = async () => {
    setLoading(true);
    setError('');

    try {
      // Case-insensitive symbol handling
      const normalizedSymbol = underlyingSymbol.trim();
      console.log('🔗 Fetching option chain for:', normalizedSymbol);
      
      // Determine if this is a futures symbol (starts with /)
      const isFuturesSymbol = normalizedSymbol.startsWith('/');
      console.log('📊 Symbol type detected:', isFuturesSymbol ? 'Futures' : 'Equity');
      
      let response;
      if (isFuturesSymbol) {
        // For futures symbols, remove the leading / and use just the symbol part
        const futuresSymbol = normalizedSymbol.substring(1).toUpperCase(); // Remove / and uppercase
        console.log('📈 Using futures symbol (without /):', futuresSymbol);
        response = await instrumentsApi.getFuturesNestedOptionChain(futuresSymbol);
      } else {
        // Regular equity options (case-insensitive)
        const equitySymbol = normalizedSymbol.toUpperCase();
        console.log('📈 Using equity symbol:', equitySymbol);
        response = await instrumentsApi.getNestedOptionChain(equitySymbol);
      }
      
      if (response.success && response.data) {
        if (isFuturesSymbol) {
          // Handle futures option chain response
          // Structure: ApiResponse<InstrumentResponse<FuturesOptionChainData>>
          // So response.data.data contains the FuturesOptionChainData
          const futuresResponse = response as { success: boolean; data: { data: FuturesOptionChainData } };
          const futuresData = futuresResponse.data.data;
          console.log('✅ Futures option chain data received:', futuresData);
          setOptionChain(futuresData);
          
          // Auto-select first expiration from first option chain
          if (futuresData['option-chains'] && futuresData['option-chains'].length > 0) {
            const firstChain = futuresData['option-chains'][0];
            if (firstChain.expirations && firstChain.expirations.length > 0) {
              setSelectedExpiration(firstChain.expirations[0]['expiration-date']);
            }
          }
        } else {
          // Handle equity option chain response
          // Structure: ApiResponse<InstrumentResponse<InstrumentData<NestedOptionChain>>>
          // So response.data.data.items[0] contains the NestedOptionChain
          const equityResponse = response as { success: boolean; data: { data: { items: NestedOptionChain[] } } };
          if (equityResponse.data?.data?.items && equityResponse.data.data.items.length > 0) {
            const optionChainData = equityResponse.data.data.items[0];
            console.log('✅ Equity option chain data received:', optionChainData);
            setOptionChain(optionChainData);
            
            // Auto-select first expiration
            const expirations = optionChainData.expirations || [];
            if (expirations.length > 0) {
              setSelectedExpiration(expirations[0]['expiration-date']);
            }
          } else {
            console.warn('⚠️ No equity option chain data in response:', response);
            setError('No option chain data available');
          }
        }
      } else {
        console.warn('⚠️ No option chain data in response:', response);
        setError('No option chain data available');
      }
    } catch (err) {
      console.error('💥 Error fetching option chain:', err);
      setError(`Failed to load option chain: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setLoading(false);
    }
  };

  // Process option chain data for display
  const optionRows = useMemo(() => {
    if (!optionChain || !selectedExpiration) {
      return [];
    }

    // Check if this is futures data or equity data
    const isFuturesData = 'option-chains' in optionChain;
    
    if (isFuturesData) {
      // Handle futures option chain data
      const futuresData = optionChain as FuturesOptionChainData;
      if (!futuresData['option-chains'] || futuresData['option-chains'].length === 0) {
        return [];
      }
      
      const firstChain = futuresData['option-chains'][0];
      const expiration = firstChain.expirations?.find(exp => exp['expiration-date'] === selectedExpiration);
      
      if (!expiration || !expiration.strikes) {
        return [];
      }

      return expiration.strikes
        .map(strike => {
          return {
            strike: strike['strike-price'],
            callSymbol: strike.call,
            callBid: Math.random() * 5, // Mock data - replace with real market data
            callAsk: Math.random() * 5 + 0.1,
            callVolume: Math.floor(Math.random() * 1000),
            callIV: Math.random() * 100,
            putSymbol: strike.put,
            putBid: Math.random() * 5,
            putAsk: Math.random() * 5 + 0.1,
            putVolume: Math.floor(Math.random() * 1000),
            putIV: Math.random() * 100,
          };
        })
        .sort((a, b) => parseFloat(a.strike) - parseFloat(b.strike));
    } else {
      // Handle equity option chain data
      const equityData = optionChain as NestedOptionChain;
      const expiration = equityData.expirations?.find(exp => exp['expiration-date'] === selectedExpiration);
      
      if (!expiration || !expiration.strikes) {
        return [];
      }

      return expiration.strikes
        .map(strike => {
          return {
            strike: strike['strike-price'],
            callSymbol: strike.call,
            callBid: Math.random() * 5, // Mock data - replace with real market data
            callAsk: Math.random() * 5 + 0.1,
            callVolume: Math.floor(Math.random() * 1000),
            callIV: Math.random() * 100,
            putSymbol: strike.put,
            putBid: Math.random() * 5,
            putAsk: Math.random() * 5 + 0.1,
            putVolume: Math.floor(Math.random() * 1000),
            putIV: Math.random() * 100,
          };
        })
        .sort((a, b) => parseFloat(a.strike) - parseFloat(b.strike));
    }
  }, [optionChain, selectedExpiration]);

  const expirationOptions = useMemo(() => {
    if (!optionChain) return [];
    
    // Check if this is futures data or equity data
    const isFuturesData = 'option-chains' in optionChain;
    
    if (isFuturesData) {
      // Handle futures option chain data
      const futuresData = optionChain as FuturesOptionChainData;
      if (!futuresData['option-chains'] || futuresData['option-chains'].length === 0) {
        return [];
      }
      
      const firstChain = futuresData['option-chains'][0];
      if (!firstChain.expirations) return [];
      
      return firstChain.expirations.map(exp => ({
        date: exp['expiration-date'],
        daysToExpiration: exp['days-to-expiration'],
        expType: exp['expiration-type']
      }));
    } else {
      // Handle equity option chain data
      const equityData = optionChain as NestedOptionChain;
      if (!equityData.expirations) return [];
      
      return equityData.expirations.map(exp => ({
        date: exp['expiration-date'],
        daysToExpiration: exp['days-to-expiration'],
        expType: exp['expiration-type']
      }));
    }
  }, [optionChain]);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const handleOptionClick = (optionSymbol: string | undefined, optionType: 'call' | 'put', strikePrice: string) => {
    if (optionSymbol && onOptionSelect) {
      onOptionSelect(optionSymbol, optionType, strikePrice, selectedExpiration);
    }
  };

  if (loading) {
    return (
      <div className="option-chain-loading">
        <div className="loading-spinner">⏳</div>
        <div>Loading option chain for {underlyingSymbol}...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="option-chain-error">
        <div className="error-icon">❌</div>
        <div className="error-message">{error}</div>
        <button onClick={fetchOptionChain} className="retry-button">
          🔄 Retry
        </button>
      </div>
    );
  }

  return (
    <div className="tastytrade-option-chain">
      {/* Header Section */}
      <div className="option-chain-header">
        <div className="symbol-info">
          <h2 className="underlying-symbol">{underlyingSymbol}</h2>
          <div className="underlying-price">
            637.15 / 1.00K {/* Mock price - replace with real data */}
          </div>
        </div>
        
        <div className="header-controls">
          <div className="iv-rank">
            <span className="label">IV Rank:</span>
            <span className="value">11.9</span>
          </div>
          <div className="last-size">
            <span className="label">Last / Size:</span>
            <span className="value">637.15 / 1.00K</span>
          </div>
          <div className="change">
            <span className="label">Chg:</span>
            <span className="value positive">4.90</span>
          </div>
          <div className="change-percent">
            <span className="label">Chg%:</span>
            <span className="value positive">0.78%</span>
          </div>
        </div>
      </div>

      {/* Strategy Controls */}
      <div className="strategy-controls">
        <div className="trade-mode">
          <span className="label">TRADE MODE</span>
        </div>
        
        <div className="strategy-section">
          <span className="label">STRATEGY</span>
          <div className="strategy-buttons">
            <button 
              className={`strategy-btn ${strategy === 'STOCK' ? 'active' : ''}`}
              onClick={() => setStrategy('STOCK')}
            >
              STOCK
            </button>
            <button 
              className={`strategy-btn ${strategy === 'OPTION' ? 'active' : ''}`}
              onClick={() => setStrategy('OPTION')}
            >
              OPTION
            </button>
          </div>
        </div>

        <div className="direction-section">
          <button 
            className={`direction-btn ${direction === 'LONG' ? 'active' : ''}`}
            onClick={() => setDirection('LONG')}
          >
            LONG
          </button>
          <button 
            className={`direction-btn ${direction === 'SHORT' ? 'active' : ''}`}
            onClick={() => setDirection('SHORT')}
          >
            SHORT
          </button>
        </div>

        <div className="go-button">
          <button className="go-btn">GO</button>
        </div>

        <div className="strikes-filter">
          <span className="label">STRIKES</span>
          <select 
            value={strikes} 
            onChange={(e) => setStrikes(e.target.value as any)}
            className="strikes-select"
          >
            <option value="ALL">ALL</option>
            <option value="ITM">ITM</option>
            <option value="OTM">OTM</option>
            <option value="ATM">ATM</option>
          </select>
        </div>
      </div>

      {/* Expiration Selector */}
      <div className="expiration-selector">
        {expirationOptions.map(exp => (
          <button
            key={exp.date}
            className={`expiration-btn ${selectedExpiration === exp.date ? 'active' : ''}`}
            onClick={() => setSelectedExpiration(exp.date)}
          >
            <div className="exp-date">{formatDate(exp.date)}</div>
            <div className="exp-days">{exp.daysToExpiration}d</div>
          </button>
        ))}
      </div>

      {/* Option Chain Table */}
      {optionRows.length > 0 ? (
        <div className="option-chain-table-container">
          <table className="option-chain-table">
            <thead>
              <tr>
                <th colSpan={4} className="calls-header">Calls</th>
                <th className="strike-header">Strike</th>
                <th colSpan={4} className="puts-header">Puts</th>
              </tr>
              <tr className="sub-header">
                <th className="volume-header">Vol</th>
                <th className="iv-header">IV %</th>
                <th className="bid-header">Bid (Sell)</th>
                <th className="ask-header">Ask (Buy)</th>
                <th className="strike-price-header">Strike</th>
                <th className="bid-header">Bid (Sell)</th>
                <th className="ask-header">Ask (Buy)</th>
                <th className="iv-header">IV %</th>
                <th className="volume-header">Vol</th>
              </tr>
            </thead>
            <tbody>
              {optionRows.map((row, index) => (
                <tr key={row.strike} className="option-row">
                  {/* Call Side */}
                  <td className="volume-cell">{row.callVolume}</td>
                  <td className="iv-cell">{row.callIV?.toFixed(0)}%</td>
                  <td 
                    className="bid-cell call-bid clickable"
                    onClick={() => handleOptionClick(row.callSymbol, 'call', row.strike)}
                  >
                    {row.callBid?.toFixed(2)}
                  </td>
                  <td 
                    className="ask-cell call-ask clickable"
                    onClick={() => handleOptionClick(row.callSymbol, 'call', row.strike)}
                  >
                    {row.callAsk?.toFixed(2)}
                  </td>
                  
                  {/* Strike Price */}
                  <td className="strike-cell">{row.strike}</td>
                  
                  {/* Put Side */}
                  <td 
                    className="bid-cell put-bid clickable"
                    onClick={() => handleOptionClick(row.putSymbol, 'put', row.strike)}
                  >
                    {row.putBid?.toFixed(2)}
                  </td>
                  <td 
                    className="ask-cell put-ask clickable"
                    onClick={() => handleOptionClick(row.putSymbol, 'put', row.strike)}
                  >
                    {row.putAsk?.toFixed(2)}
                  </td>
                  <td className="iv-cell">{row.putIV?.toFixed(0)}%</td>
                  <td className="volume-cell">{row.putVolume}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="no-options">
          <div className="empty-icon">📊</div>
          <div>No options available for the selected expiration</div>
        </div>
      )}
    </div>
  );
};

export default OptionChainViewer;