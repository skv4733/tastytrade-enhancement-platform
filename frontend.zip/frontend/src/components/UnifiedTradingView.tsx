import React, { useState, useEffect, useMemo } from 'react';
import { instrumentsApi, SymbolData, Equity, Future } from '../services/instrumentsApi';
import OptionChainViewer from './OptionChainViewer';
import './OptionChainViewer.css';
import './UnifiedTradingView.css';

interface UnifiedTradingViewProps {
  defaultSymbol?: string;
}

interface InstrumentDetails {
  symbol: string;
  type: string;
  description: string;
  data: Equity | Future | any;
}

const UnifiedTradingView: React.FC<UnifiedTradingViewProps> = ({ defaultSymbol = 'SPY' }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedInstrument, setSelectedInstrument] = useState<string>(defaultSymbol);
  const [instrumentDetails, setInstrumentDetails] = useState<InstrumentDetails | null>(null);
  const [searchResults, setSearchResults] = useState<SymbolData[]>([]);
  const [loading, setLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [loadingDetails, setLoadingDetails] = useState(false);

  // Fetch instrument details when selected instrument changes
  useEffect(() => {
    if (selectedInstrument) {
      fetchInstrumentDetails(selectedInstrument);
    }
  }, [selectedInstrument]);

  // Debounced search for symbols
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchTerm.trim().length > 0) {
        performSearch();
      } else {
        setSearchResults([]);
        setShowDropdown(false);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchTerm]);

  const performSearch = async () => {
    if (!searchTerm.trim()) return;

    setLoading(true);
    try {
      const response = await instrumentsApi.searchSymbols(searchTerm);
      if (response.success && response.data?.data?.items) {
        setSearchResults(response.data.data.items);
        setShowDropdown(true);
      } else {
        setSearchResults([]);
        setShowDropdown(false);
      }
    } catch (error) {
      console.error('Search failed:', error);
      setSearchResults([]);
      setShowDropdown(false);
    } finally {
      setLoading(false);
    }
  };

  const fetchInstrumentDetails = async (symbol: string) => {
    setLoadingDetails(true);
    try {
      // First, search to get the instrument type
      const searchResponse = await instrumentsApi.searchSymbols(symbol);
      
      if (searchResponse.success && searchResponse.data?.data?.items && searchResponse.data.data.items.length > 0) {
        const firstResult = searchResponse.data.data.items[0];
        const instrumentType = firstResult['instrument-type'];
        
        let detailsResponse;
        let instrumentData;

        // Fetch detailed information based on instrument type
        switch (instrumentType?.toLowerCase()) {
          case 'equity':
            detailsResponse = await instrumentsApi.getEquity(symbol);
            instrumentData = (detailsResponse.success && detailsResponse.data) ? detailsResponse.data.data : null;
            break;
          case 'future':
            // If this looks like a futures root symbol (starts with /), get current contracts
            if (symbol.startsWith('/') && symbol.length > 1) {
              try {
                const rootSymbol = symbol.substring(1); // Remove the /
                console.log('📈 Getting current futures contracts for root:', rootSymbol);
                const futuresResponse = await instrumentsApi.getCurrentFuturesContracts(rootSymbol);
                if (futuresResponse.success && futuresResponse.data?.data?.items && futuresResponse.data.data.items.length > 0) {
                  // Use the first active contract
                  instrumentData = futuresResponse.data.data.items[0];
                  console.log('Using current futures contract:', instrumentData.symbol);
                } else {
                  instrumentData = firstResult;
                }
              } catch (error) {
                console.error('Failed to get current futures contracts:', error);
                instrumentData = firstResult;
              }
            } else {
              // Try to get the specific futures contract
              detailsResponse = await instrumentsApi.getFuture(symbol);
              instrumentData = (detailsResponse.success && detailsResponse.data) ? detailsResponse.data.data : null;
            }
            break;
          default:
            // Use search result as fallback
            instrumentData = firstResult;
        }

        if (instrumentData) {
          setInstrumentDetails({
            symbol: symbol,
            type: instrumentType || 'Unknown',
            description: firstResult.description || firstResult['short-description'] || 'N/A',
            data: instrumentData
          });
        }
      }
    } catch (error) {
      console.error('Failed to fetch instrument details:', error);
    } finally {
      setLoadingDetails(false);
    }
  };

  const handleInstrumentSelect = (symbol: string) => {
    setSelectedInstrument(symbol.toUpperCase());
    setSearchTerm('');
    setShowDropdown(false);
  };

  const getInstrumentTypeColor = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'equity': return '#4CAF50';
      case 'future': return '#FF9800';
      case 'option': return '#2196F3';
      case 'cryptocurrency': return '#9C27B0';
      default: return '#757575';
    }
  };

  const formatCurrency = (amount: string | number | undefined): string => {
    if (!amount) return 'N/A';
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(num);
  };

  const formatNumber = (num: string | number | undefined): string => {
    if (!num) return 'N/A';
    const value = typeof num === 'string' ? parseFloat(num) : num;
    return new Intl.NumberFormat('en-US').format(value);
  };

  const renderInstrumentMetadata = () => {
    if (!instrumentDetails || loadingDetails) {
      return (
        <div className="instrument-metadata loading">
          {loadingDetails ? 'Loading instrument details...' : 'Select an instrument to view details'}
        </div>
      );
    }

    const { type, description, data } = instrumentDetails;

    return (
      <div className="instrument-metadata">
        <div className="metadata-header">
          <div className="instrument-title">
            <h3>{selectedInstrument}</h3>
            <span 
              className="instrument-type-badge"
              style={{ backgroundColor: getInstrumentTypeColor(type) }}
            >
              {type}
            </span>
          </div>
          <p className="instrument-description">{description}</p>
        </div>

        <div className="metadata-details">
          {type?.toLowerCase() === 'equity' && (
            <div className="equity-details">
              <div className="detail-row">
                <span className="label">Market Cap:</span>
                <span className="value">{formatCurrency(data['market-cap'])}</span>
              </div>
              <div className="detail-row">
                <span className="label">Shares Outstanding:</span>
                <span className="value">{formatNumber(data['shares-outstanding'])}</span>
              </div>
              <div className="detail-row">
                <span className="label">Is ETF:</span>
                <span className="value">{data['is-etf'] ? 'Yes' : 'No'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Is Index:</span>
                <span className="value">{data['is-index'] ? 'Yes' : 'No'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Lendability:</span>
                <span className="value">{data.lendability || 'N/A'}</span>
              </div>
            </div>
          )}

          {type?.toLowerCase() === 'future' && (
            <div className="future-details">
              <div className="detail-row">
                <span className="label">Product Code:</span>
                <span className="value">{data['product-code'] || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Contract Size:</span>
                <span className="value">{data['contract-size'] || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Tick Size:</span>
                <span className="value">{data['tick-size'] || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Expiration Date:</span>
                <span className="value">{data['expiration-date'] || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Days to Expiration:</span>
                <span className="value">{data['days-to-expiration'] || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Exchange:</span>
                <span className="value">{data.exchange || 'N/A'}</span>
              </div>
            </div>
          )}

          <div className="trading-info">
            <div className="detail-row">
              <span className="label">Active:</span>
              <span className={`value ${data.active ? 'active' : 'inactive'}`}>
                {data.active ? 'Yes' : 'No'}
              </span>
            </div>
            <div className="detail-row">
              <span className="label">Closing Only:</span>
              <span className="value">{data['is-closing-only'] ? 'Yes' : 'No'}</span>
            </div>
            <div className="detail-row">
              <span className="label">Streamer Symbol:</span>
              <span className="value">{data['streamer-symbol'] || 'N/A'}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="unified-trading-view">
      {/* Search Header */}
      <div className="trading-header">
        <div className="search-section">
          <h2>🎯 Trading Dashboard</h2>
          <div className="search-container">
            <div className="search-input-wrapper">
              <input
                type="text"
                placeholder="Search instruments (e.g., AAPL, SPY, /ES)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="instrument-search-input"
                onFocus={() => searchTerm && setShowDropdown(true)}
              />
              {loading && <div className="search-loading">🔍</div>}
              
              {showDropdown && searchResults.length > 0 && (
                <div className="search-dropdown">
                  {searchResults.slice(0, 10).map((result, index) => (
                    <div
                      key={`${result.symbol}-${index}`}
                      className="search-result-item"
                      onClick={() => handleInstrumentSelect(result.symbol)}
                    >
                      <div className="result-main">
                        <span className="result-symbol">{result.symbol}</span>
                        <span 
                          className="result-type"
                          style={{ backgroundColor: getInstrumentTypeColor(result['instrument-type']) }}
                        >
                          {result['instrument-type']}
                        </span>
                      </div>
                      <div className="result-description">
                        {result.description || result['short-description'] || 'N/A'}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            <div className="current-symbol">
              <label>Selected:</label>
              <input
                type="text"
                value={selectedInstrument}
                onChange={(e) => setSelectedInstrument(e.target.value.toUpperCase())}
                className="symbol-input"
                placeholder="Enter symbol"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Instrument Details */}
      {renderInstrumentMetadata()}

      {/* Option Chain */}
      <div className="option-chain-section">
        <OptionChainViewer
          underlyingSymbol={selectedInstrument}
          onOptionSelect={(optionSymbol, optionType, strikePrice, expirationDate) => {
            console.log('Selected option:', { 
              optionSymbol, 
              optionType, 
              strikePrice, 
              expirationDate 
            });
            // Here you could integrate with trading functionality
          }}
        />
      </div>
    </div>
  );
};

export default UnifiedTradingView;