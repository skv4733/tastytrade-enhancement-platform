import React, { useState, useEffect, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import { accountApi } from '../services/api';
import { Position } from '../types/api';

type SortOption = 'symbol' | 'value' | 'pnl' | 'pnlPercent';
type SortDirection = 'asc' | 'desc';

const StreamlinedPositions: React.FC = () => {
  const { accountNumber } = useParams<{ accountNumber: string }>();
  const [positions, setPositions] = useState<Position[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');
  
  // Search and Filter State
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [sortBy, setSortBy] = useState<SortOption>('symbol');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [filterType, setFilterType] = useState<string>('all');

  useEffect(() => {
    const fetchPositions = async () => {
      if (!accountNumber) return;
      
      try {
        setLoading(true);
        const response = await accountApi.getAccountSummary();
        
        if (response.success && response.accounts) {
          const accountDetail = response.accounts.find((acc: any) => 
            acc.info && acc.info['account-number'] === accountNumber
          );
          
          if (accountDetail && accountDetail.positions && accountDetail.positions.data && accountDetail.positions.data.items) {
            setPositions(accountDetail.positions.data.items);
          }
        }
      } catch (err) {
        console.error('Error fetching positions:', err);
        setError('Failed to load positions');
      } finally {
        setLoading(false);
      }
    };

    fetchPositions();
  }, [accountNumber]);

  // Helper functions
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatQuantity = (quantity: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 6,
    }).format(Math.abs(quantity));
  };

  const getPositionPnL = (position: Position) => {
    const costBasis = position['average-open-price'] * Math.abs(position.quantity);
    const currentValue = position['net-liquidating-value'] || 
                        (position['market-value']) || 
                        (position['close-price'] * position.quantity);
    return currentValue - costBasis;
  };

  const getPositionPnLPercent = (position: Position) => {
    if (position['average-open-price'] === 0) return 0;
    return ((position['close-price'] - position['average-open-price']) / position['average-open-price']) * 100;
  };

  const getCurrentValue = (position: Position) => {
    return position['net-liquidating-value'] || 
           position['market-value'] || 
           (position['close-price'] * position.quantity);
  };

  // Filtered and sorted positions
  const filteredAndSortedPositions = useMemo(() => {
    let filtered = positions;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(position => 
        position.symbol?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        position['underlying-symbol']?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply instrument type filter
    if (filterType !== 'all') {
      filtered = filtered.filter(position => position['instrument-type'] === filterType);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let aValue, bValue;

      switch (sortBy) {
        case 'symbol':
          aValue = a.symbol || '';
          bValue = b.symbol || '';
          break;
        case 'value':
          aValue = getCurrentValue(a);
          bValue = getCurrentValue(b);
          break;
        case 'pnl':
          aValue = getPositionPnL(a);
          bValue = getPositionPnL(b);
          break;
        case 'pnlPercent':
          aValue = getPositionPnLPercent(a);
          bValue = getPositionPnLPercent(b);
          break;
        default:
          aValue = a.symbol || '';
          bValue = b.symbol || '';
      }

      if (typeof aValue === 'string' && typeof bValue === 'string') {
        const comparison = aValue.localeCompare(bValue);
        return sortDirection === 'asc' ? comparison : -comparison;
      } else {
        const comparison = (aValue as number) - (bValue as number);
        return sortDirection === 'asc' ? comparison : -comparison;
      }
    });

    return filtered;
  }, [positions, searchTerm, filterType, sortBy, sortDirection]);

  // Get unique instrument types for filter dropdown
  const instrumentTypes = useMemo(() => {
    const types = new Set(positions.map(p => p['instrument-type']).filter(Boolean));
    return Array.from(types);
  }, [positions]);

  // Portfolio analytics - moved before early returns to fix hooks rule
  const portfolioStats = useMemo(() => {
    if (!filteredAndSortedPositions.length) {
      return {
        totalValue: 0,
        totalPnL: 0,
        winnersCount: 0,
        losersCount: 0,
        winRate: 0,
        largestPosition: null
      };
    }

    const totalValue = filteredAndSortedPositions.reduce((sum, pos) => sum + getCurrentValue(pos), 0);
    const totalPnL = filteredAndSortedPositions.reduce((sum, pos) => sum + getPositionPnL(pos), 0);
    const winnersCount = filteredAndSortedPositions.filter(pos => getPositionPnL(pos) > 0).length;
    const losersCount = filteredAndSortedPositions.filter(pos => getPositionPnL(pos) < 0).length;
    const totalPositions = positions.length;
    const winRate = totalPositions > 0 ? (winnersCount / totalPositions) * 100 : 0;
    
    const largest = filteredAndSortedPositions.reduce((max, pos) => {
      const value = getCurrentValue(pos);
      return value > getCurrentValue(max) ? pos : max;
    }, filteredAndSortedPositions[0]);
    
    return {
      totalValue,
      totalPnL,
      winnersCount,
      losersCount,
      winRate,
      largestPosition: largest
    };
  }, [filteredAndSortedPositions, positions.length]);

  const totalPositions = positions.length;
  const equityCount = positions.filter(p => p['instrument-type'] === 'Equity').length;
  const optionCount = positions.filter(p => p['instrument-type'] === 'Option').length;

  if (loading) {
    return (
      <div className="streamlined-positions loading">
        <div className="positions-loading">
          <div className="loading-spinner"></div>
          <span>Loading positions...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="streamlined-positions error">
        <div className="positions-error">
          <span className="error-icon">⚠️</span>
          <span>{error}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="positions-page">
      {/* Enhanced Header with Quick Stats */}
      <div className="positions-header">
        <div className="header-main">
          <h2 className="page-title">Portfolio Positions</h2>
          {positions.length > 0 && (
            <div className="portfolio-overview">
              <div className="overview-stat">
                <span className="stat-label">Total Value</span>
                <span className="stat-value">{formatCurrency(portfolioStats.totalValue)}</span>
              </div>
              <div className="overview-stat">
                <span className="stat-label">Total P&L</span>
                <span className={`stat-value ${portfolioStats.totalPnL >= 0 ? 'positive' : 'negative'}`}>
                  {portfolioStats.totalPnL >= 0 ? '+' : ''}{formatCurrency(portfolioStats.totalPnL)}
                </span>
              </div>
              <div className="overview-stat">
                <span className="stat-label">Positions</span>
                <span className="stat-value">{totalPositions}</span>
              </div>
              <div className="overview-stat">
                <span className="stat-label">Win Rate</span>
                <span className="stat-value">{portfolioStats.winRate.toFixed(1)}%</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {positions.length > 0 ? (
        <>
          {/* Enhanced Controls */}
          <div className="positions-controls">
            <div className="controls-left">
              <div className="search-container">
                <input
                  type="text"
                  placeholder="🔍 Search symbols..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="search-field"
                />
              </div>
              
              {instrumentTypes.length > 1 && (
                <select 
                  value={filterType} 
                  onChange={(e) => setFilterType(e.target.value)}
                  className="filter-field"
                >
                  <option value="all">All Types ({totalPositions})</option>
                  {instrumentTypes.map(type => (
                    <option key={type} value={type}>
                      {type} ({positions.filter(p => p['instrument-type'] === type).length})
                    </option>
                  ))}
                </select>
              )}
            </div>
            
            <div className="controls-right">
              <select 
                value={`${sortBy}-${sortDirection}`} 
                onChange={(e) => {
                  const [field, direction] = e.target.value.split('-');
                  setSortBy(field as SortOption);
                  setSortDirection(direction as SortDirection);
                }}
                className="sort-field"
              >
                <option value="symbol-asc">📝 Symbol A-Z</option>
                <option value="value-desc">💰 Value High-Low</option>
                <option value="pnl-desc">📈 P&L High-Low</option>
                <option value="pnlPercent-desc">📊 P&L % High-Low</option>
              </select>
              
              <button className="export-btn">
                📤 Export
              </button>
            </div>
          </div>

          {/* Enhanced Positions Table */}
          <div className="positions-table-container">
            <div className="positions-table">
              <table>
                <thead>
                  <tr>
                    <th className="symbol-header">Symbol</th>
                    <th className="numeric-header">Quantity</th>
                    <th className="numeric-header">Avg Cost</th>
                    <th className="numeric-header">Current Price</th>
                    <th className="numeric-header">Market Value</th>
                    <th className="numeric-header">Unrealized P&L</th>
                    <th className="numeric-header">P&L %</th>
                    <th className="action-header">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAndSortedPositions.map((position, index) => {
                    const pnl = getPositionPnL(position);
                    const pnlPercent = getPositionPnLPercent(position);
                    const currentValue = getCurrentValue(position);
                    const isLong = position.quantity >= 0;
                    const absQuantity = Math.abs(position.quantity);

                    return (
                      <tr key={`${position.symbol}-${index}`} className={`position-row ${pnl >= 0 ? 'winning' : 'losing'}`}>
                        <td className="symbol-cell">
                          <div className="symbol-container">
                            <div className="symbol-main">
                              <span className="symbol-name">{position.symbol}</span>
                              {position['underlying-symbol'] && position['underlying-symbol'] !== position.symbol && (
                                <span className="underlying">({position['underlying-symbol']})</span>
                              )}
                            </div>
                            <div className="symbol-details">
                              <span className={`position-side ${isLong ? 'long' : 'short'}`}>
                                {isLong ? '📈 LONG' : '📉 SHORT'}
                              </span>
                              <span className="instrument-type">{position['instrument-type']}</span>
                            </div>
                          </div>
                        </td>
                        
                        <td className="quantity-cell">
                          <div className="quantity-container">
                            <span className="quantity-value">{formatQuantity(absQuantity)}</span>
                            <div className="quantity-bar">
                              <div 
                                className="quantity-fill"
                                style={{ 
                                  width: `${Math.min(100, (currentValue / portfolioStats.totalValue) * 100)}%`,
                                  backgroundColor: pnl >= 0 ? '#10b981' : '#ef4444'
                                }}
                              ></div>
                            </div>
                          </div>
                        </td>
                        
                        <td className="price-cell">{formatCurrency(position['average-open-price'])}</td>
                        
                        <td className="price-cell">
                          <span className="current-price">{formatCurrency(position['close-price'] || position.mark || 0)}</span>
                        </td>
                        
                        <td className="value-cell">
                          <span className="market-value">{formatCurrency(currentValue)}</span>
                          <span className="value-percentage">
                            {((currentValue / portfolioStats.totalValue) * 100).toFixed(1)}%
                          </span>
                        </td>
                        
                        <td className={`pnl-cell ${pnl >= 0 ? 'positive' : 'negative'}`}>
                          <div className="pnl-container">
                            <span className="pnl-amount">
                              {pnl >= 0 ? '+' : ''}{formatCurrency(pnl)}
                            </span>
                            <div className={`pnl-indicator ${pnl >= 0 ? 'positive' : 'negative'}`}>
                              {pnl >= 0 ? '▲' : '▼'}
                            </div>
                          </div>
                        </td>
                        
                        <td className={`percent-cell ${pnlPercent >= 0 ? 'positive' : 'negative'}`}>
                          <div className="percent-container">
                            <span className="percent-value">
                              {pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(2)}%
                            </span>
                            <div className="percent-bar">
                              <div 
                                className={`percent-fill ${pnlPercent >= 0 ? 'positive' : 'negative'}`}
                                style={{ 
                                  width: `${Math.min(100, Math.abs(pnlPercent) * 2)}%`
                                }}
                              ></div>
                            </div>
                          </div>
                        </td>

                        <td className="action-cell">
                          <div className="action-buttons">
                            <button className="action-btn trade" title="Trade">⚡</button>
                            <button className="action-btn analyze" title="Analyze">📊</button>
                            <button className="action-btn more" title="More">⋯</button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Summary Footer */}
          <div className="positions-summary">
            <div className="summary-stats">
              <div className="summary-stat">
                <span className="summary-label">Winners:</span>
                <span className="summary-value positive">{portfolioStats.winnersCount}</span>
              </div>
              <div className="summary-stat">
                <span className="summary-label">Losers:</span>
                <span className="summary-value negative">{portfolioStats.losersCount}</span>
              </div>
              <div className="summary-stat">
                <span className="summary-label">Showing:</span>
                <span className="summary-value">{filteredAndSortedPositions.length} of {totalPositions}</span>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="empty-state">
          <div className="empty-icon">📊</div>
          <h3>No Positions Found</h3>
          <p>You don't have any positions in this account yet.</p>
          <button className="start-trading-btn">Start Trading</button>
        </div>
      )}
    </div>
  );
};

export default StreamlinedPositions;