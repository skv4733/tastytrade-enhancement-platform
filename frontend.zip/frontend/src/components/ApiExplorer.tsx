import React, { useState } from 'react';
import { Tabs, Tab, Box, Typography, Paper } from '@mui/material';
import AccountsClientTab from './api-explorer/AccountsClientTab';
import AccountStatusClientTab from './api-explorer/AccountStatusClientTab';
import AccountBalanceAndPositionsClientTab from './api-explorer/AccountBalanceAndPositionsClientTab';
import InstrumentsClientTab from './api-explorer/InstrumentsClientTab';
import MarginRequirementsClientTab from './api-explorer/MarginRequirementsClientTab';
import MarketDataClientTab from './api-explorer/MarketDataClientTab';
import MarketMetricsClientTab from './api-explorer/MarketMetricsClientTab';
import MarketTimeClientTab from './api-explorer/MarketTimeClientTab';
import OrdersClientTab from './api-explorer/OrdersClientTab';
import RiskParametersClientTab from './api-explorer/RiskParametersClientTab';
import SearchSymbolsClientTab from './api-explorer/SearchSymbolsClientTab';
import TransactionsClientTab from './api-explorer/TransactionsClientTab';
import WatchlistsClientTab from './api-explorer/WatchlistsClientTab';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`api-tabpanel-${index}`}
      aria-labelledby={`api-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `api-tab-${index}`,
    'aria-controls': `api-tabpanel-${index}`,
  };
}

const ApiExplorer: React.FC = () => {
  const [value, setValue] = useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <Paper sx={{ p: 2, m: 2 }}>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
        🚀 Trading Data Explorer
      </Typography>
      <Typography variant="body1" gutterBottom sx={{ mb: 3, fontSize: '1.1rem' }}>
        Access real-time market data, account information, and trading tools
      </Typography>

      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label="API Explorer tabs"
          variant="scrollable"
          scrollButtons="auto"
        >
          <Tab label="👤 My Profile" {...a11yProps(0)} />
          <Tab label="✅ Account Status" {...a11yProps(1)} />
          <Tab label="💰 Balance & Positions" {...a11yProps(2)} />
          <Tab label="🔍 Instruments" {...a11yProps(3)} />
          <Tab label="📊 Margin Info" {...a11yProps(4)} />
          <Tab label="📈 Live Market Data" {...a11yProps(5)} />
          <Tab label="📉 Market Analytics" {...a11yProps(6)} />
          <Tab label="🕐 Market Hours" {...a11yProps(7)} />
          <Tab label="⚡ Orders" {...a11yProps(8)} />
          <Tab label="⚠️ Risk Management" {...a11yProps(9)} />
          <Tab label="🔎 Symbol Search" {...a11yProps(10)} />
          <Tab label="🧾 Transactions" {...a11yProps(11)} />
          <Tab label="⭐ Watchlists" {...a11yProps(12)} />
        </Tabs>
      </Box>

      <TabPanel value={value} index={0}>
        <AccountsClientTab />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <AccountStatusClientTab />
      </TabPanel>
      <TabPanel value={value} index={2}>
        <AccountBalanceAndPositionsClientTab />
      </TabPanel>
      <TabPanel value={value} index={3}>
        <InstrumentsClientTab />
      </TabPanel>
      <TabPanel value={value} index={4}>
        <MarginRequirementsClientTab />
      </TabPanel>
      <TabPanel value={value} index={5}>
        <MarketDataClientTab />
      </TabPanel>
      <TabPanel value={value} index={6}>
        <MarketMetricsClientTab />
      </TabPanel>
      <TabPanel value={value} index={7}>
        <MarketTimeClientTab />
      </TabPanel>
      <TabPanel value={value} index={8}>
        <OrdersClientTab />
      </TabPanel>
      <TabPanel value={value} index={9}>
        <RiskParametersClientTab />
      </TabPanel>
      <TabPanel value={value} index={10}>
        <SearchSymbolsClientTab />
      </TabPanel>
      <TabPanel value={value} index={11}>
        <TransactionsClientTab />
      </TabPanel>
      <TabPanel value={value} index={12}>
        <WatchlistsClientTab />
      </TabPanel>
    </Paper>
  );
};

export default ApiExplorer;