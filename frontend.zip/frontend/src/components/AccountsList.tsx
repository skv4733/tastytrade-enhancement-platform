import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { accountApi } from '../services/api';
import { ApiResponse, AccountsResponse, Account, AccountItem } from '../types/api';
import Tooltip from './Tooltip';
import { getDefinition } from '../utils/financialDefinitions';

const AccountsList: React.FC = () => {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'active' | 'margin' | 'cash'>('all');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        setLoading(true);
        const response: ApiResponse<AccountsResponse> = await accountApi.getCustomerAccounts();
        
        if (response.success && response.data) {
          // Extract accounts from AccountItems
          const accountItems = response.data.data.items || [];
          const extractedAccounts = accountItems.map(item => item.account).filter(account => account != null);
          setAccounts(extractedAccounts);
        } else {
          setError(response.message || 'Failed to fetch accounts');
        }
      } catch (err) {
        setError('Error fetching accounts: ' + (err as Error).message);
      } finally {
        setLoading(false);
      }
    };

    fetchAccounts();
  }, []);

  const handleAccountClick = (accountNumber: string) => {
    navigate(`/accounts/${accountNumber}`);
  };

  const getAccountTypeIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'cash': return '💰';
      case 'margin': return '📊';
      case 'pdt': return '🚀';
      default: return '🏦';
    }
  };

  const getAccountStatusColor = (isClosed: boolean) => {
    return isClosed ? 'closed' : 'active';
  };

  const getAccountStatus = (isClosed: boolean) => {
    return isClosed ? 'Closed' : 'Active';
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const filteredAccounts = accounts.filter(account => {
    switch (selectedFilter) {
      case 'active':
        return !account['is-closed'];
      case 'margin':
        return account['margin-or-cash']?.toLowerCase() === 'margin';
      case 'cash':
        return account['margin-or-cash']?.toLowerCase() === 'cash';
      default:
        return true;
    }
  });

  // Calculate statistics
  const stats = {
    total: accounts.length,
    active: accounts.filter(acc => !acc['is-closed']).length,
    margin: accounts.filter(acc => acc['margin-or-cash']?.toLowerCase() === 'margin').length,
    cash: accounts.filter(acc => acc['margin-or-cash']?.toLowerCase() === 'cash').length,
    dayTrader: accounts.filter(acc => acc['day-trader-status']).length,
    futuresApproved: accounts.filter(acc => acc['is-futures-approved']).length,
  };

  if (loading) return <div className="loading">Loading accounts...</div>;
  if (error) return <div className="error">Error: {error}</div>;

  return (
    <div className="accounts-overview">
      {/* Header Section */}
      <div className="accounts-header">
        <div className="header-content">
          <h1>Account Portfolio</h1>
          <p>Manage and monitor all your trading accounts in one place</p>
        </div>
        <div className="quick-actions">
          <button onClick={() => navigate('/summary')} className="action-btn primary">
            📊 Portfolio Summary
          </button>
          <button onClick={() => navigate('/glossary')} className="action-btn secondary">
            📖 Help Center
          </button>
        </div>
      </div>

      {/* Statistics Overview */}
      <div className="accounts-stats">
        <div className="stat-card primary">
          <div className="stat-icon">🏦</div>
          <div className="stat-content">
            <div className="stat-number">{stats.total}</div>
            <div className="stat-label">Total Accounts</div>
          </div>
        </div>
        <div className="stat-card active">
          <div className="stat-icon">✅</div>
          <div className="stat-content">
            <div className="stat-number">{stats.active}</div>
            <div className="stat-label">Active Accounts</div>
          </div>
        </div>
        <div className="stat-card margin">
          <div className="stat-icon">📊</div>
          <div className="stat-content">
            <div className="stat-number">{stats.margin}</div>
            <div className="stat-label">Margin Accounts</div>
          </div>
        </div>
        <div className="stat-card cash">
          <div className="stat-icon">💰</div>
          <div className="stat-content">
            <div className="stat-number">{stats.cash}</div>
            <div className="stat-label">Cash Accounts</div>
          </div>
        </div>
        <div className="stat-card trader">
          <div className="stat-icon">🚀</div>
          <div className="stat-content">
            <div className="stat-number">{stats.dayTrader}</div>
            <div className="stat-label">Day Traders</div>
          </div>
        </div>
        <div className="stat-card futures">
          <div className="stat-icon">📈</div>
          <div className="stat-content">
            <div className="stat-number">{stats.futuresApproved}</div>
            <div className="stat-label">Futures Approved</div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="accounts-filters">
        <button 
          className={`filter-tab ${selectedFilter === 'all' ? 'active' : ''}`}
          onClick={() => setSelectedFilter('all')}
        >
          All Accounts ({stats.total})
        </button>
        <button 
          className={`filter-tab ${selectedFilter === 'active' ? 'active' : ''}`}
          onClick={() => setSelectedFilter('active')}
        >
          Active ({stats.active})
        </button>
        <button 
          className={`filter-tab ${selectedFilter === 'margin' ? 'active' : ''}`}
          onClick={() => setSelectedFilter('margin')}
        >
          Margin ({stats.margin})
        </button>
        <button 
          className={`filter-tab ${selectedFilter === 'cash' ? 'active' : ''}`}
          onClick={() => setSelectedFilter('cash')}
        >
          Cash ({stats.cash})
        </button>
      </div>

      {/* Accounts Grid */}
      {filteredAccounts.length > 0 ? (
        <div className="enhanced-accounts-grid">
          {filteredAccounts.map((account, index) => (
            <div key={index} className="enhanced-account-card" onClick={() => handleAccountClick(account['account-number'])}>
              <div className="account-card-header">
                <div className="account-icon-section">
                  <span className="account-type-icon">{getAccountTypeIcon(account['account-type-name'])}</span>
                  <div className="account-title-info">
                    <h3 className="account-title">
                      {account.nickname || `Account ${account['account-number']}`}
                    </h3>
                    <span className="account-number">#{account['account-number']}</span>
                  </div>
                </div>
                <div className={`account-status-badge ${getAccountStatusColor(account['is-closed'])}`}>
                  {getAccountStatus(account['is-closed'])}
                </div>
              </div>

              <div className="account-card-body">
                <div className="account-details-grid">
                  <div className="detail-item">
                    <span className="detail-label">
                      Account Type
                      <Tooltip content="The type of trading account - Cash accounts use only settled funds, Margin accounts allow borrowing." position="top">
                        <span className="help-icon">?</span>
                      </Tooltip>
                    </span>
                    <span className="detail-value">{account['account-type-name']}</span>
                  </div>

                  <div className="detail-item">
                    <span className="detail-label">
                      Trading Type
                      <Tooltip content={getDefinition('margin-equity')} position="top">
                        <span className="help-icon">?</span>
                      </Tooltip>
                    </span>
                    <span className="detail-value">{account['margin-or-cash']}</span>
                  </div>

                  <div className="detail-item">
                    <span className="detail-label">Created</span>
                    <span className="detail-value">{formatDate(account['created-at'])}</span>
                  </div>

                  <div className="detail-item">
                    <span className="detail-label">Opened</span>
                    <span className="detail-value">{formatDate(account['opened-at'])}</span>
                  </div>
                </div>

                <div className="account-features">
                  <div className={`feature-badge ${account['day-trader-status'] ? 'enabled' : 'disabled'}`}>
                    <span className="feature-icon">🚀</span>
                    <span className="feature-text">Day Trader</span>
                  </div>
                  <div className={`feature-badge ${account['is-futures-approved'] ? 'enabled' : 'disabled'}`}>
                    <span className="feature-icon">📈</span>
                    <span className="feature-text">Futures</span>
                  </div>
                  <div className={`feature-badge ${account['suitable-options-level'] ? 'enabled' : 'disabled'}`}>
                    <span className="feature-icon">⚡</span>
                    <span className="feature-text">Options</span>
                  </div>
                </div>
              </div>

              <div className="account-card-footer">
                <div className="action-buttons-row">
                  <button 
                    onClick={(e) => { e.stopPropagation(); navigate(`/accounts/${account['account-number']}/balances`); }}
                    className="card-action-btn primary"
                  >
                    💰 Balances
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); navigate(`/accounts/${account['account-number']}/positions`); }}
                    className="card-action-btn secondary"
                  >
                    📊 Positions
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); navigate(`/accounts/${account['account-number']}`); }}
                    className="card-action-btn details"
                  >
                    🔍 Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="empty-icon">🏦</div>
          <h3>No Accounts Found</h3>
          <p>No accounts match the selected filter criteria.</p>
          <button onClick={() => setSelectedFilter('all')} className="reset-filter-btn">
            Show All Accounts
          </button>
        </div>
      )}
    </div>
  );
};

export default AccountsList;