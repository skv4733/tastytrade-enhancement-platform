import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import UnifiedDashboard from './components/UnifiedDashboard';
import ApiExplorer from './components/ApiExplorer';
import HealthCheck from './components/HealthCheck';
import './App.css';

const App: React.FC = () => {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <h1>Tastytrade Account Manager</h1>
          <HealthCheck />
        </header>
        
        <main className="App-main">
          <Routes>
            <Route path="/" element={<UnifiedDashboard />} />
            <Route path="/summary" element={<UnifiedDashboard />} />
            <Route path="/customer" element={<UnifiedDashboard />} />
            <Route path="/accounts" element={<UnifiedDashboard />} />
            <Route path="/accounts/:accountNumber" element={<UnifiedDashboard />} />
            <Route path="/accounts/:accountNumber/balances" element={<UnifiedDashboard />} />
            <Route path="/accounts/:accountNumber/positions" element={<UnifiedDashboard />} />
            <Route path="/accounts/:accountNumber/transactions" element={<UnifiedDashboard />} />
            <Route path="/trading" element={<UnifiedDashboard />} />
            <Route path="/instruments" element={<Navigate to="/trading" replace />} />
            <Route path="/options" element={<Navigate to="/trading" replace />} />
            <Route path="/api-explorer" element={<ApiExplorer />} />
            <Route path="/glossary" element={<UnifiedDashboard />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;