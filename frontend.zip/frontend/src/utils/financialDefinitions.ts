export interface FinancialTerm {
  term: string;
  definition: string;
  category: 'balance' | 'buying_power' | 'margin' | 'position' | 'general';
}

export const FINANCIAL_DEFINITIONS: Record<string, FinancialTerm> = {
  'annual-income': {
    term: 'Annual Income',
    definition: 'The total amount of money earned by an individual in a year from all sources including salary, wages, bonuses, and investment income.',
    category: 'general'
  },
  'net-worth': {
    term: 'Net Worth',
    definition: 'The total value of all assets (what you own) minus all liabilities (what you owe). This represents your overall financial position.',
    category: 'general'
  },
  'liquid-net-worth': {
    term: 'Liquid Net Worth',
    definition: 'The portion of net worth that can be quickly converted to cash without significant loss of value, such as cash, stocks, and bonds.',
    category: 'general'
  },
  'cash-available': {
    term: 'Cash Available',
    definition: 'The amount of cash in your account that is available for immediate withdrawal or trading. This is settled cash minus any pending transactions or holds.',
    category: 'balance'
  },
  'cash-balance': {
    term: 'Cash Balance',
    definition: 'The total amount of cash in your account, including both settled and unsettled funds. This includes deposits, dividends, and proceeds from sales.',
    category: 'balance'
  },
  'buying-power': {
    term: 'Buying Power',
    definition: 'The maximum dollar amount of securities you can purchase in your account. For margin accounts, this includes borrowed funds from your broker.',
    category: 'buying_power'
  },
  'equity-buying-power': {
    term: 'Equity Buying Power',
    definition: 'The maximum amount available to purchase equity securities (stocks). In margin accounts, this is typically 2x your available cash and marginable securities value.',
    category: 'buying_power'
  },
  'day-trading-buying-power': {
    term: 'Day Trading Buying Power',
    definition: 'Available funds for day trading activities. Pattern Day Traders (PDT) typically have 4x their account equity available for day trades, while others have standard buying power.',
    category: 'buying_power'
  },
  'derivative-buying-power': {
    term: 'Derivative Buying Power',
    definition: 'Available funds for trading derivatives like options and futures. This is often limited by regulatory requirements and risk management rules.',
    category: 'buying_power'
  },
  'margin-equity': {
    term: 'Margin Equity',
    definition: 'Your total account equity including margin. This is the value of your securities minus any borrowed funds. It represents your true ownership stake in the account.',
    category: 'margin'
  },
  'net-liquidating-value': {
    term: 'Net Liquidating Value',
    definition: 'The total value of your account if all positions were closed (liquidated) at current market prices. This includes cash, securities, and the net value of all open positions.',
    category: 'balance'
  },
  'maintenance-requirement': {
    term: 'Maintenance Requirement',
    definition: 'The minimum amount of equity you must maintain in your margin account. If your equity falls below this level, you may receive a margin call.',
    category: 'margin'
  },
  'maintenance-excess': {
    term: 'Maintenance Excess',
    definition: 'The amount by which your account equity exceeds the maintenance requirement. This acts as a buffer before receiving margin calls.',
    category: 'margin'
  },
  'day-trade-excess': {
    term: 'Day Trade Excess',
    definition: 'The excess day trading buying power above your maintenance requirement. This shows how much additional day trading capacity you have.',
    category: 'buying_power'
  },
  'reg-t-margin-requirement': {
    term: 'Reg T Margin Requirement',
    definition: 'Federal regulation requirement for initial margin purchases. Typically 50% of the purchase price must be deposited when buying securities on margin.',
    category: 'margin'
  },
  'sma': {
    term: 'SMA (Special Memorandum Account)',
    definition: 'A credit line created when your account has excess equity above maintenance requirements. SMA can be used for additional purchases or withdrawals.',
    category: 'margin'
  },
  'settled-cash': {
    term: 'Settled Cash',
    definition: 'Cash that has completed the settlement process (typically T+2 for stocks) and is fully available for trading and withdrawal without restriction.',
    category: 'balance'
  },
  'unsettled-cash': {
    term: 'Unsettled Cash',
    definition: 'Proceeds from recent trades that have not yet completed the settlement process. These funds may be restricted for certain activities until settlement.',
    category: 'balance'
  },
  'pending-cash': {
    term: 'Pending Cash',
    definition: 'Funds from deposits or trades that are in the process of settling. These funds may not be fully available for trading or withdrawal until processed.',
    category: 'balance'
  },
  'long-equity-value': {
    term: 'Long Equity Value',
    definition: 'The total market value of all stocks and ETFs you own (long positions). This represents your bullish investments in the market.',
    category: 'position'
  },
  'short-equity-value': {
    term: 'Short Equity Value',
    definition: 'The total market value of all stocks you have sold short. Short positions profit when the stock price decreases.',
    category: 'position'
  },
  'long-derivative-value': {
    term: 'Long Derivative Value',
    definition: 'The market value of derivative positions you own, such as call options, put options you purchased, or other derivatives where you are the buyer.',
    category: 'position'
  },
  'short-derivative-value': {
    term: 'Short Derivative Value',
    definition: 'The market value of derivative positions you have sold, such as call options you wrote or put options you sold. These positions have liability exposure.',
    category: 'position'
  },
  'long-futures-value': {
    term: 'Long Futures Value',
    definition: 'The market value of futures contracts where you are the buyer (long position). Futures contracts obligate you to buy the underlying asset.',
    category: 'position'
  },
  'short-futures-value': {
    term: 'Short Futures Value',
    definition: 'The market value of futures contracts where you are the seller (short position). Futures contracts obligate you to sell the underlying asset.',
    category: 'position'
  },
  'long-cryptocurrency-value': {
    term: 'Cryptocurrency Value',
    definition: 'The total market value of all cryptocurrency holdings in your account, including Bitcoin, Ethereum, and other digital assets.',
    category: 'position'
  },
  'long-bond-value': {
    term: 'Bond Value',
    definition: 'The total market value of all bond positions in your account, including government bonds, corporate bonds, and other fixed-income securities.',
    category: 'position'
  },
  'multiplier': {
    term: 'Multiplier',
    definition: 'A factor that determines the contract size for derivatives and futures. For example, an equity option typically has a multiplier of 100, meaning each contract represents 100 shares.',
    category: 'position'
  },
  'average-open-price': {
    term: 'Average Open Price',
    definition: 'The average price at which you purchased or opened your position. This is calculated by dividing the total cost by the number of shares/contracts.',
    category: 'position'
  },
  'close-price': {
    term: 'Close Price',
    definition: 'The last traded price of the security at market close. This is used to calculate the current market value of your positions.',
    category: 'position'
  },
  'unrealized-pnl': {
    term: 'Unrealized P&L',
    definition: 'The profit or loss on your position based on current market prices, before the position is closed. Also known as "paper profit/loss".',
    category: 'position'
  },
  'realized-pnl': {
    term: 'Realized P&L',
    definition: 'The actual profit or loss from positions that have been closed (sold). This represents money that has been gained or lost and is now cash.',
    category: 'position'
  }
};

export const getDefinition = (key: string): string => {
  const definition = FINANCIAL_DEFINITIONS[key];
  return definition ? definition.definition : 'Definition not available for this term.';
};

export const getDefinitionsByCategory = (category: FinancialTerm['category']): FinancialTerm[] => {
  return Object.values(FINANCIAL_DEFINITIONS).filter(def => def.category === category);
};