import { ApiResponse } from '../types/api';

export interface TickSize {
  threshold: string;
  'tick-size': string;
}

export interface Equity {
  symbol: string;
  'instrument-type': string;
  cusip?: string;
  description?: string;
  'listed-market'?: string;
  'tick-sizes'?: TickSize[];
  'market-time-instrument-collection'?: string;
  'is-closing-only'?: boolean;
  'is-options-closing-only'?: boolean;
  'short-description'?: string;
  exchange?: string;
  'streamer-symbol'?: string;
  'is-etf'?: boolean;
  'is-index'?: boolean;
  lendability?: string;
  'borrow-rate'?: string;
  'market-cap'?: string;
  'shares-outstanding'?: number;
  active?: boolean;
}

export interface Option {
  symbol: string;
  'instrument-type': string;
  cusip?: string;
  description?: string;
  'listed-market'?: string;
  'tick-sizes'?: TickSize[];
  'market-time-instrument-collection'?: string;
  'is-closing-only'?: boolean;
  'short-description'?: string;
  exchange?: string;
  'streamer-symbol'?: string;
  'strike-price'?: string;
  'root-symbol'?: string;
  'underlying-symbol'?: string;
  'expiration-date'?: string;
  'exercise-style'?: string;
  'shares-per-contract'?: number;
  'option-type'?: string; // "C" or "P"
  'option-chain-type'?: string;
  'expiration-type'?: string;
  'settlement-type'?: string;
  'stops-trading-at'?: string;
  'days-to-expiration'?: number;
  'expires-at'?: string;
  'deliverable-type'?: string;
  active?: boolean;
}

export interface OptionStrike {
  'strike-price': string;
  call?: string;
  put?: string;
}

export interface OptionExpiration {
  'expiration-date': string;
  'days-to-expiration': number;
  'expiration-type': string;
  'settlement-type': string;
  strikes: { [strikePrice: string]: OptionStrike };
}

export interface OptionChain {
  'underlying-symbol': string;
  'root-symbol': string;
  'option-chain-type': string;
  'shares-per-contract': number;
  'tick-sizes': TickSize[];
  'deliverable-type': string;
  'market-time-instrument-collection': string;
  expirations: { [expirationDate: string]: OptionExpiration };
}

export interface NestedOptionChain {
  'underlying-symbol': string;
  'root-symbol': string;
  'option-chain-type': string;
  'shares-per-contract': number;
  'tick-sizes': TickSize[];
  deliverables?: Deliverable[];
  expirations: NestedExpiration[];
}

export interface FutureContract {
  symbol: string;
  'root-symbol': string;
  'expiration-date': string;
  'days-to-expiration': number;
  'active-month': boolean;
  'next-active-month': boolean;
  'stops-trading-at': string;
  'expires-at': string;
}

export interface FuturesTickSize {
  threshold?: string;
  value: string;
}

export interface FuturesOptionStrike {
  'strike-price': string;
  call?: string;
  'call-streamer-symbol'?: string;
  put?: string;
  'put-streamer-symbol'?: string;
}

export interface FuturesOptionExpiration {
  'underlying-symbol': string;
  'root-symbol': string;
  'option-root-symbol': string;
  'option-contract-symbol': string;
  asset: string;
  'expiration-date': string;
  'days-to-expiration': number;
  'expiration-type': string;
  'settlement-type': string;
  'notional-value': string;
  'display-factor': string;
  'strike-factor': string;
  'stops-trading-at': string;
  'expires-at': string;
  'tick-sizes': FuturesTickSize[];
  strikes: FuturesOptionStrike[];
}

export interface FuturesOptionChain {
  'underlying-symbol': string;
  'root-symbol': string;
  'exercise-style': string;
  expirations: FuturesOptionExpiration[];
}

export interface FuturesOptionChainData {
  futures: FutureContract[];
  'option-chains': FuturesOptionChain[];
}

export interface Deliverable {
  id: number;
  amount: string;
  'deliverable-type': string;
  description: string;
  'instrument-type': string;
  percent: string;
  'root-symbol': string;
  symbol: string;
}

export interface NestedExpiration {
  'expiration-date': string;
  'days-to-expiration': number;
  'expiration-type': string;
  'settlement-type': string;
  strikes: NestedStrike[];
}

export interface NestedStrike {
  'strike-price': string;
  call?: string;
  'call-streamer-symbol'?: string;
  put?: string;
  'put-streamer-symbol'?: string;
}

export interface Future {
  symbol: string;
  'instrument-type': string;
  description?: string;
  'listed-market'?: string;
  'tick-sizes'?: TickSize[];
  'market-time-instrument-collection'?: string;
  'is-closing-only'?: boolean;
  'short-description'?: string;
  exchange?: string;
  'streamer-symbol'?: string;
  'product-code'?: string;
  'contract-size'?: string;
  'tick-size'?: string;
  'display-factor'?: string;
  'last-trade-date'?: string;
  'first-notice-date'?: string;
  'roll-target-symbol'?: string;
  'expiration-date'?: string;
  'days-to-expiration'?: number;
  active?: boolean;
}

export interface SymbolData {
  symbol: string;
  'instrument-type': string;
  description?: string;
  'is-closing-only'?: boolean;
  active?: boolean;
  'product-code'?: string;
  'is-etf'?: boolean;
  'is-index'?: boolean;
  'root-symbol'?: string;
  'short-description'?: string;
}

export interface InstrumentData<T> {
  items: T[];
}

export interface InstrumentPagination {
  'page-offset': number;
  'page-count': number;
  'total-count': number;
}

export interface InstrumentResponse<T> {
  data: T;
  context: string;
  pagination?: InstrumentPagination;
}

export interface InstrumentSearchParams {
  symbol?: string;
  lendability?: string;
  isIndex?: boolean;
  isEtf?: boolean;
  pageOffset?: number;
  productCode?: string;
}

class InstrumentsApi {
  private baseUrl: string;

  constructor() {
    this.baseUrl = process.env.REACT_APP_API_BASE_URL ? `${process.env.REACT_APP_API_BASE_URL}/api/instruments` : 'http://localhost:8181/api/instruments';
    console.log('InstrumentsApi initialized with baseUrl:', this.baseUrl);
  }

  // ===== EQUITY METHODS =====

  async searchEquities(params: InstrumentSearchParams = {}): Promise<ApiResponse<InstrumentResponse<InstrumentData<Equity>>>> {
    console.log('🔍 searchEquities called with params:', JSON.stringify(params, null, 2));
    
    const queryParams = new URLSearchParams();
    
    if (params.symbol) queryParams.append('symbol', params.symbol);
    if (params.lendability) queryParams.append('lendability', params.lendability);
    if (params.isIndex !== undefined) queryParams.append('is-index', params.isIndex.toString());
    if (params.isEtf !== undefined) queryParams.append('is-etf', params.isEtf.toString());

    const url = `${this.baseUrl}/equities${queryParams.toString() ? '?' + queryParams.toString() : ''}`;
    console.log('📡 Making request to URL:', url);
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      console.log('📥 Response received:', {
        status: response.status,
        statusText: response.statusText,
        ok: response.ok,
        headers: Object.fromEntries(response.headers.entries())
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response not OK. Error text:', errorText);
        throw new Error(`Failed to search equities: ${response.status} ${response.statusText} - ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ searchEquities successful response data:', JSON.stringify(data, null, 2));
      return { success: true, data };
    } catch (error) {
      console.error('💥 searchEquities error:', error);
      console.error('Error details:', {
        name: error instanceof Error ? error.name : 'Unknown',
        message: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
      throw error;
    }
  }

  async getActiveEquities(params: InstrumentSearchParams = {}): Promise<ApiResponse<InstrumentResponse<InstrumentData<Equity>>>> {
    const queryParams = new URLSearchParams();
    
    if (params.lendability) queryParams.append('lendability', params.lendability);
    if (params.pageOffset !== undefined) queryParams.append('page-offset', params.pageOffset.toString());

    const url = `${this.baseUrl}/equities/active${queryParams.toString() ? '?' + queryParams.toString() : ''}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to get active equities: ${response.statusText}`);
    }

    const data = await response.json();
    return { success: true, data };
  }

  async getEquity(symbol: string): Promise<ApiResponse<InstrumentResponse<Equity>>> {
    const response = await fetch(`${this.baseUrl}/equities/${symbol}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to get equity: ${response.statusText}`);
    }

    const data = await response.json();
    return { success: true, data };
  }

  // ===== OPTION CHAIN METHODS =====

  async getNestedOptionChain(underlyingSymbol: string): Promise<ApiResponse<InstrumentResponse<InstrumentData<NestedOptionChain>>>> {
    console.log('🔗 getNestedOptionChain called for underlying symbol:', underlyingSymbol);
    
    const url = `${this.baseUrl}/option-chains/${underlyingSymbol}/nested`;
    console.log('📡 Making request to URL:', url);
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      console.log('📥 Response received:', {
        status: response.status,
        statusText: response.statusText,
        ok: response.ok,
        headers: Object.fromEntries(response.headers.entries())
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response not OK. Error text:', errorText);
        throw new Error(`Failed to get nested option chain: ${response.status} ${response.statusText} - ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ getNestedOptionChain successful response data:', JSON.stringify(data, null, 2));
      return { success: true, data };
    } catch (error) {
      console.error('💥 getNestedOptionChain error:', error);
      console.error('Error details:', {
        name: error instanceof Error ? error.name : 'Unknown',
        message: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
      throw error;
    }
  }

  async getDetailedOptionChain(underlyingSymbol: string): Promise<ApiResponse<InstrumentResponse<InstrumentData<Option>>>> {
    const response = await fetch(`${this.baseUrl}/option-chains/${underlyingSymbol}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to get detailed option chain: ${response.statusText}`);
    }

    const data = await response.json();
    return { success: true, data };
  }

  async getCompactOptionChain(underlyingSymbol: string): Promise<ApiResponse<InstrumentResponse<any>>> {
    const response = await fetch(`${this.baseUrl}/option-chains/${underlyingSymbol}/compact`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to get compact option chain: ${response.statusText}`);
    }

    const data = await response.json();
    return { success: true, data };
  }

  // ===== FUTURES METHODS =====

  async searchFutures(params: InstrumentSearchParams = {}): Promise<ApiResponse<InstrumentResponse<InstrumentData<Future>>>> {
    const queryParams = new URLSearchParams();
    
    if (params.symbol) queryParams.append('symbol', params.symbol);
    if (params.productCode) queryParams.append('product-code', params.productCode);

    const url = `${this.baseUrl}/futures${queryParams.toString() ? '?' + queryParams.toString() : ''}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to search futures: ${response.statusText}`);
    }

    const data = await response.json();
    return { success: true, data };
  }

  async getFuture(symbol: string): Promise<ApiResponse<InstrumentResponse<Future>>> {
    console.log('🔍 getFuture called for symbol:', symbol);
    
    // Try the query parameter approach first (more reliable)
    try {
      const queryParams = new URLSearchParams();
      queryParams.append('symbol', symbol);
      const url = `${this.baseUrl}/futures/by-symbol?${queryParams.toString()}`;
      console.log('📡 Making request to URL:', url);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to get future via query: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('✅ getFuture successful via query parameter');
      return { success: true, data };
    } catch (queryError) {
      console.log('Query parameter approach failed, trying path variable approach');
      
      // Fallback to the path variable approach
      const encodedSymbol = encodeURIComponent(symbol);
      
      const response = await fetch(`${this.baseUrl}/futures/${encodedSymbol}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to get future: ${response.statusText}`);
      }

      const data = await response.json();
      return { success: true, data };
    }
  }

  // ===== FUTURES OPTION METHODS =====

  async getFuturesNestedOptionChain(underlyingSymbol: string): Promise<ApiResponse<InstrumentResponse<FuturesOptionChainData>>> {
    console.log('🔗 getFuturesNestedOptionChain called for underlying symbol:', underlyingSymbol);
    
    // URL encode the symbol to handle forward slashes in futures symbols
    const encodedSymbol = encodeURIComponent(underlyingSymbol);
    const url = `${this.baseUrl}/futures-option-chains/${encodedSymbol}/nested`;
    console.log('📡 Making request to URL:', url);
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      console.log('📥 Response received:', {
        status: response.status,
        statusText: response.statusText,
        ok: response.ok,
        headers: Object.fromEntries(response.headers.entries())
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response not OK. Error text:', errorText);
        throw new Error(`Failed to get futures nested option chain: ${response.status} ${response.statusText} - ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ getFuturesNestedOptionChain successful response data:', JSON.stringify(data, null, 2));
      return { success: true, data };
    } catch (error) {
      console.error('💥 getFuturesNestedOptionChain error:', error);
      console.error('Error details:', {
        name: error instanceof Error ? error.name : 'Unknown',
        message: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
      throw error;
    }
  }

  // ===== SYMBOL SEARCH METHODS =====

  async searchSymbols(symbol: string): Promise<ApiResponse<InstrumentResponse<InstrumentData<SymbolData>>>> {
    console.log('🔍 searchSymbols called with query:', symbol);
    
    const url = `${this.baseUrl}/symbols/search/${encodeURIComponent(symbol)}`;
    console.log('📡 Making request to URL:', url);
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      console.log('📥 Response received:', {
        status: response.status,
        statusText: response.statusText,
        ok: response.ok,
        headers: Object.fromEntries(response.headers.entries())
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response not OK. Error text:', errorText);
        throw new Error(`Failed to search symbols: ${response.status} ${response.statusText} - ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ searchSymbols successful response data:', JSON.stringify(data, null, 2));
      return { success: true, data };
    } catch (error) {
      console.error('💥 searchSymbols error:', error);
      console.error('Error details:', {
        name: error instanceof Error ? error.name : 'Unknown',
        message: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
      throw error;
    }
  }

  async getCurrentFuturesContracts(root: string): Promise<ApiResponse<InstrumentResponse<InstrumentData<Future>>>> {
    console.log('🔍 getCurrentFuturesContracts called for root:', root);
    
    const queryParams = new URLSearchParams();
    queryParams.append('root', root);
    
    const url = `${this.baseUrl}/futures/current?${queryParams.toString()}`;
    console.log('📡 Making request to URL:', url);
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      console.log('📥 Response received:', {
        status: response.status,
        statusText: response.statusText,
        ok: response.ok,
        headers: Object.fromEntries(response.headers.entries())
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response not OK. Error text:', errorText);
        throw new Error(`Failed to get current futures contracts: ${response.status} ${response.statusText} - ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ getCurrentFuturesContracts successful response data:', JSON.stringify(data, null, 2));
      return { success: true, data };
    } catch (error) {
      console.error('💥 getCurrentFuturesContracts error:', error);
      console.error('Error details:', {
        name: error instanceof Error ? error.name : 'Unknown',
        message: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
      throw error;
    }
  }

  async getAllFuturesContracts(): Promise<ApiResponse<InstrumentResponse<InstrumentData<Future>>>> {
    console.log('🔍 getAllFuturesContracts called');
    
    const url = `${this.baseUrl}/futures/all`;
    console.log('📡 Making request to URL:', url);
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      console.log('📥 Response received:', {
        status: response.status,
        statusText: response.statusText,
        ok: response.ok
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response not OK. Error text:', errorText);
        throw new Error(`Failed to get all futures contracts: ${response.status} ${response.statusText} - ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ getAllFuturesContracts successful, received:', data.data?.items?.length, 'contracts');
      return { success: true, data };
    } catch (error) {
      console.error('💥 getAllFuturesContracts error:', error);
      console.error('Error details:', {
        name: error instanceof Error ? error.name : 'Unknown',
        message: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
      throw error;
    }
  }

  // ===== CRYPTOCURRENCY METHODS =====

  async searchCryptocurrencies(params: InstrumentSearchParams = {}): Promise<ApiResponse<InstrumentResponse<InstrumentData<any>>>> {
    const queryParams = new URLSearchParams();
    
    if (params.symbol) queryParams.append('symbol', params.symbol);

    const url = `${this.baseUrl}/cryptocurrencies${queryParams.toString() ? '?' + queryParams.toString() : ''}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to search cryptocurrencies: ${response.statusText}`);
    }

    const data = await response.json();
    return { success: true, data };
  }

  async getCryptocurrency(symbol: string): Promise<ApiResponse<InstrumentResponse<any>>> {
    // URL encode the symbol to handle forward slashes
    const encodedSymbol = encodeURIComponent(symbol);
    
    const response = await fetch(`${this.baseUrl}/cryptocurrencies/${encodedSymbol}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to get cryptocurrency: ${response.statusText}`);
    }

    const data = await response.json();
    return { success: true, data };
  }
}

export const instrumentsApi = new InstrumentsApi();