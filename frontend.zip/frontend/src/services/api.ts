import axios from 'axios';
import { 
  ApiResponse, 
  CustomerInfoResponse, 
  AccountsResponse, 
  Account, 
  AccountBalancesResponse, 
  AccountPositionsResponse,
  TransactionsResponse,
  SingleTransactionResponse
} from '../types/api';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8181';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const accountApi = {
  async getCustomerInfo(): Promise<ApiResponse<CustomerInfoResponse>> {
    const response = await apiClient.get('/api/account/customer');
    return response.data;
  },

  async getCustomerAccounts(): Promise<ApiResponse<AccountsResponse>> {
    const response = await apiClient.get('/api/account/accounts');
    return response.data;
  },

  async getAccountInfo(accountNumber: string): Promise<ApiResponse<Account>> {
    const response = await apiClient.get(`/api/account/accounts/${accountNumber}`);
    return response.data;
  },

  async getAccountBalances(accountNumber: string): Promise<ApiResponse<AccountBalancesResponse>> {
    const response = await apiClient.get(`/api/account/accounts/${accountNumber}/balances`);
    return response.data;
  },

  async getAccountPositions(accountNumber: string): Promise<ApiResponse<AccountPositionsResponse>> {
    const response = await apiClient.get(`/api/account/accounts/${accountNumber}/positions`);
    return response.data;
  },

  async getAccountSummary(): Promise<any> {
    const response = await apiClient.get('/api/v1/account/summary');
    return response.data;
  },

  async getHealthCheck(): Promise<any> {
    const response = await apiClient.get('/api/session/health');
    return response.data;
  },

  async getAccountTransactions(accountNumber: string): Promise<ApiResponse<TransactionsResponse>> {
    const response = await apiClient.get(`/api/accounts/${accountNumber}/transactions`);
    return response.data;
  },

  async getAccountTransactionsFiltered(
    accountNumber: string, 
    filters: {
      sort?: string;
      type?: string;
      'start-date'?: string;
      'end-date'?: string;
      symbol?: string;
    }
  ): Promise<ApiResponse<TransactionsResponse>> {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) params.append(key, value);
    });
    
    const response = await apiClient.get(
      `/api/accounts/${accountNumber}/transactions/filtered?${params.toString()}`
    );
    return response.data;
  },

  async getAccountTransaction(accountNumber: string, transactionId: number): Promise<ApiResponse<SingleTransactionResponse>> {
    const response = await apiClient.get(`/api/accounts/${accountNumber}/transactions/${transactionId}`);
    return response.data;
  },
};

export default apiClient;