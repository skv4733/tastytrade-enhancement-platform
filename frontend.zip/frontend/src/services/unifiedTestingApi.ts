import axios from 'axios';

const API_BASE_URL = 'http://localhost:8181/api/test2';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// ===== ACCOUNTS CLIENT ENDPOINTS =====
export const accountsApi = {
  getCustomerInfo: () => api.get('/customers/me'),
  getCustomerAccounts: () => api.get('/customers/me/accounts'),
};

// ===== ACCOUNT STATUS CLIENT ENDPOINTS =====
export const accountStatusApi = {
  getAccountTradingStatus: (accountNumber: string) => 
    api.get(`/accounts/${accountNumber}/trading-status`),
};

// ===== ACCOUNT BALANCE AND POSITIONS CLIENT ENDPOINTS =====
export const accountBalanceAndPositionsApi = {
  getAccountBalances: (accountNumber: string) => 
    api.get(`/accounts/${accountNumber}/balances`),
  getAccountPositions: (accountNumber: string) => 
    api.get(`/accounts/${accountNumber}/positions`),
  getBalanceSnapshots: (accountNumber: string, snapshotDate?: string) => 
    api.get(`/accounts/${accountNumber}/balance-snapshots`, {
      params: snapshotDate ? { snapshotDate } : {}
    }),
};

// ===== SEARCH SYMBOLS CLIENT ENDPOINTS =====
export const searchSymbolsApi = {
  searchSymbols: (symbol: string) => api.get(`/symbols/search/${symbol}`),
  searchEquitySymbols: (symbol: string) => api.get(`/symbols/search/equity/${symbol}`),
  searchFuturesSymbols: (symbol: string) => api.get(`/symbols/search/futures/${symbol}`),
  searchOptionSymbols: (symbol: string) => api.get(`/symbols/search/options/${symbol}`),
};

// ===== WATCHLISTS CLIENT ENDPOINTS =====
export const watchlistsApi = {
  getPublicWatchlists: () => api.get('/public-watchlists'),
  getAccountWatchlists: (accountNumber: string) => 
    api.get(`/accounts/${accountNumber}/watchlists`),
  getWatchlists: () => api.get('/watchlists'),
  getPairsWatchlists: () => api.get('/pairs-watchlists'),
  createWatchlist: (watchlistRequest: any) => 
    api.post('/watchlists', watchlistRequest),
  getWatchlistById: (watchlistId: string) => 
    api.get(`/watchlists/${watchlistId}`),
  deleteWatchlist: (watchlistId: string) => 
    api.delete(`/watchlists/${watchlistId}`),
};

// ===== INSTRUMENTS CLIENT ENDPOINTS =====
export const instrumentsApi = {
  // Equities
  searchEquities: (params: any) => api.get('/instruments/equities', { params }),
  getEquity: (symbol: string) => api.get(`/instruments/equities/${symbol}`),
  createEquity: (equityRequest: any) => api.post('/instruments/equities', equityRequest),
  getActiveEquities: (params: any) => api.get('/instruments/equities/active', { params }),
  updateEquity: (symbol: string, equityPatch: any) => api.patch(`/instruments/equities/${symbol}`, equityPatch),
  
  // Futures
  searchFutures: (params: any) => api.get('/instruments/futures', { params }),
  getFuture: (symbol: string) => api.get(`/instruments/futures/${symbol}`),
  
  // Option Chains
  getNestedOptionChain: (symbol: string) => api.get(`/instruments/option-chains/${symbol}/nested`),
  getCompactOptionChain: (symbol: string) => api.get(`/instruments/option-chains/${symbol}/compact`),
  getDetailedOptionChain: (underlyingSymbol: string) => api.get(`/option-chains/${underlyingSymbol}`),
  getOptionDetailForSingleOption: (symbol: string) => api.get('/option-chains/market-data/by-type', { params: { 'equity-option': symbol } }),
  
  // Equity Options
  getEquityOptions: (symbol?: string) => api.get('/instruments/equity-options', { params: symbol ? { symbol } : {} }),
  getEquityOption: (symbol: string) => api.get(`/instruments/equity-options/${symbol}`),
  updateEquityOption: (symbol: string, optionPatch: any) => api.patch(`/instruments/equity-options/${symbol}`, optionPatch),
  
  // Futures Options
  getFuturesNestedOptionChain: (underlyingSymbol: string) => api.get(`/futures-option-chains/${underlyingSymbol}/nested`),
  getFuturesDetailedOptionChain: (underlyingSymbol: string) => api.get(`/futures-option-chains/${underlyingSymbol}`),
  getFutureOptions: (symbol?: string) => api.get('/instruments/future-options', { params: symbol ? { symbol } : {} }),
  getFutureOption: (symbol: string) => api.get(`/instruments/future-options/${symbol}`),
  
  // Future Products
  getFutureProducts: () => api.get('/instruments/future-products', {
    headers: { 'Authorization': 'SESSION_TOKEN', 'User-Agent': 'TradingApp/1.0' }
  }),
  getFutureProduct: (exchange: string, code: string) => api.get(`/instruments/future-products/${exchange}/${code}`),
  getFutureProductByCode: (code: string) => api.get(`/instruments/future-products/${code}`),
  updateFutureProduct: (id: string, productPatch: any) => api.patch(`/instruments/future-products/${id}`, productPatch),
  
  // Future Option Products
  getFutureOptionProducts: () => api.get('/instruments/future-option-products', {
    headers: { 'Authorization': 'SESSION_TOKEN', 'User-Agent': 'TradingApp/1.0' }
  }),
  getFutureOptionProduct: (exchange: string, rootSymbol: string) => api.get(`/instruments/future-option-products/${exchange}/${rootSymbol}`),
  getFutureOptionProductBySymbol: (rootSymbol: string) => api.get(`/instruments/future-option-products/${rootSymbol}`),
  updateFutureOptionProduct: (id: string, productPatch: any) => api.patch(`/instruments/future-option-products/${id}`, productPatch),
  
  // Cryptocurrencies
  searchCryptocurrencies: (symbol?: string) => api.get('/instruments/cryptocurrencies', { params: symbol ? { symbol } : {} }),
  getCryptocurrency: (symbol: string) => api.get(`/instruments/cryptocurrencies/${symbol}`),
  
  // Bonds
  getBonds: (symbol?: string) => api.get('/instruments/bonds', { params: symbol ? { symbol } : {} }),
  getBond: (symbol: string) => api.get(`/instruments/bonds/${symbol}`),
  updateBond: (symbol: string, bondPatch: any) => api.patch(`/instruments/bonds/${symbol}`, bondPatch),
  
  // Warrants
  getWarrants: (symbol?: string) => api.get('/instruments/warrants', { params: symbol ? { symbol } : {} }),
  getWarrant: (symbol: string) => api.get(`/instruments/warrants/${symbol}`),
  updateWarrant: (symbol: string, warrantPatch: any) => api.patch(`/instruments/warrants/${symbol}`, warrantPatch),
  
  // Other Instruments
  getQuantityDecimalPrecisions: () => api.get('/instruments/quantity-decimal-precisions', {
    headers: { 'Authorization': 'SESSION_TOKEN', 'User-Agent': 'TradingApp/1.0' }
  }),
  getInstrumentLookup: (params: any) => api.get('/instruments/lookup', { params }),
  searchInstruments: (searchRequest: any) => api.post('/instruments/search', searchRequest),
  createInstrument: (instrumentRequest: any) => api.post('/instruments', instrumentRequest),
  getEquityDeliverables: (params: any) => api.get('/instruments/equity-deliverables', { params }),
  getFixedIncomeSecurities: (params: any) => api.get('/instruments/fixed-income-securities', { params }),
};

// ===== ORDERS CLIENT ENDPOINTS =====
export const ordersApi = {
  createOrder: (accountNumber: string, orderRequest: any) => 
    api.post(`/accounts/${accountNumber}/orders`, orderRequest),
  dryRunOrder: (accountNumber: string, orderRequest: any) => 
    api.post(`/accounts/${accountNumber}/orders/dry-run`, orderRequest),
};

// ===== TRANSACTIONS CLIENT ENDPOINTS =====
export const transactionsApi = {
  getAccountTransactions: (accountNumber: string, params?: any) => 
    api.get(`/accounts/${accountNumber}/transactions`, { params }),
  getAccountTransaction: (accountNumber: string, transactionId: string) => 
    api.get(`/accounts/${accountNumber}/transactions/${transactionId}`),
  getTotalTransactionFees: (accountNumber: string, params?: any) => 
    api.get(`/accounts/${accountNumber}/transactions/total-fees`, { params }),
};

// ===== MARKET TIME CLIENT ENDPOINTS =====
export const marketTimeApi = {
  // Market Sessions
  getMarketSessions: (params?: any) => api.get('/market-time/sessions', { params }),
  getCurrentMarketSessions: (instrumentCollections?: string) => 
    api.get('/market-time/sessions/current', { 
      params: instrumentCollections ? { 'instrument-collections': instrumentCollections } : {} 
    }),
  getAllMarketSessions: () => api.get('/market-time/sessions/all'),
  
  // Equity Sessions
  getCurrentEquitySession: () => api.get('/market-time/equities/sessions/current'),
  getNextEquitySession: () => api.get('/market-time/equities/sessions/next'),
  getPreviousEquitySession: () => api.get('/market-time/equities/sessions/previous'),
  getEquityHolidays: (params?: any) => api.get('/market-time/equities/holidays', { params }),
  
  // Futures Sessions
  getCurrentFuturesSession: () => api.get('/market-time/futures/sessions/current'),
  getCurrentFuturesSessionByCollection: (instrumentCollection: string) => 
    api.get(`/market-time/futures/sessions/current/${instrumentCollection}`),
  getPreviousFuturesSessionByCollection: (instrumentCollection: string) => 
    api.get(`/market-time/futures/sessions/previous/${instrumentCollection}`),
  getFuturesHolidaysByCollection: (instrumentCollection: string, params?: any) => 
    api.get(`/market-time/futures/holidays/${instrumentCollection}`, { params }),
  
  // Market Status & Calendar
  getMarketStatus: () => api.get('/market-time/status'),
  getTradingCalendar: (params?: any) => api.get('/market-time/calendar', { params }),
  getCurrentExtendedHours: () => api.get('/market-time/extended-hours/current'),
};

// ===== MARKET DATA CLIENT ENDPOINTS =====
export const marketDataApi = {
  getMarketDataByType: (params: any) => 
    api.get('/market-data/by-type', { params }),
};

// ===== MARKET METRICS CLIENT ENDPOINTS =====
export const marketMetricsApi = {
  getMarketMetrics: (symbols?: string) => 
    api.get('/market-metrics', { params: symbols ? { symbols } : {} }),
  getDividendHistory: (symbol: string) => 
    api.get(`/market-metrics/historic-corporate-events/dividends/${symbol}`),
  getEarningsReportHistory: (symbol: string) => 
    api.get(`/market-metrics/historic-corporate-events/earnings-reports/${symbol}`),
};

// ===== RISK PARAMETERS CLIENT ENDPOINTS =====
export const riskParametersApi = {
  getEffectiveMarginRequirements: (accountNumber: string, symbol: string) => 
    api.get(`/accounts/${accountNumber}/margin-requirements/${symbol}/effective`),
  getPositionLimits: (accountNumber: string) => 
    api.get(`/accounts/${accountNumber}/position-limit`),
  getRiskParameters: (accountNumber: string) => 
    api.get(`/accounts/${accountNumber}/risk-parameters`),
  getBuyingPower: (accountNumber: string) => 
    api.get(`/accounts/${accountNumber}/buying-power`),
  calculateBuyingPowerEffect: (accountNumber: string, orderRequest: any) => 
    api.post(`/accounts/${accountNumber}/buying-power/effect`, orderRequest),
  updatePositionLimits: (accountNumber: string, positionLimitRequest: any) => 
    api.patch(`/accounts/${accountNumber}/position-limit`, positionLimitRequest),
  getConcentrationLimits: (accountNumber: string) => 
    api.get(`/accounts/${accountNumber}/concentration-limits`),
  updateConcentrationLimits: (accountNumber: string, concentrationLimitsRequest: any) => 
    api.patch(`/accounts/${accountNumber}/concentration-limits`, concentrationLimitsRequest),
  getRiskStatus: (accountNumber: string) => 
    api.get(`/accounts/${accountNumber}/risk-status`),
  getMarginCalls: (accountNumber: string, params?: any) => 
    api.get(`/accounts/${accountNumber}/margin-calls`, { params }),
  getLiquidationHistory: (accountNumber: string, params?: any) => 
    api.get(`/accounts/${accountNumber}/liquidations`, { params }),
};

// ===== MARGIN REQUIREMENTS CLIENT ENDPOINTS =====
export const marginRequirementsApi = {
  getMarginRequirements: (accountNumber: string, params?: any) => 
    api.get(`/margin/accounts/${accountNumber}/requirements`, { params }),
  performMarginDryRun: (accountNumber: string, marginDryRunRequest: any) => 
    api.post(`/margin/accounts/${accountNumber}/dry-run`, marginDryRunRequest),
  getSymbolMarginRequirements: (accountNumber: string, symbol: string, params?: any) => 
    api.get(`/margin/accounts/${accountNumber}/requirements/symbol/${symbol}`, { params }),
  calculateMarginRequirements: (accountNumber: string, marginCalculationRequest: any) => 
    api.post(`/margin/accounts/${accountNumber}/calculate`, marginCalculationRequest),
  getMarginUtilization: (accountNumber: string) => 
    api.get(`/margin/accounts/${accountNumber}/utilization`),
  getPortfolioMarginRequirements: (accountNumber: string) => 
    api.get(`/margin/accounts/${accountNumber}/portfolio-margin`),
  getMarginUtilizationHistory: (accountNumber: string, params?: any) => 
    api.get(`/utilization/history`, { params }),
  getMarginAlerts: (accountNumber: string, params?: any) => 
    api.get(`/alerts`, { params }),
  getMarginCallStatus: (accountNumber: string) => 
    api.get(`/margin-call`),
  performPortfolioMarginDryRun: (accountNumber: string, portfolioMarginRequest: any) => 
    api.post(`/portfolio-margin/dry-run`, portfolioMarginRequest),
  getMarginConfiguration: (accountNumber: string) => 
    api.get(`/configuration`),
};

export default {
  accountsApi,
  accountStatusApi,
  accountBalanceAndPositionsApi,
  searchSymbolsApi,
  watchlistsApi,
  instrumentsApi,
  ordersApi,
  transactionsApi,
  marketTimeApi,
  riskParametersApi,
  marginRequirementsApi,
  marketDataApi,
  marketMetricsApi,
};